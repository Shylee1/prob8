import 'dotenv/config';
import express from 'express';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type, ThinkingLevel } from '@google/genai';
import {
  extractDocketFallback,
  parseNaturalLanguageQueryFallback,
} from './src/utils/probateLogic.ts';
import {
  SAMPLE_TYLER_ODYSSEY_HTML,
  runTexasOdysseyPipeline,
} from './src/connectors/texasOdysseyConnector.ts';
import { buildPropertyMarketIntelligence } from './src/utils/valuationAndIntegrations.ts';
import type { CrmDeal } from './src/types/caselot.ts';

function isBlockedWebhookHost(hostname: string): boolean {
  const host = hostname.toLowerCase().replace(/^\[|\]$/g, '');
  if (
    host === 'localhost' ||
    host === '127.0.0.1' ||
    host === '0.0.0.0' ||
    host === '::1' ||
    host.endsWith('.local') ||
    host.endsWith('.internal')
  ) {
    return true;
  }
  const ipv4Match = host.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
  if (ipv4Match) {
    const [, a, b] = ipv4Match.map(Number);
    if (
      a === 10 ||
      a === 127 ||
      (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) ||
      (a === 192 && b === 168) ||
      a === 0
    ) {
      return true;
    }
  }
  return false;
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === 'production';

function getAiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY' || apiKey.trim() === '') {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

async function startServer() {
  const app = express();
  const httpServer = http.createServer(app);
  app.use(express.json({ limit: '2mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, service: 'CaseLot API' });
  });

  app.get('/api/config/maps', (_req, res) => {
    const apiKey =
      process.env.VITE_GOOGLE_MAPS_API_KEY ||
      process.env.GOOGLE_MAPS_API_KEY ||
      '';
    res.json({ apiKey: apiKey === 'MY_GOOGLE_MAPS_API_KEY' ? '' : apiKey });
  });

  app.post('/api/connectors/texas-odyssey/sync', (req, res) => {
    const rawFeed =
      typeof req.body?.rawFeed === 'string' && req.body.rawFeed.trim().length > 0
        ? req.body.rawFeed
        : SAMPLE_TYLER_ODYSSEY_HTML;
    const rawCounty = String(req.body?.countyFilter || 'ALL');
    const countyFilter =
      rawCounty === 'Harris' || rawCounty === 'Travis' ? rawCounty : 'ALL';

    const result = runTexasOdysseyPipeline(rawFeed, countyFilter);
    res.json(result);
  });

  // Live 3rd-party webhook / REST integration connectivity tester (with SSRF guardrails)
  app.post('/api/integrations/test-webhook', async (req, res) => {
    const endpointUrl = String(req.body?.endpointUrl || '').trim();
    const integrationName = String(req.body?.name || 'Custom Integration').trim();
    const authHeaderName = String(req.body?.authHeaderName || 'X-CaseLot-Signature')
      .replace(/[\r\n]/g, '')
      .trim();
    const authHeaderValue = String(req.body?.apiKeyMasked || 'caselot_test_token')
      .replace(/[\r\n]/g, '')
      .trim();

    let parsedUrl: URL;
    try {
      parsedUrl = new URL(endpointUrl);
    } catch {
      res.status(400).json({ ok: false, error: 'Please provide a valid https:// endpoint URL.' });
      return;
    }

    if (parsedUrl.protocol !== 'https:' && parsedUrl.protocol !== 'http:') {
      res.status(400).json({ ok: false, error: 'Only http:// or https:// endpoints are supported.' });
      return;
    }

    if (isBlockedWebhookHost(parsedUrl.hostname)) {
      res.status(400).json({
        ok: false,
        error: 'Private, loopback, and link-local hosts are blocked for security.',
      });
      return;
    }

    const started = Date.now();
    const samplePayload = {
      event: 'caselot.integration.test',
      timestamp: new Date().toISOString(),
      integration: integrationName,
      deal: {
        caseNumber: 'PR-2026-48102',
        county: 'Harris',
        state: 'TX',
        address: '412 Meadowbrook Dr, Houston, TX 77024',
        assessedValue: 410000,
      },
    };

    try {
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        'User-Agent': 'CaseLot-Webhook-Dispatcher/2026.1',
      };
      if (authHeaderName && authHeaderValue) {
        headers[authHeaderName] = authHeaderValue;
      }

      const upstream = await fetch(parsedUrl.toString(), {
        method: 'POST',
        headers,
        body: JSON.stringify(samplePayload),
        signal: AbortSignal.timeout(6000),
      });
      const text = await upstream.text();
      res.json({
        ok: upstream.ok,
        status: upstream.status,
        latencyMs: Date.now() - started,
        preview: text.slice(0, 240),
      });
    } catch (err) {
      res.status(502).json({
        ok: false,
        status: 502,
        latencyMs: Date.now() - started,
        error: err instanceof Error ? err.message : 'Upstream webhook request failed.',
      });
    }
  });

  // Property Valuation & Comps Intelligence (Zillow / Redfin market benchmarks)
  app.post('/api/property/market-intel', (req, res) => {
    const deal = req.body?.deal as CrmDeal | undefined;
    if (!deal || !deal.property) {
      res.status(400).json({ error: 'Valid deal & property payload is required.' });
      return;
    }
    const rehabOverride =
      typeof req.body?.rehabOverride === 'number' ? req.body.rehabOverride : undefined;
    const intel = buildPropertyMarketIntelligence(deal, rehabOverride);
    res.json({ source: 'caselot-avm-aggregator', intel });
  });

  // 1. Smart AI Probate Search -> translates natural language into structured Discover filters
  app.post('/api/ai/search', async (req, res) => {
    const query = String(req.body?.query || '').trim();
    if (!query) {
      res.status(400).json({ error: 'Search query is required.' });
      return;
    }

    const ai = getAiClient();
    if (!ai) {
      const filters = parseNaturalLanguageQueryFallback(query);
      res.json({
        source: 'deterministic-parser',
        filters,
        explanation: 'Parsed natural-language query into structured county, administration, equity, and representation filters.',
      });
      return;
    }

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: `Convert this probate real estate search query into structured filter fields: "${query}"`,
        config: {
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
          systemInstruction:
            'You are the CaseLot probate docket query parser. Extract structured filter fields from the user query. Use "ALL" for stateCode or countyName if unspecified. Available states/counties: TX (Harris, Travis), AZ (Maricopa), FL (Miami-Dade), IL (Cook), GA (Fulton). propertyType is one of: "All", "Single-Family", "Multi-Family", "Land / Lot", "Commercial". adminType is one of: "all", "Independent", "Dependent / Supervised", "Informal", "Summary". attorneyStatus is one of: "all", "no-attorney", "represented". minEquity is an integer USD amount (0 if unspecified). filingWindowDays is integer days (0 if unspecified). searchQuery is any remaining keyword not covered by structured fields (empty string if fully captured).',
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              stateCode: { type: Type.STRING },
              countyName: { type: Type.STRING },
              filingWindowDays: { type: Type.INTEGER },
              propertyType: { type: Type.STRING },
              minEquity: { type: Type.INTEGER },
              attorneyStatus: { type: Type.STRING },
              adminType: { type: Type.STRING },
              searchQuery: { type: Type.STRING },
              explanation: { type: Type.STRING },
            },
            required: [
              'stateCode',
              'countyName',
              'filingWindowDays',
              'propertyType',
              'minEquity',
              'attorneyStatus',
              'adminType',
              'searchQuery',
              'explanation',
            ],
          },
        },
      });

      const parsed = JSON.parse((response.text ?? '{}').trim());
      const rawCounty = String(parsed.countyName || 'ALL').replace(/\s+County$/i, '').trim();
      res.json({
        source: 'gemini-4-hydrogen',
        filters: {
          stateCode: String(parsed.stateCode || 'ALL').toUpperCase(),
          countyName: rawCounty || 'ALL',
          filingWindowDays: Number(parsed.filingWindowDays) || 0,
          propertyType: parsed.propertyType || 'All',
          minEquity: Number(parsed.minEquity) || 0,
          attorneyStatus: parsed.attorneyStatus || 'all',
          adminType: parsed.adminType || 'all',
          searchQuery: parsed.searchQuery || '',
        },
        explanation:
          parsed.explanation ||
          'Translated natural-language query into structured court & assessor filters.',
      });
    } catch (err) {
      console.error('AI search error, falling back:', err);
      const filters = parseNaturalLanguageQueryFallback(query);
      res.json({
        source: 'deterministic-fallback',
        filters,
        explanation: 'Applied local structured query parser.',
      });
    }
  });

  // 2. Structured Court Docket / PDF Text Extraction
  app.post('/api/ai/extract-docket', async (req, res) => {
    const rawText = String(req.body?.rawText || '').trim();
    if (!rawText || rawText.length < 15) {
      res.status(400).json({ error: 'Please paste raw docket or filing text (at least 15 characters).' });
      return;
    }

    const ai = getAiClient();
    if (!ai) {
      res.json({
        source: 'deterministic-parser',
        extracted: extractDocketFallback(rawText),
      });
      return;
    }

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: `Extract structured probate case and real estate fields from this court filing text:\n\n${rawText}`,
        config: {
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
          systemInstruction:
            'Extract exact probate case, stakeholder, and real property fields from court docket text. Normalize stateCode to 2-letter US postal code (e.g. TX, AZ, FL, IL, GA). Return countyName WITHOUT the word "County" (e.g. "Harris", "Maricopa"). Return propertyAddress as street address ONLY without city/state/zip (e.g. "1842 Oak Crest Ln"). Normalize adminType strictly to one of: "Independent", "Dependent / Supervised", "Informal", "Summary". Normalize propertyType strictly to one of: "Single-Family", "Multi-Family", "Land / Lot", "Commercial". Return integer USD numbers for assessedValue and estimatedDebt.',
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              decedentName: { type: Type.STRING },
              dateOfDeath: { type: Type.STRING },
              caseNumber: { type: Type.STRING },
              caseType: { type: Type.STRING },
              adminType: { type: Type.STRING },
              probateStage: { type: Type.STRING },
              executorName: { type: Type.STRING },
              executorAddress: { type: Type.STRING },
              probateAttorney: { type: Type.STRING },
              propertyAddress: { type: Type.STRING },
              city: { type: Type.STRING },
              stateCode: { type: Type.STRING },
              countyName: { type: Type.STRING },
              parcelId: { type: Type.STRING },
              assessedValue: { type: Type.INTEGER },
              estimatedDebt: { type: Type.INTEGER },
              propertyType: { type: Type.STRING },
              aiSummary: { type: Type.STRING },
            },
            required: [
              'decedentName',
              'dateOfDeath',
              'caseNumber',
              'caseType',
              'adminType',
              'probateStage',
              'executorName',
              'executorAddress',
              'probateAttorney',
              'propertyAddress',
              'city',
              'stateCode',
              'countyName',
              'parcelId',
              'assessedValue',
              'estimatedDebt',
              'propertyType',
              'aiSummary',
            ],
          },
        },
      });

      const extracted = JSON.parse((response.text ?? '{}').trim());
      if (extracted.countyName) {
        extracted.countyName = String(extracted.countyName).replace(/\s+County$/i, '').trim();
      }
      if (extracted.propertyAddress) {
        extracted.propertyAddress = String(extracted.propertyAddress).split(',')[0].trim();
      }
      res.json({
        source: 'gemini-4-hydrogen',
        extracted,
      });
    } catch (err) {
      console.error('AI extract error, falling back:', err);
      res.json({
        source: 'deterministic-fallback',
        extracted: extractDocketFallback(rawText),
      });
    }
  });

  // 3. Localized Probate Hub Plain-English Rule Explainer (with UPL guardrail)
  app.post('/api/ai/explain-rule', async (req, res) => {
    const question = String(req.body?.question || '').trim();
    const countyName = String(req.body?.countyName || 'Harris');
    const stateCode = String(req.body?.stateCode || 'TX');
    const rulesContext = String(req.body?.rulesContext || '');

    if (!question) {
      res.status(400).json({ error: 'Question is required.' });
      return;
    }

    const ai = getAiClient();
    if (!ai) {
      res.json({
        source: 'local-playbook',
        answer: `In ${countyName} County, ${stateCode}, real estate transfer authority depends on whether the Personal Representative holds Independent/Informal authority or requires a Supervised Court Order of Sale. ${rulesContext} Always verify the active Letters Testamentary / Administration and consult a licensed ${stateCode} probate attorney for transaction-specific legal advice.`,
      });
      return;
    }

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: `Jurisdiction: ${countyName} County, ${stateCode}\nContext: ${rulesContext}\nUser operational question: ${question}`,
        config: {
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
          systemInstruction:
            'You are CaseLot’s plain-English probate workflow guide for real estate acquisitions. Answer concisely in 2-3 clear sentences focused on operational steps, documents to verify, and county procedures. NEVER give formal legal advice or draft bespoke legal pleadings; always end with a concise reminder to verify with local title counsel or a licensed probate attorney.',
        },
      });

      res.json({
        source: 'gemini-4-hydrogen',
        answer: (response.text ?? '').trim(),
      });
    } catch (err) {
      console.error('AI explain-rule error:', err);
      res.json({
        source: 'local-playbook',
        answer: `In ${countyName} County, ${stateCode}: ${rulesContext} Verify active Letters and confirm title underwriting requirements with a licensed local probate attorney.`,
      });
    }
  });

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const disableHmr = process.env.DISABLE_HMR === 'true';
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        allowedHosts: true,
        ws: { server: httpServer },
        hmr: disableHmr ? false : { server: httpServer },
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('/{*splat}', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`CaseLot server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
