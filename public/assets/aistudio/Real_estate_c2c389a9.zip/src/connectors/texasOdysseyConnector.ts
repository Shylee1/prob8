import type { AdminType, CrmDeal, PropertyType } from '../types/caselot';

export interface TexasOdysseyDocketRow {
  caseNumber: string;
  countyName: 'Harris' | 'Travis';
  courtName: string;
  decedentName: string;
  dateOfDeath: string;
  filingDate: string;
  caseType: string;
  adminType: AdminType;
  probateStage: string;
  personalRepresentative: string;
  prMailingAddress: string;
  attorney: string;
  rawSnippet: string;
}

export interface TexasTaxAssessorParcel {
  parcelId: string;
  countyName: 'Harris' | 'Travis';
  ownerName: string;
  situsAddress: string;
  city: string;
  stateCode: 'TX';
  zip: string;
  legalDescription: string;
  assessedValue: number;
  estimatedDebt: number;
  propertyType: PropertyType;
  sqft: number;
  yearBuilt: number;
  lat: number;
  lng: number;
}

export interface TexasAssessorMatch {
  docket: TexasOdysseyDocketRow;
  parcel: TexasTaxAssessorParcel | null;
  matchConfidence: number;
  matchMethod: string;
}

export interface TexasConnectorRunResult {
  vendor: 'Tyler Odyssey (Texas Probate Courts)';
  countyFilter: 'ALL' | 'Harris' | 'Travis';
  syncedAt: string;
  parsedDocketsCount: number;
  matchedPropertiesCount: number;
  matches: TexasAssessorMatch[];
  deals: CrmDeal[];
}

export const SAMPLE_TYLER_ODYSSEY_HTML = `<table id="OdysseyCaseSearchResults">
  <tbody>
    <tr data-cause="526104-403" data-county="Harris">
      <td class="case-num">526104-403</td>
      <td class="court">Harris County Probate Court No. 3</td>
      <td class="style">IN THE ESTATE OF RAYMOND V. ALVAREZ, DECEASED (DOD: 2026-09-11)</td>
      <td class="filed">2026-11-11</td>
      <td class="type">Application for Independent Administration &amp; Letters Testamentary</td>
      <td class="pr">Gloria Alvarez | 3118 Norfolk St, Houston, TX 77098</td>
      <td class="atty">None Listed (Pro Se)</td>
    </tr>
    <tr data-cause="526188-401" data-county="Harris">
      <td class="case-num">526188-401</td>
      <td class="court">Harris County Probate Court No. 1</td>
      <td class="style">IN THE ESTATE OF MARTHA E. CALDWELL, DECEASED (DOD: 2026-09-02)</td>
      <td class="filed">2026-11-12</td>
      <td class="type">Application for Dependent Administration (Court-Supervised)</td>
      <td class="pr">Kevin Caldwell | 714 Sabine St, Houston, TX 77007</td>
      <td class="atty">Lydia Brooks, Esq.</td>
    </tr>
    <tr data-cause="C-1-PB-26-002490" data-county="Travis">
      <td class="case-num">C-1-PB-26-002490</td>
      <td class="court">Travis County Probate Court No. 1</td>
      <td class="style">ESTATE OF ROBERT T. HENDRICKS, DECEASED (DOD: 2026-09-24)</td>
      <td class="filed">2026-11-12</td>
      <td class="type">Independent Administration &amp; Determination of Heirship</td>
      <td class="pr">Denise Hendricks | 4208 Shoal Creek Blvd, Austin, TX 78756</td>
      <td class="atty">Pro Se</td>
    </tr>
    <tr data-cause="C-1-PB-26-002512" data-county="Travis">
      <td class="case-num">C-1-PB-26-002512</td>
      <td class="court">Travis County Probate Court No. 2</td>
      <td class="style">IN THE ESTATE OF NORA J. WHITFIELD, DECEASED (DOD: 2026-08-30)</td>
      <td class="filed">2026-11-13</td>
      <td class="type">Independent Probate of Will &amp; Muniment Check</td>
      <td class="pr">Grant Whitfield | 2104 Barton Hills Dr, Austin, TX 78704</td>
      <td class="atty">Samuel Ortiz, Esq.</td>
    </tr>
  </tbody>
</table>`;

export const TEXAS_TAX_ASSESSOR_ROLL: TexasTaxAssessorParcel[] = [
  {
    parcelId: 'HCAD-066-142-0018',
    countyName: 'Harris',
    ownerName: 'ALVAREZ, RAYMOND V',
    situsAddress: '4418 Magnolia Ridge Dr',
    city: 'Houston',
    stateCode: 'TX',
    zip: '77023',
    legalDescription: 'LT 18 BLK 6 IDYLWOOD ADDN, HARRIS COUNTY, TX',
    assessedValue: 398000,
    estimatedDebt: 14000,
    propertyType: 'Single-Family',
    sqft: 1960,
    yearBuilt: 1954,
    lat: 29.7235,
    lng: -95.3248,
  },
  {
    parcelId: 'HCAD-031-088-0009',
    countyName: 'Harris',
    ownerName: 'CALDWELL, MARTHA E EST OF',
    situsAddress: '1108 W Drew St',
    city: 'Houston',
    stateCode: 'TX',
    zip: '77006',
    legalDescription: 'LT 9 BLK 14 MONTROSE PLACE, HARRIS COUNTY, TX',
    assessedValue: 545000,
    estimatedDebt: 82000,
    propertyType: 'Multi-Family',
    sqft: 2740,
    yearBuilt: 1948,
    lat: 29.7478,
    lng: -95.3941,
  },
  {
    parcelId: 'TCAD-021904-0311',
    countyName: 'Travis',
    ownerName: 'HENDRICKS, ROBERT T',
    situsAddress: '1604 E Cesar Chavez St',
    city: 'Austin',
    stateCode: 'TX',
    zip: '78702',
    legalDescription: 'LOT 11 BLK 3 CHESTNUT CORRIDOR, TRAVIS COUNTY, TX',
    assessedValue: 485000,
    estimatedDebt: 22000,
    propertyType: 'Commercial',
    sqft: 2150,
    yearBuilt: 1968,
    lat: 30.2564,
    lng: -97.7265,
  },
  {
    parcelId: 'TCAD-010815-0920',
    countyName: 'Travis',
    ownerName: 'WHITFIELD, NORA J',
    situsAddress: '2711 Oakmont Blvd',
    city: 'Austin',
    stateCode: 'TX',
    zip: '78703',
    legalDescription: 'LOT 20 OAKMONT HEIGHTS SEC 2, TRAVIS COUNTY, TX',
    assessedValue: 675000,
    estimatedDebt: 45000,
    propertyType: 'Single-Family',
    sqft: 2490,
    yearBuilt: 1961,
    lat: 30.3052,
    lng: -97.7524,
  },
];

const STOP_WORDS = new Set(['EST', 'ESTATE', 'OF', 'THE', 'IN', 'DECEASED', 'ET', 'AL', 'JR', 'SR', 'II', 'III', 'TRUST']);

export function normalizePersonName(rawName: string): string[] {
  const cleaned = rawName
    .toUpperCase()
    .replace(/&AMP;/g, '&')
    .replace(/[^A-Z0-9,\s]/g, ' ')
    .trim();

  // Reorder "LAST, FIRST M" -> tokens still match either way
  const tokens = cleaned
    .split(/[\s,]+/)
    .map((t) => t.trim())
    .filter((t) => t.length > 0 && !STOP_WORDS.has(t));

  return Array.from(new Set(tokens));
}

function decodeHtmlEntities(str: string): string {
  return str
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .trim();
}

function inferAdminType(text: string): AdminType {
  const lower = text.toLowerCase();
  if (/\bindependent\b/.test(lower)) return 'Independent';
  if (/\bdependent\b|\bsupervised\b/.test(lower)) return 'Dependent / Supervised';
  if (/\binformal\b/.test(lower)) return 'Informal';
  if (/\bsummary\b/.test(lower)) return 'Summary';
  return 'Independent';
}

function cleanDecedentFromStyle(styleText: string): { decedentName: string; dateOfDeath: string } {
  const dodMatch = styleText.match(/DOD:?\s*([0-9]{4}-[0-9]{2}-[0-9]{2})/i);
  const dateOfDeath = dodMatch ? dodMatch[1] : '2026-09-15';
  const stripped = styleText
    .replace(/\(DOD:[^)]+\)/gi, '')
    .replace(/IN\s+THE\s+ESTATE\s+OF\s+/gi, '')
    .replace(/ESTATE\s+OF\s+/gi, '')
    .replace(/,?\s*DECEASED/gi, '')
    .trim();

  // Title case nicely if all uppercase
  const titleCased = stripped
    .split(/\s+/)
    .map((word) => {
      if (word.length <= 2 && word.endsWith('.')) return word.toUpperCase();
      return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
    })
    .join(' ');

  return { decedentName: titleCased || 'Unknown Decedent', dateOfDeath };
}

export function parseTylerOdysseyFeed(
  rawFeed: string,
  countyFilter: 'ALL' | 'Harris' | 'Travis' = 'ALL'
): TexasOdysseyDocketRow[] {
  const trimmed = rawFeed.trim();
  const rows: TexasOdysseyDocketRow[] = [];

  if (trimmed.startsWith('[') || trimmed.startsWith('{')) {
    try {
      const parsed = JSON.parse(trimmed);
      const arr = Array.isArray(parsed) ? parsed : [parsed];
      for (const item of arr) {
        const county: 'Harris' | 'Travis' =
          String(item.countyName || item.county || '').toLowerCase().includes('travis')
            ? 'Travis'
            : 'Harris';
        if (countyFilter !== 'ALL' && county !== countyFilter) continue;
        rows.push({
          caseNumber: String(item.caseNumber || item.case_number || 'TX-2026-001'),
          countyName: county,
          courtName: String(item.courtName || `${county} County Probate Court`),
          decedentName: String(item.decedentName || item.decedent_name || 'Unknown Decedent'),
          dateOfDeath: String(item.dateOfDeath || '2026-09-15'),
          filingDate: String(item.filingDate || '2026-11-12'),
          caseType: String(item.caseType || 'Independent Administration'),
          adminType: inferAdminType(String(item.adminType || item.caseType || '')),
          probateStage: String(item.probateStage || 'Petition Filed'),
          personalRepresentative: String(item.personalRepresentative || 'Pending Appointment'),
          prMailingAddress: String(item.prMailingAddress || `${county} County, TX`),
          attorney: String(item.attorney || 'None Listed (Pro Se)'),
          rawSnippet: JSON.stringify(item),
        });
      }
      return rows;
    } catch {
      // Fall through to HTML / line parsing
    }
  }

  // Parse Tyler Odyssey HTML <tr> blocks
  const trMatches = trimmed.match(/<tr[^>]*>[\s\S]*?<\/tr>/gi);
  if (trMatches && trMatches.length > 0) {
    for (const tr of trMatches) {
      const tdMatches = [...tr.matchAll(/<td[^>]*>([\s\S]*?)<\/td>/gi)].map((m) =>
        decodeHtmlEntities(m[1].replace(/<[^>]+>/g, ''))
      );
      if (tdMatches.length < 5) continue;

      const [caseNumber, courtName, styleText, filingDate, caseType, prField = '', attyField = 'Pro Se'] = tdMatches;
      const county: 'Harris' | 'Travis' = courtName.toLowerCase().includes('travis') ? 'Travis' : 'Harris';
      if (countyFilter !== 'ALL' && county !== countyFilter) continue;

      const { decedentName, dateOfDeath } = cleanDecedentFromStyle(styleText);
      const [prName, prAddr] = prField.split('|').map((s) => s.trim());

      rows.push({
        caseNumber,
        countyName: county,
        courtName,
        decedentName,
        dateOfDeath,
        filingDate,
        caseType,
        adminType: inferAdminType(caseType),
        probateStage: caseType.toLowerCase().includes('dependent')
          ? 'Court-Supervised Petition'
          : 'Application & Citation Issued',
        personalRepresentative: prName || 'Pending PR Appointment',
        prMailingAddress: prAddr || `${county} County, TX`,
        attorney: attyField || 'None Listed (Pro Se)',
        rawSnippet: `${caseNumber} | ${courtName} | ${styleText} | ${caseType}`,
      });
    }
    return rows;
  }

  // Pipe or CSV line fallback
  const lines = trimmed
    .split('\n')
    .map((l) => l.trim())
    .filter((l) => l.length > 5 && !l.toLowerCase().startsWith('casenumber'));

  for (const line of lines) {
    const parts = line.split(/\||,/).map((p) => p.trim());
    if (parts.length < 4) continue;
    const [caseNumber, countyRaw, decedentRaw, filingDate, caseType = 'Independent Administration', pr = 'Applicant', atty = 'Pro Se'] = parts;
    const county: 'Harris' | 'Travis' = countyRaw.toLowerCase().includes('travis') ? 'Travis' : 'Harris';
    if (countyFilter !== 'ALL' && county !== countyFilter) continue;
    const { decedentName, dateOfDeath } = cleanDecedentFromStyle(decedentRaw);
    rows.push({
      caseNumber,
      countyName: county,
      courtName: `${county} County Probate Court`,
      decedentName,
      dateOfDeath,
      filingDate: filingDate || '2026-11-12',
      caseType,
      adminType: inferAdminType(caseType),
      probateStage: 'Petition Filed',
      personalRepresentative: pr,
      prMailingAddress: `${county} County, TX`,
      attorney: atty,
      rawSnippet: line,
    });
  }

  return rows;
}

export function scoreOwnerNameMatch(decedentName: string, ownerName: string): number {
  const decedentTokens = normalizePersonName(decedentName);
  const ownerTokens = normalizePersonName(ownerName);
  if (decedentTokens.length === 0 || ownerTokens.length === 0) return 0;

  let matched = 0;
  let exactMultiCharMatches = 0;

  for (const dTok of decedentTokens) {
    if (ownerTokens.includes(dTok)) {
      matched += 1;
      if (dTok.length >= 2) exactMultiCharMatches += 1;
    } else if (dTok.length === 1 && ownerTokens.some((o) => o.startsWith(dTok))) {
      matched += 0.6;
    }
  }

  if (exactMultiCharMatches < 2) {
    return Math.round((matched / decedentTokens.length) * 55);
  }

  const recall = matched / decedentTokens.length;
  const precision = matched / ownerTokens.length;
  const f1 = (2 * recall * precision) / Math.max(0.001, recall + precision);
  return Math.min(99, Math.round(70 + f1 * 29));
}

export function crossReferenceAssessorRolls(
  docketCases: TexasOdysseyDocketRow[],
  taxRolls: TexasTaxAssessorParcel[] = TEXAS_TAX_ASSESSOR_ROLL
): TexasAssessorMatch[] {
  return docketCases.map((docket) => {
    const countyParcels = taxRolls.filter((p) => p.countyName === docket.countyName);
    let bestParcel: TexasTaxAssessorParcel | null = null;
    let bestScore = 0;

    for (const parcel of countyParcels) {
      const score = scoreOwnerNameMatch(docket.decedentName, parcel.ownerName);
      if (score > bestScore) {
        bestScore = score;
        bestParcel = parcel;
      }
    }

    if (bestParcel && bestScore >= 75) {
      return {
        docket,
        parcel: bestParcel,
        matchConfidence: bestScore,
        matchMethod: `${docket.countyName === 'Harris' ? 'HCAD' : 'TCAD'} Owner Token Cross-Match`,
      };
    }

    return {
      docket,
      parcel: null,
      matchConfidence: bestScore,
      matchMethod: 'No County Tax Roll Match Above Threshold (75%)',
    };
  });
}

export function runTexasOdysseyPipeline(
  rawFeed: string = SAMPLE_TYLER_ODYSSEY_HTML,
  countyFilter: 'ALL' | 'Harris' | 'Travis' = 'ALL',
  taxRolls: TexasTaxAssessorParcel[] = TEXAS_TAX_ASSESSOR_ROLL
): TexasConnectorRunResult {
  const parsed = parseTylerOdysseyFeed(rawFeed, countyFilter);
  const matches = crossReferenceAssessorRolls(parsed, taxRolls);

  const deals: CrmDeal[] = [];
  matches.forEach((m, idx) => {
    if (!m.parcel) return;
    const { docket, parcel, matchConfidence } = m;
    const hasAttorney =
      Boolean(docket.attorney) && !/none|pro se|unrepresented/i.test(docket.attorney);
    const jurisdictionId = docket.countyName === 'Travis' ? 'tx-travis' : 'tx-harris';
    const angle = ((idx + 2) * 1.18) % (Math.PI * 2);
    const radius = 4.6 + (idx % 3) * 1.9;

    deals.push({
      id: `deal-tx-odyssey-${docket.caseNumber.toLowerCase().replace(/[^a-z0-9]/g, '')}`,
      inPipeline: false,
      stage: 'Verified Real Estate',
      offerAmount: Math.round(parcel.assessedValue * 0.76),
      notes: `Synced from Tyler Odyssey (${docket.courtName}) & cross-matched against ${docket.countyName === 'Harris' ? 'HCAD' : 'TCAD'} parcel ${parcel.parcelId} (${matchConfidence}% confidence).`,
      nextFollowupAt: '2026-11-22',
      probateCase: {
        id: `case-odyssey-${docket.caseNumber}`,
        jurisdictionId,
        caseNumber: docket.caseNumber,
        decedentName: docket.decedentName,
        dateOfDeath: docket.dateOfDeath,
        filingDate: docket.filingDate,
        caseType: docket.caseType,
        adminType: docket.adminType,
        probateStage: docket.probateStage,
        hasAttorney,
        rawDocketText: docket.rawSnippet,
        aiSummary: `Tyler Odyssey connector ingested ${docket.adminType.toLowerCase()} filing in ${docket.courtName}; ${docket.countyName === 'Harris' ? 'HCAD' : 'TCAD'} assessor cross-reference confirmed ownership of ${parcel.situsAddress}.`,
        docketTimeline: [
          {
            id: `ev-od-${idx}-1`,
            date: docket.filingDate,
            title: docket.caseType,
            documentType: 'Tyler Odyssey Sync',
            notes: `PR: ${docket.personalRepresentative} · Counsel: ${docket.attorney}`,
          },
          {
            id: `ev-od-${idx}-2`,
            date: new Date().toISOString().slice(0, 10),
            title: `${docket.countyName === 'Harris' ? 'HCAD' : 'TCAD'} Tax Roll Match Verified (${matchConfidence}%)`,
            documentType: 'Assessor Match',
            notes: `APN ${parcel.parcelId} — ${parcel.legalDescription}`,
          },
        ],
      },
      property: {
        id: `prop-od-${parcel.parcelId}`,
        parcelId: parcel.parcelId,
        address: parcel.situsAddress,
        city: parcel.city,
        stateCode: 'TX',
        zip: parcel.zip,
        countyName: parcel.countyName,
        legalDescription: parcel.legalDescription,
        assessedValue: parcel.assessedValue,
        estimatedDebt: parcel.estimatedDebt,
        propertyType: parcel.propertyType,
        sqft: parcel.sqft,
        yearBuilt: parcel.yearBuilt,
        lat: parcel.lat,
        lng: parcel.lng,
        sceneX: Number((Math.cos(angle) * radius).toFixed(2)),
        sceneZ: Number((Math.sin(angle) * radius).toFixed(2)),
        ownerName: parcel.ownerName,
        matchConfidence,
        matchSource: 'County Tax Roll Cross-Match',
      },
      stakeholders: [
        {
          id: `st-od-${idx}-pr`,
          role: 'Executor / PR',
          fullName: docket.personalRepresentative,
          mailingAddress: docket.prMailingAddress,
          phone: '(555) 014-8820',
          email: 'estate.contact@example.com',
          verified: true,
        },
        ...(hasAttorney
          ? [
              {
                id: `st-od-${idx}-atty`,
                role: 'Probate Attorney' as const,
                fullName: docket.attorney,
                mailingAddress: `${docket.countyName} County Bar`,
                phone: '(555) 014-9901',
                email: 'probate.counsel@example.com',
                verified: true,
              },
            ]
          : []),
      ],
      activities: [
        {
          id: `act-od-${idx}-1`,
          timestamp: new Date().toISOString().slice(0, 16).replace('T', ' '),
          channel: 'Note',
          summary: `Auto-ingested from Tyler Odyssey Texas Probate Connector & matched to ${parcel.parcelId}.`,
        },
      ],
      checklistCompleted: {},
    });
  });

  return {
    vendor: 'Tyler Odyssey (Texas Probate Courts)',
    countyFilter,
    syncedAt: new Date().toISOString().slice(0, 16).replace('T', ' ') + ' CST',
    parsedDocketsCount: parsed.length,
    matchedPropertiesCount: deals.length,
    matches,
    deals,
  };
}
