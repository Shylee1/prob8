import test from 'node:test';
import assert from 'node:assert/strict';
import {
  SAMPLE_TYLER_ODYSSEY_HTML,
  crossReferenceAssessorRolls,
  normalizePersonName,
  parseTylerOdysseyFeed,
  runTexasOdysseyPipeline,
  scoreOwnerNameMatch,
} from './texasOdysseyConnector.ts';

test('normalizePersonName handles LAST, FIRST and strips estate stop words', () => {
  assert.deepEqual(
    normalizePersonName('IN THE ESTATE OF RAYMOND V. ALVAREZ, DECEASED'),
    ['RAYMOND', 'V', 'ALVAREZ']
  );
  assert.deepEqual(
    normalizePersonName('ALVAREZ, RAYMOND V EST OF'),
    ['ALVAREZ', 'RAYMOND', 'V']
  );
});

test('parseTylerOdysseyFeed parses HTML rows and filters by county', () => {
  const allRows = parseTylerOdysseyFeed(SAMPLE_TYLER_ODYSSEY_HTML, 'ALL');
  assert.equal(allRows.length, 4);
  assert.equal(allRows[0].caseNumber, '526104-403');
  assert.equal(allRows[0].countyName, 'Harris');
  assert.equal(allRows[0].adminType, 'Independent');

  const travisRows = parseTylerOdysseyFeed(SAMPLE_TYLER_ODYSSEY_HTML, 'Travis');
  assert.equal(travisRows.length, 2);
  assert.equal(travisRows[0].countyName, 'Travis');
});

test('scoreOwnerNameMatch matches inverted tax roll names with high confidence', () => {
  const score = scoreOwnerNameMatch('Martha E. Caldwell', 'CALDWELL, MARTHA E EST OF');
  assert.ok(score >= 90, `Expected >= 90 confidence, got ${score}`);

  const mismatch = scoreOwnerNameMatch('Martha E. Caldwell', 'ALVAREZ, RAYMOND V');
  assert.ok(mismatch < 50, `Expected < 50 mismatch score, got ${mismatch}`);
});

test('crossReferenceAssessorRolls matches Texas probate dockets to HCAD/TCAD parcels', () => {
  const rows = parseTylerOdysseyFeed(SAMPLE_TYLER_ODYSSEY_HTML, 'ALL');
  const matches = crossReferenceAssessorRolls(rows);
  assert.equal(matches.length, 4);
  for (const m of matches) {
    assert.ok(m.parcel !== null, `Expected parcel match for ${m.docket.decedentName}`);
    assert.ok(m.matchConfidence >= 90);
  }
});

test('runTexasOdysseyPipeline produces ready-to-import CrmDeal records', () => {
  const result = runTexasOdysseyPipeline(SAMPLE_TYLER_ODYSSEY_HTML, 'Harris');
  assert.equal(result.parsedDocketsCount, 2);
  assert.equal(result.matchedPropertiesCount, 2);
  assert.equal(result.deals[0].property.stateCode, 'TX');
  assert.equal(result.deals[0].property.countyName, 'Harris');
  assert.ok(result.deals[0].property.assessedValue > 0);
});
