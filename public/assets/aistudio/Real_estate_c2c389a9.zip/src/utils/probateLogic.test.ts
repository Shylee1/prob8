import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateEstimatedEquity,
  filterProbateDeals,
  parseNaturalLanguageQueryFallback,
  extractDocketFallback,
  computePipelineMetrics,
  buildFormFieldMap,
} from './probateLogic';
import type { BuyerProfile, CrmDeal, DiscoverFilters, Jurisdiction } from '../types/caselot';

const sampleDeals: CrmDeal[] = [
  {
    id: 'deal-1',
    inPipeline: true,
    stage: 'Verified Real Estate',
    offerAmount: 245000,
    notes: 'Vacant brick ranch',
    nextFollowupAt: '2026-11-18',
    probateCase: {
      id: 'case-1',
      jurisdictionId: 'tx-harris',
      caseNumber: 'PR-2026-501192',
      decedentName: 'Arthur Pendelton',
      dateOfDeath: '2026-09-02',
      filingDate: '2026-10-28',
      caseType: 'Probate of Will',
      adminType: 'Independent',
      probateStage: 'Letters Issued',
      hasAttorney: false,
      rawDocketText: 'Independent admin sample',
      aiSummary: 'Independent administration in Harris County, no attorney of record.',
      docketTimeline: [],
    },
    property: {
      id: 'prop-1',
      parcelId: '044-210-009-0012',
      address: '2814 Meadowbrook Dr',
      city: 'Houston',
      stateCode: 'TX',
      zip: '77025',
      countyName: 'Harris',
      legalDescription: 'LT 12 BLK 4 MEADOWBROOK SEC 2',
      assessedValue: 340000,
      estimatedDebt: 40000,
      propertyType: 'Single-Family',
      sqft: 2150,
      yearBuilt: 1968,
      lat: 29.69,
      lng: -95.42,
      sceneX: -4,
      sceneZ: 2,
      ownerName: 'Arthur Pendelton',
      matchConfidence: 98,
      matchSource: 'County Tax Roll Cross-Match',
    },
    stakeholders: [
      {
        id: 'st-1',
        role: 'Executor / PR',
        fullName: 'Clara Pendelton',
        mailingAddress: '901 Sage Rd, Houston, TX 77056',
        phone: '(713) 555-0192',
        email: 'clara.p@example.com',
        verified: true,
      },
    ],
    activities: [],
    checklistCompleted: {},
  },
  {
    id: 'deal-2',
    inPipeline: true,
    stage: 'Probate Court Approval',
    offerAmount: 310000,
    notes: 'Overbid hearing scheduled',
    nextFollowupAt: '2026-11-22',
    probateCase: {
      id: 'case-2',
      jurisdictionId: 'az-maricopa',
      caseNumber: 'PB2026-008341',
      decedentName: 'Eleanor Vance',
      dateOfDeath: '2026-07-10',
      filingDate: '2026-09-01',
      caseType: 'Formal Probate',
      adminType: 'Dependent / Supervised',
      probateStage: 'Order of Sale Pending',
      hasAttorney: true,
      rawDocketText: 'Formal supervised estate',
      aiSummary: 'Supervised probate in Maricopa County.',
      docketTimeline: [],
    },
    property: {
      id: 'prop-2',
      parcelId: '164-28-045',
      address: '4512 E Camelback Rd',
      city: 'Phoenix',
      stateCode: 'AZ',
      zip: '85018',
      countyName: 'Maricopa',
      legalDescription: 'LOT 45 ARCADIA ESTATES UNIT 3',
      assessedValue: 480000,
      estimatedDebt: 210000,
      propertyType: 'Single-Family',
      sqft: 2640,
      yearBuilt: 1979,
      lat: 33.5,
      lng: -111.98,
      sceneX: 5,
      sceneZ: -3,
      ownerName: 'Eleanor Vance',
      matchConfidence: 95,
      matchSource: 'Inventory & Appraisement PDF',
    },
    stakeholders: [],
    activities: [],
    checklistCompleted: {},
  },
];

const defaultFilters: DiscoverFilters = {
  stateCode: 'ALL',
  countyName: 'ALL',
  filingWindowDays: 0,
  propertyType: 'All',
  minEquity: 0,
  attorneyStatus: 'all',
  adminType: 'all',
  searchQuery: '',
};

test('calculateEstimatedEquity clamps negative values and computes net equity', () => {
  assert.equal(calculateEstimatedEquity(340000, 40000), 300000);
  assert.equal(calculateEstimatedEquity(100000, 150000), 0);
  assert.equal(calculateEstimatedEquity(-50, 100), 0);
});

test('filterProbateDeals filters by state, attorney status, and equity threshold', () => {
  const noAtty = filterProbateDeals(sampleDeals, {
    ...defaultFilters,
    stateCode: 'TX',
    attorneyStatus: 'no-attorney',
    minEquity: 250000,
  });
  assert.equal(noAtty.length, 1);
  assert.equal(noAtty[0].id, 'deal-1');

  const recentOnly = filterProbateDeals(
    sampleDeals,
    { ...defaultFilters, filingWindowDays: 30 },
    '2026-11-13'
  );
  assert.equal(recentOnly.length, 1);
  assert.equal(recentOnly[0].id, 'deal-1');
});

test('parseNaturalLanguageQueryFallback extracts county, admin type, equity, and pro se status', () => {
  const parsed = parseNaturalLanguageQueryFallback(
    'Show me independent administration single-family homes in Harris County with $200k equity and no attorney'
  );
  assert.equal(parsed.stateCode, 'TX');
  assert.equal(parsed.countyName, 'Harris');
  assert.equal(parsed.adminType, 'Independent');
  assert.equal(parsed.propertyType, 'Single-Family');
  assert.equal(parsed.minEquity, 200000);
  assert.equal(parsed.attorneyStatus, 'no-attorney');
});

test('extractDocketFallback parses structured fields from raw court filing text', () => {
  const raw = `
    Case No: 2026-PR-09812
    Estate of Margaret Holloway
    Date of Death: 2026-08-19
    Independent Administration
    Executor: David Holloway
    Property Address: 1842 Oak Crest Ln, Houston, TX
    APN: 064-118-002-0019
    Assessed Value: $365,000
    Liens: $45,000
  `;
  const extracted = extractDocketFallback(raw);
  assert.equal(extracted.caseNumber, '2026-PR-09812');
  assert.equal(extracted.decedentName, 'Margaret Holloway');
  assert.equal(extracted.executorName, 'David Holloway');
  assert.equal(extracted.assessedValue, 365000);
  assert.equal(extracted.estimatedDebt, 45000);
  assert.equal(extracted.adminType, 'Independent');
});

test('computePipelineMetrics aggregates stage counts and total equity', () => {
  const metrics = computePipelineMetrics(sampleDeals);
  assert.equal(metrics.totalPipelineDeals, 2);
  assert.equal(metrics.totalAssessedValue, 820000);
  assert.equal(metrics.totalEstimatedEquity, 570000);
  assert.equal(metrics.courtApprovalCount, 1);
  assert.equal(metrics.stageCounts['Verified Real Estate'], 1);
  assert.equal(metrics.stageEquity['Probate Court Approval'], 270000);
});

test('buildFormFieldMap auto-populates estate, parcel, and jurisdiction contingency clause', () => {
  const buyer: BuyerProfile = {
    entityName: 'Oakline Acquisitions LLC',
    signerName: 'Jordan Reyes',
    signerTitle: 'Managing Member',
    mailingAddress: '800 Capitol St, Houston, TX 77002',
    phone: '(713) 555-0144',
    email: 'acquisitions@oakline.example',
    earnestMoney: 5000,
    inspectionDays: 10,
    closingDays: 21,
  };
  const jurisdiction: Jurisdiction = {
    id: 'az-maricopa',
    stateCode: 'AZ',
    stateName: 'Arizona',
    countyName: 'Maricopa',
    courtSystemType: 'Superior Court Probate Division',
    scrapingAdapter: 'CourtView',
    connectorStatus: 'Scheduled Daily',
    lastSyncedAt: '2026-11-13',
    rules: {
      adminTypesSummary: 'Informal vs Formal',
      courtConfirmationRequired: true,
      overbidProcess: '10% initial overbid',
      typicalTimeline: '4-6 months',
      creditorClaimPeriod: '120 days',
      homesteadNote: 'Statutory allowance applies',
    },
    officialLinks: [],
    checklistTemplates: [],
  };
  const fields = buildFormFieldMap(sampleDeals[1], jurisdiction, buyer);
  assert.equal(fields.estateName, 'Estate of Eleanor Vance');
  assert.equal(fields.parcelId, '164-28-045');
  assert.equal(fields.offerAmount, '$310,000');
  assert.ok(fields.probateContingencyClause.includes('court confirmation'));
});
