import type { CrmDeal } from '../types/caselot';

export interface OverbidFormula {
  firstBracketCap: number;
  firstBracketPct: number;
  remainderPct: number;
  flatAddOn: number;
  description: string;
}

export interface StateProbateStatute {
  stateCode: string;
  stateName: string;
  upcAdopted: 'Full UPC' | 'Modified UPC' | 'Non-UPC';
  independentAuthority: string;
  courtConfirmationRule: string;
  overbidFormula: OverbidFormula | null;
  creditorClaimWindow: string;
  homesteadAndSpousalNote: string;
  attorneyRule: string;
  typicalTimelineMonths: string;
  transferOnDeathDeed: boolean;
}

export interface FederalComplianceCheck {
  id: 'firpta' | 'respa' | 'tcpa' | 'fair-housing';
  statute: string;
  title: string;
  status: 'Compliant / Exempt' | 'Action Required' | 'High Risk — Verify Consent';
  severity: 'ok' | 'caution' | 'warning';
  summary: string;
  requiredAction: string;
}

export interface FederalComplianceReport {
  firptaWithholdingEstimate: number;
  firptaRatePct: number;
  tcpaConsentRequired: boolean;
  respaWholesaleFlag: boolean;
  checks: FederalComplianceCheck[];
}

// Comprehensive United States 50-State + DC Probate Real Estate Statutory Matrix
export const US_STATE_PROBATE_RULES: StateProbateStatute[] = [
  {
    stateCode: 'AL',
    stateName: 'Alabama',
    upcAdopted: 'Non-UPC',
    independentAuthority: 'Will Power of Sale or Petition to Sell',
    courtConfirmationRule: 'Required when Will omits explicit power of sale or in intestate estates.',
    overbidFormula: null,
    creditorClaimWindow: '6 months from grant of Letters',
    homesteadAndSpousalNote: 'Homestead allowance ($15,000) & elective share protections apply.',
    attorneyRule: 'Counsel strongly recommended for real estate petitions',
    typicalTimelineMonths: '6–10 mo',
    transferOnDeathDeed: false,
  },
  {
    stateCode: 'AK',
    stateName: 'Alaska',
    upcAdopted: 'Full UPC',
    independentAuthority: 'Informal Probate (Registrar)',
    courtConfirmationRule: 'Not required under Informal Probate unless restricted on Letters.',
    overbidFormula: null,
    creditorClaimWindow: '4 months from first publication',
    homesteadAndSpousalNote: 'UPC Homestead Allowance ($27,000) & Family Allowance.',
    attorneyRule: 'Pro se permitted for Informal PR',
    typicalTimelineMonths: '4–7 mo',
    transferOnDeathDeed: true,
  },
  {
    stateCode: 'AZ',
    stateName: 'Arizona',
    upcAdopted: 'Full UPC',
    independentAuthority: 'Informal Probate (A.R.S. § 14-3301)',
    courtConfirmationRule: 'Not required for Informal PR; required for Supervised / restricted Letters.',
    overbidFormula: {
      firstBracketCap: 10000,
      firstBracketPct: 0.1,
      remainderPct: 0.05,
      flatAddOn: 0,
      description: 'Court confirmation overbid typically starts at 10% on first $10k + 5% balance when ordered.',
    },
    creditorClaimWindow: '4 months (120 days) from first publication',
    homesteadAndSpousalNote: 'Beneficiary (TOD) Deeds common; statutory family/homestead allowances.',
    attorneyRule: 'Pro se permitted for individual PR',
    typicalTimelineMonths: '4–7 mo',
    transferOnDeathDeed: true,
  },
  {
    stateCode: 'AR',
    stateName: 'Arkansas',
    upcAdopted: 'Non-UPC',
    independentAuthority: 'Will Power of Sale or Court Order',
    courtConfirmationRule: 'Court order & appraisal check (often 75% appraisal floor) unless Will grants power.',
    overbidFormula: null,
    creditorClaimWindow: '6 months from first notice publication',
    homesteadAndSpousalNote: 'Constitutional homestead & dower/curtesy spousal life estate rights.',
    attorneyRule: 'Attorney required for most estate administrations',
    typicalTimelineMonths: '6–12 mo',
    transferOnDeathDeed: true,
  },
  {
    stateCode: 'CA',
    stateName: 'California',
    upcAdopted: 'Non-UPC',
    independentAuthority: 'IAEA Full Authority (Prob. Code § 10400)',
    courtConfirmationRule: 'Full IAEA avoids court auction (15-day Notice of Proposed Action). Limited/No IAEA requires court confirmation & 90% probate referee appraisal floor.',
    overbidFormula: {
      firstBracketCap: 10000,
      firstBracketPct: 0.1,
      remainderPct: 0.05,
      flatAddOn: 0,
      description: 'Cal. Prob. Code § 10311: Minimum first overbid = 10% of first $10,000 + 5% of remaining price.',
    },
    creditorClaimWindow: '4 months from issuance of Letters',
    homesteadAndSpousalNote: 'Probate homestead & community property spousal election review required.',
    attorneyRule: 'Pro se permitted for individual PR; statutory fees apply if attorney retained',
    typicalTimelineMonths: '9–16 mo',
    transferOnDeathDeed: true,
  },
  {
    stateCode: 'CO',
    stateName: 'Colorado',
    upcAdopted: 'Full UPC',
    independentAuthority: 'Informal Probate (C.R.S. § 15-12-301)',
    courtConfirmationRule: 'Not required under Informal/Unsupervised Administration.',
    overbidFormula: null,
    creditorClaimWindow: '4 months from published notice (1 year max)',
    homesteadAndSpousalNote: 'Exempt property & family allowance; Beneficiary Deeds widely used.',
    attorneyRule: 'Pro se permitted',
    typicalTimelineMonths: '6–9 mo',
    transferOnDeathDeed: true,
  },
  {
    stateCode: 'CT',
    stateName: 'Connecticut',
    upcAdopted: 'Non-UPC',
    independentAuthority: 'Probate Court Decree Authorizing Sale',
    courtConfirmationRule: 'Court approval required if Will omits sale power or estate is insolvent.',
    overbidFormula: null,
    creditorClaimWindow: '150 days from appointment of fiduciary',
    homesteadAndSpousalNote: 'Statutory spousal share & CT estate tax lien clearance (Form PC-256) required for closing.',
    attorneyRule: 'Pro se permitted; title insurers often require CT counsel review',
    typicalTimelineMonths: '6–12 mo',
    transferOnDeathDeed: false,
  },
  {
    stateCode: 'DE',
    stateName: 'Delaware',
    upcAdopted: 'Non-UPC',
    independentAuthority: 'Register of Wills / Will Power of Sale',
    courtConfirmationRule: 'Chancery Court petition required to sell real property to pay debts if no Will power.',
    overbidFormula: null,
    creditorClaimWindow: '8 months from date of death',
    homesteadAndSpousalNote: 'Real property vests in heirs/devisees at death subject to estate debt liens.',
    attorneyRule: 'Counsel recommended for Chancery real estate petitions',
    typicalTimelineMonths: '8–12 mo',
    transferOnDeathDeed: false,
  },
  {
    stateCode: 'DC',
    stateName: 'District of Columbia',
    upcAdopted: 'Modified UPC',
    independentAuthority: 'Unsupervised Probate (D.C. Code § 20-401)',
    courtConfirmationRule: 'Unsupervised PR may sell without court order; Supervised PR requires court approval.',
    overbidFormula: null,
    creditorClaimWindow: '6 months from first notice publication',
    homesteadAndSpousalNote: 'Homestead allowance & DC estate tax clearance certificate required.',
    attorneyRule: 'Pro se permitted for standard estates',
    typicalTimelineMonths: '6–10 mo',
    transferOnDeathDeed: true,
  },
  {
    stateCode: 'FL',
    stateName: 'Florida',
    upcAdopted: 'Non-UPC',
    independentAuthority: 'Will Power of Sale (Fla. Stat. § 733.613)',
    courtConfirmationRule: 'Court Order Authorizing Sale required if Will lacks explicit Power of Sale or estate is intestate.',
    overbidFormula: null,
    creditorClaimWindow: '90 days (3 months) from first publication of Notice to Creditors',
    homesteadAndSpousalNote: 'CRITICAL: Constitutional Homestead passes outside probate; Petition to Determine Homestead Status required.',
    attorneyRule: 'Florida Bar attorney REQUIRED for nearly all Formal Administrations',
    typicalTimelineMonths: '5–9 mo (Formal) · 1–3 mo (Summary)',
    transferOnDeathDeed: false,
  },
  {
    stateCode: 'GA',
    stateName: 'Georgia',
    upcAdopted: 'Non-UPC',
    independentAuthority: 'Solemn Form Will Power of Sale',
    courtConfirmationRule: 'Not required when Will grants power of sale; Administrators require Leave to Sell petition.',
    overbidFormula: null,
    creditorClaimWindow: '3 months from final notice publication',
    homesteadAndSpousalNote: 'Year’s Support petitions (O.C.G.A. § 53-3-1) can award real estate ahead of creditors.',
    attorneyRule: 'Pro se permitted',
    typicalTimelineMonths: '3–6 mo',
    transferOnDeathDeed: true,
  },
  {
    stateCode: 'HI',
    stateName: 'Hawaii',
    upcAdopted: 'Full UPC',
    independentAuthority: 'Informal Probate (Registrar)',
    courtConfirmationRule: 'Informal PR sells privately; Supervised / Formal requires court confirmation & overbid.',
    overbidFormula: {
      firstBracketCap: 10000,
      firstBracketPct: 0.1,
      remainderPct: 0.05,
      flatAddOn: 0,
      description: 'Haw. Rev. Stat. § 560:3-715 / court rules: 10% first $10k + 5% balance in confirmed sales.',
    },
    creditorClaimWindow: '4 months from first publication',
    homesteadAndSpousalNote: 'Elective share & HARPTA state non-resident withholding (7.25%) check.',
    attorneyRule: 'Pro se permitted for Informal; counsel recommended for Land Court',
    typicalTimelineMonths: '6–10 mo',
    transferOnDeathDeed: true,
  },
  {
    stateCode: 'ID',
    stateName: 'Idaho',
    upcAdopted: 'Full UPC',
    independentAuthority: 'Informal Unsupervised Probate',
    courtConfirmationRule: 'Not required under Informal Administration.',
    overbidFormula: null,
    creditorClaimWindow: '4 months from first publication',
    homesteadAndSpousalNote: 'Community property state; surviving spouse Devolution / Summary Probate common.',
    attorneyRule: 'Pro se permitted',
    typicalTimelineMonths: '4–7 mo',
    transferOnDeathDeed: false,
  },
  {
    stateCode: 'IL',
    stateName: 'Illinois',
    upcAdopted: 'Non-UPC',
    independentAuthority: 'Independent Administration (755 ILCS 5/28-1)',
    courtConfirmationRule: 'Not required under Independent Admin; Supervised Admin requires court order.',
    overbidFormula: null,
    creditorClaimWindow: '6 months from first publication of claim notice',
    homesteadAndSpousalNote: 'Title insurers require bond-in-lieu or escrow holdback during 6-month claim window.',
    attorneyRule: 'Counsel typically required by local probate divisions (e.g. Cook County)',
    typicalTimelineMonths: '6–10 mo',
    transferOnDeathDeed: true,
  },
  {
    stateCode: 'IN',
    stateName: 'Indiana',
    upcAdopted: 'Non-UPC',
    independentAuthority: 'Unsupervised Administration (Ind. Code § 29-1-7.5)',
    courtConfirmationRule: 'Not required for Unsupervised PR; Supervised requires court order & appraisal.',
    overbidFormula: null,
    creditorClaimWindow: '3 months from first notice publication',
    homesteadAndSpousalNote: 'Spousal survivor allowance ($25,000) & Transfer-on-Death Deeds recognized.',
    attorneyRule: 'Indiana attorney generally required for court-filed estates',
    typicalTimelineMonths: '4–7 mo',
    transferOnDeathDeed: true,
  },
  {
    stateCode: 'IA',
    stateName: 'Iowa',
    upcAdopted: 'Non-UPC',
    independentAuthority: 'Will Power of Sale / Court Order',
    courtConfirmationRule: 'Court order & notice to heirs required unless Will authorizes private sale without order.',
    overbidFormula: null,
    creditorClaimWindow: '4 months from second publication',
    homesteadAndSpousalNote: 'Spousal homestead occupancy rights & Iowa inheritance tax clearance (repealed 2025+, check DOD).',
    attorneyRule: 'Attorney required for Iowa probate administration',
    typicalTimelineMonths: '6–10 mo',
    transferOnDeathDeed: false,
  },
  {
    stateCode: 'KS',
    stateName: 'Kansas',
    upcAdopted: 'Non-UPC',
    independentAuthority: 'Simplified Estates Act / Will Power of Sale',
    courtConfirmationRule: 'Not required under Simplified Estates Act with Will power; otherwise court order required.',
    overbidFormula: null,
    creditorClaimWindow: '4 months from first publication',
    homesteadAndSpousalNote: 'Strong constitutional homestead exemption for surviving spouse/children.',
    attorneyRule: 'Kansas attorney required for most estate proceedings',
    typicalTimelineMonths: '5–9 mo',
    transferOnDeathDeed: true,
  },
  {
    stateCode: 'KY',
    stateName: 'Kentucky',
    upcAdopted: 'Non-UPC',
    independentAuthority: 'Will Power of Sale / District Court',
    courtConfirmationRule: 'Circuit Court action required to sell real property if Will lacks sale power.',
    overbidFormula: null,
    creditorClaimWindow: '6 months from appointment of fiduciary',
    homesteadAndSpousalNote: 'Dower/curtesy spousal interest must be released or joined at closing.',
    attorneyRule: 'Pro se permitted for simple estates; counsel needed for Circuit sale',
    typicalTimelineMonths: '6–9 mo',
    transferOnDeathDeed: false,
  },
  {
    stateCode: 'LA',
    stateName: 'Louisiana',
    upcAdopted: 'Non-UPC',
    independentAuthority: 'Independent Administration (La. C.C.P. Art. 3396)',
    courtConfirmationRule: 'Independent Executor/Admin sells without court advertising; Ordinary Admin requires 7-day publication & court homologation.',
    overbidFormula: null,
    creditorClaimWindow: 'During succession prior to Judgment of Possession',
    homesteadAndSpousalNote: 'Civil Law Forced Heirship & Usufruct rules apply to community/separate property.',
    attorneyRule: 'Louisiana succession attorney typically required',
    typicalTimelineMonths: '3–8 mo',
    transferOnDeathDeed: false,
  },
  {
    stateCode: 'ME',
    stateName: 'Maine',
    upcAdopted: 'Full UPC',
    independentAuthority: 'Informal Probate (18-C M.R.S. § 3-301)',
    courtConfirmationRule: 'Informal PR holds statutory power of sale unless restricted.',
    overbidFormula: null,
    creditorClaimWindow: '4 months from first publication',
    homesteadAndSpousalNote: 'UPC Homestead Allowance ($22,500) & Maine estate tax lien check.',
    attorneyRule: 'Pro se permitted',
    typicalTimelineMonths: '5–8 mo',
    transferOnDeathDeed: true,
  },
  {
    stateCode: 'MD',
    stateName: 'Maryland',
    upcAdopted: 'Modified UPC',
    independentAuthority: 'Administrative Probate (Register of Wills)',
    courtConfirmationRule: 'PR holds broad statutory power to sell real estate without Orphans’ Court order.',
    overbidFormula: null,
    creditorClaimWindow: '6 months from date of death',
    homesteadAndSpousalNote: 'Family allowance & Maryland inheritance tax (10% collateral heirs) check.',
    attorneyRule: 'Pro se permitted',
    typicalTimelineMonths: '6–10 mo',
    transferOnDeathDeed: false,
  },
  {
    stateCode: 'MA',
    stateName: 'Massachusetts',
    upcAdopted: 'Full UPC',
    independentAuthority: 'Informal Probate + License to Sell',
    courtConfirmationRule: 'Unless Will grants explicit power of sale, PR must petition Probate Court for a License to Sell Real Estate.',
    overbidFormula: null,
    creditorClaimWindow: '1 year from date of death (title lien)',
    homesteadAndSpousalNote: 'Automatic MA estate tax lien attaches to real estate for 10 yrs (M.G.L. c. 65C) — requires Release of Lien.',
    attorneyRule: 'Counsel strongly advised for License to Sell & M.G.L. c. 65C lien release',
    typicalTimelineMonths: '6–12 mo',
    transferOnDeathDeed: false,
  },
  {
    stateCode: 'MI',
    stateName: 'Michigan',
    upcAdopted: 'Full UPC',
    independentAuthority: 'Informal / Unsupervised Probate (EPIC)',
    courtConfirmationRule: 'Not required for Unsupervised PR unless Letters restrict real estate sale.',
    overbidFormula: null,
    creditorClaimWindow: '4 months from publication of Notice to Creditors',
    homesteadAndSpousalNote: 'Homestead allowance & Lady Bird (Enhanced Life Estate) Deeds widely used.',
    attorneyRule: 'Pro se permitted',
    typicalTimelineMonths: '5–8 mo',
    transferOnDeathDeed: false,
  },
  {
    stateCode: 'MN',
    stateName: 'Minnesota',
    upcAdopted: 'Full UPC',
    independentAuthority: 'Informal Unsupervised Probate',
    courtConfirmationRule: 'Not required under Informal Probate; Formal Unsupervised grants full power of sale.',
    overbidFormula: null,
    creditorClaimWindow: '4 months from notice publication',
    homesteadAndSpousalNote: 'Strong spousal homestead descent rules; Transfer-on-Death Deeds common.',
    attorneyRule: 'Pro se permitted for Informal; title insurers prefer counsel',
    typicalTimelineMonths: '4–8 mo',
    transferOnDeathDeed: true,
  },
  {
    stateCode: 'MS',
    stateName: 'Mississippi',
    upcAdopted: 'Non-UPC',
    independentAuthority: 'Will Power of Sale / Chancery Decree',
    courtConfirmationRule: 'Chancery Court decree required unless Will explicitly waives court sale approval.',
    overbidFormula: null,
    creditorClaimWindow: '90 days from first publication to creditors',
    homesteadAndSpousalNote: 'Surviving spouse homestead occupancy right overrides partition/sale.',
    attorneyRule: 'Mississippi attorney required in Chancery Court',
    typicalTimelineMonths: '6–10 mo',
    transferOnDeathDeed: true,
  },
  {
    stateCode: 'MO',
    stateName: 'Missouri',
    upcAdopted: 'Non-UPC',
    independentAuthority: 'Independent Administration (RSMo § 473.780)',
    courtConfirmationRule: 'Independent PR sells without court order; Supervised PR requires Court Order & 75% appraisal floor.',
    overbidFormula: null,
    creditorClaimWindow: '6 months from first publication of Letters',
    homesteadAndSpousalNote: 'Beneficiary Deeds widely used; spousal marital rights release required.',
    attorneyRule: 'Missouri attorney required for full probate administration',
    typicalTimelineMonths: '6–10 mo',
    transferOnDeathDeed: true,
  },
  {
    stateCode: 'MT',
    stateName: 'Montana',
    upcAdopted: 'Full UPC',
    independentAuthority: 'Informal Probate',
    courtConfirmationRule: 'Not required under Informal Unsupervised Administration.',
    overbidFormula: null,
    creditorClaimWindow: '4 months from first publication',
    homesteadAndSpousalNote: 'UPC Homestead Allowance ($20,000) & Transfer-on-Death Deeds.',
    attorneyRule: 'Pro se permitted',
    typicalTimelineMonths: '4–8 mo',
    transferOnDeathDeed: true,
  },
  {
    stateCode: 'NE',
    stateName: 'Nebraska',
    upcAdopted: 'Full UPC',
    independentAuthority: 'Informal Probate (Neb. Rev. Stat. § 30-2414)',
    courtConfirmationRule: 'Informal PR sells privately without court confirmation.',
    overbidFormula: null,
    creditorClaimWindow: '2 months from first publication',
    homesteadAndSpousalNote: 'Nebraska County Inheritance Tax (1%–15% depending on relationship) creates lien until paid.',
    attorneyRule: 'Attorney typically required for Inheritance Tax determination',
    typicalTimelineMonths: '5–9 mo',
    transferOnDeathDeed: true,
  },
  {
    stateCode: 'NV',
    stateName: 'Nevada',
    upcAdopted: 'Non-UPC',
    independentAuthority: 'Independent Admin (NRS 143.300)',
    courtConfirmationRule: 'Full Independent Authority avoids court confirmation after 15-day Notice of Proposed Action; otherwise court confirmation & 90% appraisal required.',
    overbidFormula: {
      firstBracketCap: 10000,
      firstBracketPct: 0.1,
      remainderPct: 0.05,
      flatAddOn: 0,
      description: 'NRS 148.270: Minimum first overbid = 10% on first $10,000 + 5% of balance when court-confirmed.',
    },
    creditorClaimWindow: '60 days (Summary) or 90 days (General)',
    homesteadAndSpousalNote: 'Community property rules & Deeds Upon Death recognized.',
    attorneyRule: 'Pro se permitted for set-aside/summary; counsel common for general',
    typicalTimelineMonths: '4–9 mo',
    transferOnDeathDeed: true,
  },
  {
    stateCode: 'NH',
    stateName: 'New Hampshire',
    upcAdopted: 'Non-UPC',
    independentAuthority: 'Waiver of Administration / License to Sell',
    courtConfirmationRule: 'Requires Probate Division License to Sell unless Will conveys explicit power or all heirs consent.',
    overbidFormula: null,
    creditorClaimWindow: '6 months from grant of administration',
    homesteadAndSpousalNote: 'Spousal homestead right ($120,000) must be addressed before deed transfer.',
    attorneyRule: 'Pro se permitted',
    typicalTimelineMonths: '6–10 mo',
    transferOnDeathDeed: false,
  },
  {
    stateCode: 'NJ',
    stateName: 'New Jersey',
    upcAdopted: 'Modified UPC',
    independentAuthority: 'Surrogate Probate (Independent Executor)',
    courtConfirmationRule: 'Executor with Will power sells without court order; Administrators require Superior Court order if restricted.',
    overbidFormula: null,
    creditorClaimWindow: '9 months from death (creditor presentation)',
    homesteadAndSpousalNote: 'NJ Transfer Inheritance Tax waiver (Form L-9) required for title insurance on Class C/D heirs.',
    attorneyRule: 'Pro se permitted',
    typicalTimelineMonths: '6–10 mo',
    transferOnDeathDeed: false,
  },
  {
    stateCode: 'NM',
    stateName: 'New Mexico',
    upcAdopted: 'Full UPC',
    independentAuthority: 'Informal Probate (NMSA § 45-3-301)',
    courtConfirmationRule: 'Not required under Informal Administration.',
    overbidFormula: null,
    creditorClaimWindow: '4 months from first published notice (1 year max)',
    homesteadAndSpousalNote: 'Community property state; Transfer-on-Death Deeds widely used.',
    attorneyRule: 'Pro se permitted',
    typicalTimelineMonths: '4–7 mo',
    transferOnDeathDeed: true,
  },
  {
    stateCode: 'NY',
    stateName: 'New York',
    upcAdopted: 'Non-UPC',
    independentAuthority: 'Surrogate’s Court Letters Testamentary',
    courtConfirmationRule: 'Executor with Will power sells freely; Administrators often hold real-estate restriction requiring SCPA Art. 19 order.',
    overbidFormula: null,
    creditorClaimWindow: '7 months from issuance of Letters',
    homesteadAndSpousalNote: 'NY Estate Tax lien check (ET-117 / ET-30) & strict heir kinship rules in intestacy.',
    attorneyRule: 'NY estate attorney standard for Surrogate’s Court & title closing',
    typicalTimelineMonths: '8–15 mo',
    transferOnDeathDeed: true,
  },
  {
    stateCode: 'NC',
    stateName: 'North Carolina',
    upcAdopted: 'Non-UPC',
    independentAuthority: 'Will Power of Sale / Clerk Special Proceeding',
    courtConfirmationRule: 'Title vests in heirs at death; Special Proceeding & 10-day upset bid required if sold to pay debts without Will power.',
    overbidFormula: {
      firstBracketCap: 0,
      firstBracketPct: 0,
      remainderPct: 0.05,
      flatAddOn: 750,
      description: 'N.C.G.S. § 1-339.36: Upset bid requires greater of 5% or $750 within 10-day window.',
    },
    creditorClaimWindow: '90 days from first Notice to Creditors publication',
    homesteadAndSpousalNote: 'PR must join with heirs/devisees within 2 years of death for insurable title.',
    attorneyRule: 'NC closing attorney required for title conveyance',
    typicalTimelineMonths: '6–9 mo',
    transferOnDeathDeed: false,
  },
  {
    stateCode: 'ND',
    stateName: 'North Dakota',
    upcAdopted: 'Full UPC',
    independentAuthority: 'Informal Unsupervised Probate',
    courtConfirmationRule: 'Not required under Informal Probate.',
    overbidFormula: null,
    creditorClaimWindow: '3 months from first publication',
    homesteadAndSpousalNote: 'UPC Homestead Allowance & Transfer-on-Death Deeds.',
    attorneyRule: 'Pro se permitted',
    typicalTimelineMonths: '4–7 mo',
    transferOnDeathDeed: true,
  },
  {
    stateCode: 'OH',
    stateName: 'Ohio',
    upcAdopted: 'Non-UPC',
    independentAuthority: 'Will Power of Sale / Consent to Sell',
    courtConfirmationRule: 'Land Sale Proceeding required unless Will grants power of sale or all heirs sign Consent to Power to Sell Real Estate.',
    overbidFormula: null,
    creditorClaimWindow: '6 months from date of death',
    homesteadAndSpousalNote: 'Statutory Dower interest must be released; Transfer-on-Death Designation Affidavits very common.',
    attorneyRule: 'Ohio probate counsel generally required by local Probate Courts',
    typicalTimelineMonths: '6–10 mo',
    transferOnDeathDeed: true,
  },
  {
    stateCode: 'OK',
    stateName: 'Oklahoma',
    upcAdopted: 'Non-UPC',
    independentAuthority: 'Summary / General Administration',
    courtConfirmationRule: 'Court Confirmation & 90% appraisal floor required unless Will grants power of sale or consents under 58 O.S. § 239.',
    overbidFormula: {
      firstBracketCap: 0,
      firstBracketPct: 0,
      remainderPct: 0.1,
      flatAddOn: 0,
      description: '58 O.S. § 426: Court may accept 10% higher written bid at confirmation hearing.',
    },
    creditorClaimWindow: '2 months from Notice to Creditors',
    homesteadAndSpousalNote: 'Constitutional surviving spouse probate homestead right.',
    attorneyRule: 'Oklahoma attorney standard for District Court probate',
    typicalTimelineMonths: '4–8 mo',
    transferOnDeathDeed: true,
  },
  {
    stateCode: 'OR',
    stateName: 'Oregon',
    upcAdopted: 'Non-UPC',
    independentAuthority: 'Will Power of Sale / Court Order',
    courtConfirmationRule: 'Court order required unless Will explicitly authorizes sale without court order.',
    overbidFormula: null,
    creditorClaimWindow: '4 months from first Notice to Interested Persons',
    homesteadAndSpousalNote: 'Small Estate Affidavit supports real property up to $200,000.',
    attorneyRule: 'Oregon counsel standard',
    typicalTimelineMonths: '5–9 mo',
    transferOnDeathDeed: true,
  },
  {
    stateCode: 'PA',
    stateName: 'Pennsylvania',
    upcAdopted: 'Modified UPC',
    independentAuthority: 'Register of Wills — Broad PR Sale Power',
    courtConfirmationRule: 'PR generally holds statutory power to sell real estate without Orphans’ Court approval unless restricted in Will.',
    overbidFormula: null,
    creditorClaimWindow: '1 year from grant of Letters advertisement',
    homesteadAndSpousalNote: 'PA Inheritance Tax (4.5% lineal, 12% siblings, 15% others) lien clearance required at closing.',
    attorneyRule: 'Pro se permitted; counsel recommended for inheritance tax return (REV-1500)',
    typicalTimelineMonths: '6–12 mo',
    transferOnDeathDeed: false,
  },
  {
    stateCode: 'RI',
    stateName: 'Rhode Island',
    upcAdopted: 'Non-UPC',
    independentAuthority: 'Probate Court Petition to Sell',
    courtConfirmationRule: 'Probate Court authorization required unless Will grants explicit power to sell.',
    overbidFormula: null,
    creditorClaimWindow: '6 months from first publication',
    homesteadAndSpousalNote: 'RI Estate Tax lien waiver (T-77) required on all estate realty transfers.',
    attorneyRule: 'Counsel recommended',
    typicalTimelineMonths: '6–10 mo',
    transferOnDeathDeed: false,
  },
  {
    stateCode: 'SC',
    stateName: 'South Carolina',
    upcAdopted: 'Full UPC',
    independentAuthority: 'Informal Probate (S.C. Code § 62-3-715)',
    courtConfirmationRule: 'Informal PR sells unless Will/court restricts; intestate realty may require deed of distribution or court order.',
    overbidFormula: null,
    creditorClaimWindow: '8 months from publication (or 1 year from death)',
    homesteadAndSpousalNote: 'Spousal elective share (1/3) & SC deed recording requirements.',
    attorneyRule: 'SC licensed closing attorney REQUIRED for real estate closings',
    typicalTimelineMonths: '6–10 mo',
    transferOnDeathDeed: false,
  },
  {
    stateCode: 'SD',
    stateName: 'South Dakota',
    upcAdopted: 'Full UPC',
    independentAuthority: 'Informal Unsupervised Probate',
    courtConfirmationRule: 'Not required under Informal Administration.',
    overbidFormula: null,
    creditorClaimWindow: '4 months from first publication',
    homesteadAndSpousalNote: 'Transfer-on-Death Deeds recognized; no state inheritance tax.',
    attorneyRule: 'Pro se permitted',
    typicalTimelineMonths: '4–7 mo',
    transferOnDeathDeed: true,
  },
  {
    stateCode: 'TN',
    stateName: 'Tennessee',
    upcAdopted: 'Non-UPC',
    independentAuthority: 'Will Power of Sale / Muniment of Title',
    courtConfirmationRule: 'Title vests in heirs at death; court order required only if selling to pay estate debts without Will power.',
    overbidFormula: null,
    creditorClaimWindow: '4 months from first publication (12 months max)',
    homesteadAndSpousalNote: 'Year’s Support & elective share review; Muniment of Title transfers realty fast.',
    attorneyRule: 'Tennessee attorney standard for Chancery/Probate Court',
    typicalTimelineMonths: '5–9 mo',
    transferOnDeathDeed: false,
  },
  {
    stateCode: 'TX',
    stateName: 'Texas',
    upcAdopted: 'Non-UPC',
    independentAuthority: 'Independent Administration (Tex. Est. Code § 401)',
    courtConfirmationRule: 'Not required under Independent Administration. Dependent Administration requires Order of Sale, 10-day return, and Court Confirmation.',
    overbidFormula: null,
    creditorClaimWindow: '4 months from permissive creditor notice',
    homesteadAndSpousalNote: 'Strong Texas Constitutional Homestead shields surviving spouse/minor children; Muniment of Title available.',
    attorneyRule: 'Texas attorney required unless sole beneficiary/pro se local exception applies',
    typicalTimelineMonths: '3–6 mo (Independent) · 9–14 mo (Dependent)',
    transferOnDeathDeed: true,
  },
  {
    stateCode: 'UT',
    stateName: 'Utah',
    upcAdopted: 'Full UPC',
    independentAuthority: 'Informal Probate (Utah Code § 75-3-301)',
    courtConfirmationRule: 'Not required under Informal Unsupervised Administration.',
    overbidFormula: null,
    creditorClaimWindow: '3 months from first Notice to Creditors',
    homesteadAndSpousalNote: 'UPC Homestead Allowance ($22,500) & Transfer-on-Death Deeds.',
    attorneyRule: 'Pro se permitted',
    typicalTimelineMonths: '4–6 mo',
    transferOnDeathDeed: true,
  },
  {
    stateCode: 'VT',
    stateName: 'Vermont',
    upcAdopted: 'Non-UPC',
    independentAuthority: 'Probate Division License to Sell',
    courtConfirmationRule: 'License to Sell required from Probate Division unless Will grants power and heirs/creditors protected.',
    overbidFormula: null,
    creditorClaimWindow: '4 months from first publication',
    homesteadAndSpousalNote: 'Spousal homestead right ($125,000) & VT estate tax clearance.',
    attorneyRule: 'Pro se permitted; counsel helpful for License to Sell',
    typicalTimelineMonths: '6–10 mo',
    transferOnDeathDeed: false,
  },
  {
    stateCode: 'VA',
    stateName: 'Virginia',
    upcAdopted: 'Non-UPC',
    independentAuthority: 'Clerk of Circuit Court Qualification',
    courtConfirmationRule: 'Title passes directly to heirs/devisees at death; Will power allows Executor sale, otherwise heirs sign deed (within 1 yr creditor lien window).',
    overbidFormula: null,
    creditorClaimWindow: '1 year from death (bond/creditor lien period)',
    homesteadAndSpousalNote: 'Title companies require escrow/bond if closing within 1 year of death.',
    attorneyRule: 'Pro se permitted; settlement attorney/agent required for closing',
    typicalTimelineMonths: '4–9 mo',
    transferOnDeathDeed: true,
  },
  {
    stateCode: 'WA',
    stateName: 'Washington',
    upcAdopted: 'Non-UPC',
    independentAuthority: 'Nonintervention Probate (RCW 11.68)',
    courtConfirmationRule: 'Not required with Nonintervention Powers — PR sells like an independent owner.',
    overbidFormula: null,
    creditorClaimWindow: '4 months from first publication',
    homesteadAndSpousalNote: 'Community property state; Transfer-on-Death Deeds & Lack-of-Probate Affidavits common.',
    attorneyRule: 'Pro se permitted',
    typicalTimelineMonths: '4–7 mo',
    transferOnDeathDeed: true,
  },
  {
    stateCode: 'WV',
    stateName: 'West Virginia',
    upcAdopted: 'Non-UPC',
    independentAuthority: 'County Commission Fiduciary Supervisor',
    courtConfirmationRule: 'Will power permits Executor sale; intestate realty vests in heirs directly unless sold for debts.',
    overbidFormula: null,
    creditorClaimWindow: '60 days (short form) or 6 months notice to creditors',
    homesteadAndSpousalNote: 'Transfer-on-Death Deeds recognized.',
    attorneyRule: 'Pro se permitted',
    typicalTimelineMonths: '5–9 mo',
    transferOnDeathDeed: true,
  },
  {
    stateCode: 'WI',
    stateName: 'Wisconsin',
    upcAdopted: 'Modified UPC',
    independentAuthority: 'Informal Administration (Probate Registrar)',
    courtConfirmationRule: 'Not required under Informal Administration unless restricted.',
    overbidFormula: null,
    creditorClaimWindow: '3–4 months set by Registrar notice',
    homesteadAndSpousalNote: 'Marital property state; Transfer-on-Death Deeds widely used.',
    attorneyRule: 'Pro se permitted for Informal Administration',
    typicalTimelineMonths: '4–8 mo',
    transferOnDeathDeed: true,
  },
  {
    stateCode: 'WY',
    stateName: 'Wyoming',
    upcAdopted: 'Non-UPC',
    independentAuthority: 'District Court Probate / Summary Distribution',
    courtConfirmationRule: 'Court order & 90% appraisal confirmation required unless Will grants express power of sale.',
    overbidFormula: null,
    creditorClaimWindow: '3 months from first publication',
    homesteadAndSpousalNote: 'Summary real property distribution available for estates <= $200,000.',
    attorneyRule: 'Wyoming attorney standard for District Court',
    typicalTimelineMonths: '5–8 mo',
    transferOnDeathDeed: true,
  },
];

export function getStateProbateStatute(stateCode: string): StateProbateStatute {
  const code = stateCode.trim().toUpperCase();
  return (
    US_STATE_PROBATE_RULES.find((s) => s.stateCode === code) ??
    US_STATE_PROBATE_RULES.find((s) => s.stateCode === 'TX')!
  );
}

export function calculateMinimumOverbidPrice(
  acceptedOffer: number,
  formula: OverbidFormula | null
): {
  minimumNextBid: number;
  requiredIncrement: number;
  formulaSummary: string;
} {
  const safeOffer = Math.max(0, Math.round(acceptedOffer));
  if (!formula || safeOffer === 0) {
    return {
      minimumNextBid: safeOffer,
      requiredIncrement: 0,
      formulaSummary: formula?.description ?? 'No statutory court overbid formula applies under independent authority.',
    };
  }

  let increment = 0;
  if (formula.firstBracketCap > 0) {
    const firstSlice = Math.min(safeOffer, formula.firstBracketCap);
    const remainder = Math.max(0, safeOffer - formula.firstBracketCap);
    increment = Math.round(firstSlice * formula.firstBracketPct + remainder * formula.remainderPct);
  } else {
    const pctIncrement = Math.round(safeOffer * formula.remainderPct);
    increment = Math.max(formula.flatAddOn, pctIncrement);
  }

  return {
    minimumNextBid: safeOffer + increment,
    requiredIncrement: increment,
    formulaSummary: formula.description,
  };
}

export interface FederalComplianceInput {
  offerAmount: number;
  propertyType: CrmDeal['property']['propertyType'];
  sellerIsForeignEstateOrHeir: boolean;
  buyerIntendsPrimaryResidence: boolean;
  wholesaleAssignmentPlanned: boolean;
  outreachChannel: 'Direct Mail' | 'Manual Call' | 'Automated SMS / Dialer';
  hasPriorExpressWrittenConsent: boolean;
}

export function evaluateFederalCompliance(
  input: FederalComplianceInput
): FederalComplianceReport {
  const price = Math.max(0, input.offerAmount);
  const isResidential =
    input.propertyType === 'Single-Family' || input.propertyType === 'Multi-Family';

  // FIRPTA (26 U.S.C. § 1445)
  let firptaRatePct = 0;
  let firptaStatus: FederalComplianceCheck['status'] = 'Compliant / Exempt';
  let firptaSeverity: FederalComplianceCheck['severity'] = 'ok';
  let firptaAction = 'Collect standard IRS Non-Foreign Status Affidavit (W-9 / FIRPTA Cert) at closing.';

  if (input.sellerIsForeignEstateOrHeir) {
    if (input.buyerIntendsPrimaryResidence && isResidential && price <= 300000) {
      firptaRatePct = 0;
      firptaStatus = 'Action Required';
      firptaSeverity = 'caution';
      firptaAction =
        'Residential <= $300k buyer-occupancy exemption may reduce withholding to 0%; obtain signed Buyer Residency Affidavit.';
    } else if (input.buyerIntendsPrimaryResidence && isResidential && price <= 1000000) {
      firptaRatePct = 10;
      firptaStatus = 'Action Required';
      firptaSeverity = 'warning';
      firptaAction =
        'Escrow agent must withhold 10% of gross amount realized and remit via IRS Form 8288 within 20 days of closing.';
    } else {
      firptaRatePct = 15;
      firptaStatus = 'Action Required';
      firptaSeverity = 'warning';
      firptaAction =
        'Escrow agent must withhold 15% of gross amount realized under 26 U.S.C. § 1445 (IRS Form 8288 / 8288-A).';
    }
  }
  const firptaWithholdingEstimate = Math.round(price * (firptaRatePct / 100));

  // RESPA (12 U.S.C. § 2601) & Wholesale Transparency
  const respaCheck: FederalComplianceCheck = input.wholesaleAssignmentPlanned
    ? {
        id: 'respa',
        statute: 'RESPA (12 U.S.C. § 2601) & State Disclosure',
        title: 'Settlement Transparency & Assignment Audit',
        status: 'Action Required',
        severity: 'caution',
        summary:
          'Wholesale assignment or fee-splitting requires transparent HUD-1/ALTA settlement line-item disclosure and zero unearned title/settlement kickbacks (RESPA § 8).',
        requiredAction:
          'Disclose buyer assignment right in writing to Personal Representative & verify state licensing limits on marketing equitable interest.',
      }
    : {
        id: 'respa',
        statute: 'RESPA (12 U.S.C. § 2601)',
        title: 'Settlement & Anti-Kickback Compliance',
        status: 'Compliant / Exempt',
        severity: 'ok',
        summary:
          'Direct acquisition with transparent ALTA settlement statement and no affiliated title/escrow kickback.',
        requiredAction:
          'Deliver written Good-Faith Closing Cost Breakdown and allow PR independent choice of title company.',
      };

  // TCPA (47 U.S.C. § 227) & National DNC
  let tcpaCheck: FederalComplianceCheck;
  let tcpaConsentRequired = false;
  if (input.outreachChannel === 'Direct Mail') {
    tcpaCheck = {
      id: 'tcpa',
      statute: 'TCPA (47 U.S.C. § 227) & USPS Mail',
      title: 'Outreach Channel Safety — Certified Direct Mail',
      status: 'Compliant / Exempt',
      severity: 'ok',
      summary:
        'Physical USPS direct mail to the Executor/PR mailing address is exempt from TCPA autodialer/SMS consent restrictions.',
      requiredAction:
        'Use accurate return address, clear opt-out instructions, and compassionate non-deceptive probate copy.',
    };
  } else if (input.outreachChannel === 'Manual Call') {
    tcpaCheck = {
      id: 'tcpa',
      statute: 'TCPA & National DNC (16 C.F.R. § 310)',
      title: 'Manual Voice Call DNC Scrub',
      status: 'Action Required',
      severity: 'caution',
      summary:
        'Manual one-to-one dialing avoids ATDS penalties but still requires National/State DNC scrubbing and 8:00 AM–9:00 PM local time calling hours.',
      requiredAction:
        'Scrub PR phone against National DNC Registry before dialing and honor immediate verbal opt-out.',
    };
  } else {
    tcpaConsentRequired = !input.hasPriorExpressWrittenConsent;
    tcpaCheck = input.hasPriorExpressWrittenConsent
      ? {
          id: 'tcpa',
          statute: 'TCPA (47 U.S.C. § 227)',
          title: 'Automated SMS / Dialer Consent Verified',
          status: 'Compliant / Exempt',
          severity: 'ok',
          summary: 'Prior Express Written Consent (PEWC) recorded on file.',
          requiredAction: 'Include clear STOP opt-out footer on every automated SMS.',
        }
      : {
          id: 'tcpa',
          statute: 'TCPA (47 U.S.C. § 227)',
          title: 'Automated SMS / Dialer Blocked — Missing PEWC',
          status: 'High Risk — Verify Consent',
          severity: 'warning',
          summary:
            'Sending automated SMS or AI/pre-recorded calls to skip-traced probate numbers without Prior Express Written Consent carries $500–$1,500 statutory liability per text/call.',
          requiredAction:
            'Switch to Direct Mail or Manual DNC-scrubbed Call unless PEWC was captured.',
        };
  }

  // Fair Housing Act (42 U.S.C. § 3604)
  const fairHousingCheck: FederalComplianceCheck = {
    id: 'fair-housing',
    statute: 'Fair Housing Act (42 U.S.C. § 3604) & ECOA',
    title: 'Neutral Valuation & Non-Discriminatory Outreach',
    status: 'Compliant / Exempt',
    severity: 'ok',
    summary:
      'Underwriting relies strictly on objective parcel comps, physical condition, debt, and statutory probate carry costs.',
    requiredAction:
      'Avoid protected-class references in mailers, notes, or resale marketing copy.',
  };

  return {
    firptaWithholdingEstimate,
    firptaRatePct,
    tcpaConsentRequired,
    respaWholesaleFlag: input.wholesaleAssignmentPlanned,
    checks: [
      {
        id: 'firpta',
        statute: 'FIRPTA (26 U.S.C. § 1445)',
        title: 'Foreign Decedent / Estate Tax Withholding',
        status: firptaStatus,
        severity: firptaSeverity,
        summary: input.sellerIsForeignEstateOrHeir
          ? `Foreign estate/heir flag active: estimated ${firptaRatePct}% IRS withholding ($${firptaWithholdingEstimate.toLocaleString()}).`
          : 'Domestic US decedent/estate presumed; verify via standard Non-Foreign Status Affidavit at title.',
        requiredAction: firptaAction,
      },
      respaCheck,
      tcpaCheck,
      fairHousingCheck,
    ],
  };
}
