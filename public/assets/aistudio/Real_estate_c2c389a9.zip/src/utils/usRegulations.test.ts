import test from 'node:test';
import assert from 'node:assert/strict';
import {
  US_STATE_PROBATE_RULES,
  calculateMinimumOverbidPrice,
  evaluateFederalCompliance,
  getStateProbateStatute,
} from './usRegulations';

test('US_STATE_PROBATE_RULES covers all 50 US states plus District of Columbia (51 jurisdictions)', () => {
  assert.equal(US_STATE_PROBATE_RULES.length, 51);
  const codes = new Set(US_STATE_PROBATE_RULES.map((s) => s.stateCode));
  assert.equal(codes.size, 51);
  assert.ok(codes.has('CA'));
  assert.ok(codes.has('TX'));
  assert.ok(codes.has('FL'));
  assert.ok(codes.has('NY'));
  assert.ok(codes.has('DC'));
});

test('calculateMinimumOverbidPrice computes California Prob. Code §10311 overbid accurately', () => {
  const ca = getStateProbateStatute('CA');
  const res = calculateMinimumOverbidPrice(500000, ca.overbidFormula);
  // 10% of first $10,000 ($1,000) + 5% of remaining $490,000 ($24,500) = $25,500 increment -> $525,500
  assert.equal(res.requiredIncrement, 25500);
  assert.equal(res.minimumNextBid, 525500);
});

test('calculateMinimumOverbidPrice returns zero increment for Texas Independent Administration', () => {
  const tx = getStateProbateStatute('TX');
  const res = calculateMinimumOverbidPrice(350000, tx.overbidFormula);
  assert.equal(res.requiredIncrement, 0);
  assert.equal(res.minimumNextBid, 350000);
});

test('evaluateFederalCompliance computes FIRPTA withholding tiers, RESPA wholesale notice, and TCPA blocks', () => {
  const foreignHigh = evaluateFederalCompliance({
    offerAmount: 450000,
    propertyType: 'Single-Family',
    sellerIsForeignEstateOrHeir: true,
    buyerIntendsPrimaryResidence: true,
    wholesaleAssignmentPlanned: true,
    outreachChannel: 'Automated SMS / Dialer',
    hasPriorExpressWrittenConsent: false,
  });

  // Residential <= $1M with buyer primary residence -> 10% FIRPTA ($45,000)
  assert.equal(foreignHigh.firptaRatePct, 10);
  assert.equal(foreignHigh.firptaWithholdingEstimate, 45000);
  assert.equal(foreignHigh.tcpaConsentRequired, true);
  assert.equal(foreignHigh.respaWholesaleFlag, true);

  const safeDirectMail = evaluateFederalCompliance({
    offerAmount: 450000,
    propertyType: 'Single-Family',
    sellerIsForeignEstateOrHeir: false,
    buyerIntendsPrimaryResidence: false,
    wholesaleAssignmentPlanned: false,
    outreachChannel: 'Direct Mail',
    hasPriorExpressWrittenConsent: false,
  });

  assert.equal(safeDirectMail.firptaWithholdingEstimate, 0);
  assert.equal(safeDirectMail.tcpaConsentRequired, false);
});
