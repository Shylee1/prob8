import test from 'node:test';
import assert from 'node:assert/strict';
import { SEED_DEALS } from '../data/seedData';
import {
  analyzeStakeholderHierarchy,
  auditValuationConfidence,
  buildPropertyMarketIntelligence,
  buildZillowAndRedfinUrls,
  calculateCurrentProbatePricing,
  calculateDealStrategies,
  generateCompassionateOutreach,
} from './valuationAndIntegrations';

test('buildZillowAndRedfinUrls encodes property address into valid Zillow and Redfin links', () => {
  const deal = SEED_DEALS[0];
  const urls = buildZillowAndRedfinUrls(deal);
  assert.ok(urls.zillowUrl.startsWith('https://www.zillow.com/homes/'));
  assert.ok(urls.redfinUrl.startsWith('https://www.redfin.com/stingray/do/query-location?location='));
  assert.ok(urls.zillowUrl.includes('Meadowbrook'));
});

test('buildPropertyMarketIntelligence derives Zestimate, Redfin Estimate, comps, and MAO', () => {
  const deal = SEED_DEALS[0];
  const intel = buildPropertyMarketIntelligence(deal);
  assert.ok(intel.zillowZestimate >= deal.property.assessedValue);
  assert.ok(intel.redfinEstimate >= deal.property.assessedValue);
  assert.ok(intel.zillowLow < intel.zillowZestimate && intel.zillowZestimate < intel.zillowHigh);
  assert.equal(intel.comps.length, 3);
  assert.ok(intel.recommendedMao > 0);
});

test('calculateCurrentProbatePricing applies statutory graduated schedule for FL vs TX', () => {
  const fl = calculateCurrentProbatePricing('fl-miamidade', 500000, 50000);
  const tx = calculateCurrentProbatePricing('tx-harris', 500000, 50000);

  // Florida §733.6171 statutory attorney fee (3% of $500k = $15,000) exceeds TX independent typical flat/hourly
  assert.equal(fl.attorneyFeeEstimate, 15000);
  assert.ok(tx.attorneyFeeEstimate < fl.attorneyFeeEstimate);
  assert.equal(fl.filingFee, 401);
  assert.equal(tx.filingFee, 360);
  assert.ok(fl.totalProbateCarryCost > fl.attorneyFeeEstimate);
});

test('calculateDealStrategies computes Flip Profit, Rental Cap Rate/DSCR, and Seller Financing', () => {
  const deal = SEED_DEALS[0];
  const strategies = calculateDealStrategies(deal, 25000, {
    downPaymentPct: 20,
    interestRatePct: 5.0,
    termYears: 20,
  });
  assert.ok(strategies.blendedArv > deal.offerAmount);
  assert.ok(strategies.annualCapRatePct > 0);
  assert.ok(strategies.dscrRatio > 0);
  assert.ok(strategies.sellerMonthlyPayment > 0);
  assert.ok(strategies.sellerTotalInterestEarned > 0);
});

test('auditValuationConfidence flags spread between assessor and AVM estimates', () => {
  const deal = SEED_DEALS[0];
  const audit = auditValuationConfidence(deal, 495000, 480000);
  assert.ok(audit.spreadPct > 15);
  assert.equal(audit.confidenceLabel, 'Verify Local Comps');
  assert.equal(audit.requiresFieldInspection, true);
});

test('analyzeStakeholderHierarchy detects out-of-state PR and generates empathetic outreach', () => {
  // SEED_DEALS[0] has PR Clara Pendelton in Denver, CO for a Houston, TX property
  const hierarchy = analyzeStakeholderHierarchy(SEED_DEALS[0]);
  assert.equal(hierarchy.outOfStatePr, true);
  assert.equal(hierarchy.prStateCode, 'CO');
  assert.equal(hierarchy.contactReadiness, 'Verified PR Direct');

  const msg = generateCompassionateOutreach(
    SEED_DEALS[0],
    'out-of-state-relief',
    'Oakline Estate Acquisitions LLC',
    295000
  );
  assert.ok(msg.subject.includes('Meadowbrook'));
  assert.ok(msg.body.includes('Denver') || msg.body.includes('out of state'));
});

