import type {
  AdminType,
  BuyerProfile,
  CrmDeal,
  DealStage,
  DiscoverFilters,
  ExtractedDocketData,
  Jurisdiction,
  PropertyType,
} from '../types/caselot';
import { DEAL_STAGES } from '../types/caselot';

export function calculateEstimatedEquity(assessedValue: number, estimatedDebt: number): number {
  const safeValue = Number.isFinite(assessedValue) ? Math.max(0, assessedValue) : 0;
  const safeDebt = Number.isFinite(estimatedDebt) ? Math.max(0, estimatedDebt) : 0;
  return Math.max(0, safeValue - safeDebt);
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0,
  }).format(Number.isFinite(amount) ? amount : 0);
}

export function hasActiveSearchFilters(filters: DiscoverFilters): boolean {
  return (
    filters.stateCode !== 'ALL' ||
    filters.countyName !== 'ALL' ||
    filters.filingWindowDays > 0 ||
    filters.propertyType !== 'All' ||
    filters.minEquity > 0 ||
    filters.attorneyStatus !== 'all' ||
    filters.adminType !== 'all' ||
    filters.searchQuery.trim().length > 0
  );
}

export function filterProbateDeals(
  deals: CrmDeal[],
  filters: DiscoverFilters,
  referenceDateIso = '2026-11-13'
): CrmDeal[] {
  const refTime = new Date(referenceDateIso).getTime();
  const query = filters.searchQuery.trim().toLowerCase();

  return deals.filter((deal) => {
    if (filters.stateCode !== 'ALL' && deal.property.stateCode !== filters.stateCode) {
      return false;
    }
    if (filters.countyName !== 'ALL' && deal.property.countyName !== filters.countyName) {
      return false;
    }
    if (filters.propertyType !== 'All' && deal.property.propertyType !== filters.propertyType) {
      return false;
    }
    if (filters.adminType !== 'all' && deal.probateCase.adminType !== filters.adminType) {
      return false;
    }
    if (filters.attorneyStatus === 'no-attorney' && deal.probateCase.hasAttorney) {
      return false;
    }
    if (filters.attorneyStatus === 'represented' && !deal.probateCase.hasAttorney) {
      return false;
    }

    const equity = calculateEstimatedEquity(deal.property.assessedValue, deal.property.estimatedDebt);
    if (equity < filters.minEquity) {
      return false;
    }

    if (filters.filingWindowDays > 0) {
      const filingTime = new Date(deal.probateCase.filingDate).getTime();
      const diffDays = (refTime - filingTime) / (1000 * 60 * 60 * 24);
      if (diffDays > filters.filingWindowDays) {
        return false;
      }
    }

    if (query.length > 0) {
      const haystack = [
        deal.probateCase.caseNumber,
        deal.probateCase.decedentName,
        deal.probateCase.aiSummary,
        deal.probateCase.adminType,
        deal.property.address,
        deal.property.city,
        deal.property.countyName,
        deal.property.stateCode,
        deal.property.zip,
        deal.property.parcelId,
        ...deal.stakeholders.map((s) => s.fullName),
      ]
        .join(' ')
        .toLowerCase();

      // Match all significant query tokens if user types keywords
      const tokens = query
        .split(/\s+/)
        .filter((t) => t.length > 1 && !['in', 'with', 'and', 'or', 'the', 'show', 'me', 'cases', 'properties'].includes(t));

      if (tokens.length > 0 && !tokens.every((token) => haystack.includes(token))) {
        return false;
      }
    }

    return true;
  });
}

export function parseNaturalLanguageQueryFallback(nlQuery: string): Partial<DiscoverFilters> {
  const lower = nlQuery.toLowerCase();
  const patch: Partial<DiscoverFilters> = {};

  if (lower.includes('harris')) {
    patch.stateCode = 'TX';
    patch.countyName = 'Harris';
  } else if (lower.includes('travis') || lower.includes('austin')) {
    patch.stateCode = 'TX';
    patch.countyName = 'Travis';
  } else if (lower.includes('maricopa') || lower.includes('phoenix')) {
    patch.stateCode = 'AZ';
    patch.countyName = 'Maricopa';
  } else if (lower.includes('miami') || lower.includes('dade')) {
    patch.stateCode = 'FL';
    patch.countyName = 'Miami-Dade';
  } else if (lower.includes('cook') || lower.includes('chicago')) {
    patch.stateCode = 'IL';
    patch.countyName = 'Cook';
  } else if (lower.includes('fulton') || lower.includes('atlanta')) {
    patch.stateCode = 'GA';
    patch.countyName = 'Fulton';
  } else if (lower.includes('texas') || /\btx\b/.test(lower)) {
    patch.stateCode = 'TX';
  } else if (lower.includes('florida') || /\bfl\b/.test(lower)) {
    patch.stateCode = 'FL';
  } else if (lower.includes('arizona') || /\baz\b/.test(lower)) {
    patch.stateCode = 'AZ';
  } else if (lower.includes('illinois') || /\bil\b/.test(lower)) {
    patch.stateCode = 'IL';
  } else if (lower.includes('georgia') || /\bga\b/.test(lower)) {
    patch.stateCode = 'GA';
  } else if (lower.includes('california') || /\bca\b/.test(lower)) {
    patch.stateCode = 'CA';
  } else if (lower.includes('new york') || /\bny\b/.test(lower)) {
    patch.stateCode = 'NY';
  } else if (lower.includes('ohio') || /\boh\b/.test(lower)) {
    patch.stateCode = 'OH';
  } else if (lower.includes('north carolina') || /\bnc\b/.test(lower)) {
    patch.stateCode = 'NC';
  }

  if (lower.includes('independent')) {
    patch.adminType = 'Independent';
  } else if (lower.includes('dependent') || lower.includes('supervised')) {
    patch.adminType = 'Dependent / Supervised';
  } else if (lower.includes('informal')) {
    patch.adminType = 'Informal';
  } else if (lower.includes('summary')) {
    patch.adminType = 'Summary';
  }

  if (lower.includes('no attorney') || lower.includes('without attorney') || lower.includes('pro se') || lower.includes('unrepresented')) {
    patch.attorneyStatus = 'no-attorney';
  } else if (lower.includes('with attorney') || lower.includes('represented')) {
    patch.attorneyStatus = 'represented';
  }

  if (lower.includes('single-family') || lower.includes('single family') || lower.includes('home') || lower.includes('house') || lower.includes('residential')) {
    patch.propertyType = 'Single-Family';
  } else if (lower.includes('multi-family') || lower.includes('duplex') || lower.includes('apartment')) {
    patch.propertyType = 'Multi-Family';
  } else if (lower.includes('land') || lower.includes('lot') || lower.includes('vacant')) {
    patch.propertyType = 'Land / Lot';
  } else if (lower.includes('commercial')) {
    patch.propertyType = 'Commercial';
  }

  const equityMatch = lower.match(/\$?(\d{2,4})\s*k/);
  if (equityMatch) {
    patch.minEquity = Number(equityMatch[1]) * 1000;
  } else if (lower.includes('unencumbered') || lower.includes('free and clear')) {
    patch.minEquity = 150000;
  }

  const daysMatch = lower.match(/last\s+(\d+)\s+days/);
  if (daysMatch) {
    patch.filingWindowDays = Number(daysMatch[1]);
  }

  // Clear raw searchQuery if structured filters were extracted, otherwise keep concise search
  if (Object.keys(patch).length > 0) {
    patch.searchQuery = '';
  } else {
    patch.searchQuery = nlQuery;
  }

  return patch;
}

export function extractDocketFallback(rawText: string): ExtractedDocketData {
  const grab = (pattern: RegExp, fallback = ''): string => {
    const m = rawText.match(pattern);
    return m && m[1] ? m[1].trim() : fallback;
  };

  const decedentName = grab(/(?:Estate of|Decedent:?)\s+([A-Z][A-Za-z\s.'-]+?)(?:\n|,|;|$)/i, 'Estate of Margaret Holloway');
  const dateOfDeath = grab(/(?:Date of Death|DOD):?\s*([0-9]{4}-[0-9]{2}-[0-9]{2}|[A-Za-z]+\s+\d{1,2},\s*\d{4})/i, '2026-08-19');
  const caseNumber = grab(/(?:Case\s*(?:No\.?|Number|#)|Cause\s*No\.?):?\s*([A-Z0-9-]+)/i, `PR-2026-${Math.floor(1000 + (rawText.length % 8999))}`);
  const executorName = grab(/(?:Executor|Personal Representative|Administrator|Applicant):?\s*([A-Z][A-Za-z\s.'-]+?)(?:\n|,|;|$)/i, 'David Holloway');
  const executorAddress = grab(/(?:Executor Address|PR Address|Mailing Address):?\s*([^\n]+)/i, '4120 Westheimer Rd, Houston, TX 77027');
  const probateAttorney = grab(/(?:Attorney|Counsel):?\s*([^\n]+)/i, 'None Listed (Pro Se)');
  const propertyAddress = grab(/(?:Property Address|Real Property|Situs):?\s*([^\n,]+(?:,\s*[^\n]+)?)/i, '1842 Oak Crest Ln');
  const parcelId = grab(/(?:APN|Parcel(?:\s*ID)?):?\s*([A-Z0-9-]+)/i, '064-118-002-0019');

  const valStr = grab(/(?:Assessed Value|Appraised Value|Market Value):?\s*\$?([\d,]+)/i, '345000').replace(/,/g, '');
  const debtStr = grab(/(?:Liens|Debt|Mortgage|Claims):?\s*\$?([\d,]+)/i, '42000').replace(/,/g, '');

  const lower = rawText.toLowerCase();
  let adminType: AdminType = 'Independent';
  if (/\bindependent\b/.test(lower)) adminType = 'Independent';
  else if (/\bdependent\b|\bsupervised\b/.test(lower)) adminType = 'Dependent / Supervised';
  else if (/\binformal\b/.test(lower)) adminType = 'Informal';
  else if (/\bsummary\b/.test(lower)) adminType = 'Summary';

  let propertyType: PropertyType = 'Single-Family';
  if (lower.includes('lot') || lower.includes('vacant land')) propertyType = 'Land / Lot';
  else if (lower.includes('duplex') || lower.includes('multi')) propertyType = 'Multi-Family';
  else if (lower.includes('commercial') || lower.includes('retail')) propertyType = 'Commercial';

  let stateCode = 'TX';
  let countyName = 'Harris';
  let city = 'Houston';
  if (lower.includes('maricopa') || lower.includes('arizona') || lower.includes('phoenix')) {
    stateCode = 'AZ';
    countyName = 'Maricopa';
    city = 'Phoenix';
  } else if (lower.includes('miami') || lower.includes('florida')) {
    stateCode = 'FL';
    countyName = 'Miami-Dade';
    city = 'Miami';
  } else if (lower.includes('travis') || lower.includes('austin')) {
    stateCode = 'TX';
    countyName = 'Travis';
    city = 'Austin';
  } else if (lower.includes('cook') || lower.includes('chicago')) {
    stateCode = 'IL';
    countyName = 'Cook';
    city = 'Chicago';
  }

  return {
    decedentName: decedentName.replace(/^Estate of\s+/i, ''),
    dateOfDeath,
    caseNumber,
    caseType: lower.includes('intestate') ? 'Intestate Administration' : 'Probate of Will & Letters Testamentary',
    adminType,
    probateStage: lower.includes('inventory') ? 'Inventory Filed' : 'Petition Filed',
    executorName,
    executorAddress,
    probateAttorney,
    propertyAddress: propertyAddress.split(',')[0].trim(),
    city,
    stateCode,
    countyName,
    parcelId,
    assessedValue: Number(valStr) || 345000,
    estimatedDebt: Number(debtStr) || 0,
    propertyType,
    aiSummary: `Extracted ${adminType.toLowerCase()} probate filing for ${decedentName} in ${countyName} County, ${stateCode} with matched real property at ${propertyAddress.split(',')[0].trim()}.`,
  };
}

export interface PipelineMetrics {
  totalPipelineDeals: number;
  totalAssessedValue: number;
  totalEstimatedEquity: number;
  courtApprovalCount: number;
  stageCounts: Record<DealStage, number>;
  stageEquity: Record<DealStage, number>;
}

export function computePipelineMetrics(deals: CrmDeal[]): PipelineMetrics {
  const stageCounts = {} as Record<DealStage, number>;
  const stageEquity = {} as Record<DealStage, number>;
  for (const stage of DEAL_STAGES) {
    stageCounts[stage] = 0;
    stageEquity[stage] = 0;
  }

  let totalPipelineDeals = 0;
  let totalAssessedValue = 0;
  let totalEstimatedEquity = 0;
  let courtApprovalCount = 0;

  for (const deal of deals) {
    if (!deal.inPipeline) continue;
    totalPipelineDeals += 1;
    const equity = calculateEstimatedEquity(deal.property.assessedValue, deal.property.estimatedDebt);
    totalAssessedValue += deal.property.assessedValue;
    totalEstimatedEquity += equity;
    stageCounts[deal.stage] = (stageCounts[deal.stage] || 0) + 1;
    stageEquity[deal.stage] = (stageEquity[deal.stage] || 0) + equity;
    if (deal.stage === 'Probate Court Approval') {
      courtApprovalCount += 1;
    }
  }

  return {
    totalPipelineDeals,
    totalAssessedValue,
    totalEstimatedEquity,
    courtApprovalCount,
    stageCounts,
    stageEquity,
  };
}

export interface AutoPopulatedFormFields {
  estateName: string;
  caseNumber: string;
  countyState: string;
  courtSystem: string;
  propertyAddress: string;
  parcelId: string;
  legalDescription: string;
  recipientName: string;
  recipientAddress: string;
  offerAmount: string;
  earnestMoney: string;
  inspectionDays: string;
  closingDays: string;
  buyerEntity: string;
  buyerSigner: string;
  buyerContact: string;
  probateContingencyClause: string;
  federalNotice?: string;
}

export function buildFormFieldMap(
  deal: CrmDeal,
  jurisdiction: Jurisdiction | undefined,
  buyer: BuyerProfile
): AutoPopulatedFormFields {
  const primaryStakeholder =
    deal.stakeholders.find((s) => s.role === 'Executor / PR') ??
    deal.stakeholders[0];

  const courtConf = jurisdiction?.rules.courtConfirmationRequired
    ? 'This Agreement is expressly contingent upon formal probate court confirmation and statutory overbid procedures.'
    : `This Agreement is contingent upon verification of valid Letters Testamentary / Independent Authority in ${deal.property.countyName} County, ${deal.property.stateCode}.`;

  return {
    estateName: `Estate of ${deal.probateCase.decedentName}`,
    caseNumber: deal.probateCase.caseNumber,
    countyState: `${deal.property.countyName} County, ${deal.property.stateCode}`,
    courtSystem: jurisdiction?.courtSystemType ?? 'County Probate Court',
    propertyAddress: `${deal.property.address}, ${deal.property.city}, ${deal.property.stateCode} ${deal.property.zip}`,
    parcelId: deal.property.parcelId,
    legalDescription: deal.property.legalDescription,
    recipientName: primaryStakeholder?.fullName ?? 'Personal Representative',
    recipientAddress: primaryStakeholder?.mailingAddress ?? `${deal.property.city}, ${deal.property.stateCode}`,
    offerAmount: formatCurrency(deal.offerAmount || Math.round(deal.property.assessedValue * 0.78)),
    earnestMoney: formatCurrency(buyer.earnestMoney),
    inspectionDays: `${buyer.inspectionDays} Calendar Days`,
    closingDays: `${buyer.closingDays} Days Post-Clearance`,
    buyerEntity: buyer.entityName,
    buyerSigner: `${buyer.signerName}, ${buyer.signerTitle}`,
    buyerContact: `${buyer.phone} · ${buyer.email}`,
    probateContingencyClause: courtConf,
    federalNotice:
      'US Federal Compliance: Subject to IRS FIRPTA Non-Foreign Status Affidavit (26 U.S.C. § 1445), RESPA ALTA settlement transparency (12 U.S.C. § 2601), and Fair Housing Act neutrality (42 U.S.C. § 3604).',
  };
}
