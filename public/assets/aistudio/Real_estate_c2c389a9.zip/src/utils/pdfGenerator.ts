import { PDFDocument, StandardFonts, rgb } from 'pdf-lib';
import type { AutoPopulatedFormFields } from './probateLogic';
import type { FormTemplate } from '../types/caselot';

export interface GeneratedPdfResult {
  bytes: Uint8Array;
  blobUrl: string;
  fileName: string;
}

function wrapText(text: string, maxChars: number): string[] {
  const words = text.split(/\s+/);
  const lines: string[] = [];
  let current = '';
  for (const word of words) {
    if ((current + ' ' + word).trim().length > maxChars) {
      if (current) lines.push(current);
      current = word;
    } else {
      current = (current + ' ' + word).trim();
    }
  }
  if (current) lines.push(current);
  return lines;
}

export async function generateProbateFormPdf(
  template: FormTemplate,
  fields: AutoPopulatedFormFields
): Promise<GeneratedPdfResult> {
  const doc = await PDFDocument.create();
  const page = doc.addPage([612, 792]); // US Letter
  const { width, height } = page.getSize();

  const fontRegular = await doc.embedFont(StandardFonts.Helvetica);
  const fontBold = await doc.embedFont(StandardFonts.HelveticaBold);
  const fontMono = await doc.embedFont(StandardFonts.Courier);

  const navy = rgb(0.06, 0.09, 0.16);
  const slate = rgb(0.28, 0.33, 0.41);
  const muted = rgb(0.45, 0.5, 0.58);
  const border = rgb(0.84, 0.87, 0.91);
  const bannerBg = rgb(0.95, 0.96, 0.98);

  let y = height - 48;

  // Header bar
  page.drawRectangle({
    x: 42,
    y: y - 42,
    width: width - 84,
    height: 54,
    color: navy,
  });

  page.drawText('CASELOT TRANSACTION PACKET', {
    x: 56,
    y: y - 14,
    size: 8,
    font: fontBold,
    color: rgb(0.75, 0.82, 0.92),
  });

  page.drawText(template.title.toUpperCase(), {
    x: 56,
    y: y - 31,
    size: 13,
    font: fontBold,
    color: rgb(1, 1, 1),
  });

  y -= 64;

  // Metadata strip
  page.drawRectangle({
    x: 42,
    y: y - 36,
    width: width - 84,
    height: 36,
    color: bannerBg,
    borderColor: border,
    borderWidth: 0.75,
  });

  page.drawText(`CASE NO: ${fields.caseNumber}`, {
    x: 54,
    y: y - 15,
    size: 9,
    font: fontMono,
    color: navy,
  });
  page.drawText(`JURISDICTION: ${fields.countyState}`, {
    x: 245,
    y: y - 15,
    size: 9,
    font: fontMono,
    color: navy,
  });
  page.drawText(`ESTATE: ${fields.estateName}`, {
    x: 54,
    y: y - 28,
    size: 9,
    font: fontBold,
    color: slate,
  });

  y -= 58;

  // Section 1: Parties & Property
  const drawSectionHeading = (title: string) => {
    page.drawText(title, {
      x: 42,
      y,
      size: 10,
      font: fontBold,
      color: navy,
    });
    page.drawLine({
      start: { x: 42, y: y - 5 },
      end: { x: width - 42, y: y - 5 },
      thickness: 0.75,
      color: border,
    });
    y -= 20;
  };

  const drawRow = (label: string, value: string) => {
    page.drawText(label, {
      x: 42,
      y,
      size: 9,
      font: fontBold,
      color: slate,
    });
    const wrapped = wrapText(value || '—', 64);
    for (let i = 0; i < wrapped.length; i++) {
      page.drawText(wrapped[i], {
        x: 185,
        y: y - i * 13,
        size: 9,
        font: fontRegular,
        color: navy,
      });
    }
    y -= Math.max(1, wrapped.length) * 14 + 4;
  };

  drawSectionHeading('1. ESTATE, COURT & SUBJECT PARCEL IDENTIFICATION');
  drawRow('Estate Matter', fields.estateName);
  drawRow('Court Venue', fields.courtSystem);
  drawRow('Subject Property', fields.propertyAddress);
  drawRow('Parcel ID / APN', fields.parcelId);
  drawRow('Legal Description', fields.legalDescription);
  drawRow('Personal Rep / Recipient', `${fields.recipientName} (${fields.recipientAddress})`);

  y -= 8;
  drawSectionHeading('2. PROPOSED TRANSACTION TERMS');
  drawRow('Buyer Entity', fields.buyerEntity);
  drawRow('Authorized Signer', `${fields.buyerSigner} · ${fields.buyerContact}`);
  drawRow('Proposed Purchase Price', fields.offerAmount);
  drawRow('Earnest Money Deposit', fields.earnestMoney);
  drawRow('Inspection / Due Diligence', fields.inspectionDays);
  drawRow('Target Closing Window', fields.closingDays);

  y -= 8;
  drawSectionHeading('3. LOCALIZED PROBATE CONTINGENCY & STANDARD PROVISIONS');

  const contingencyLines = wrapText(fields.probateContingencyClause, 88);
  for (const line of contingencyLines) {
    page.drawText(line, {
      x: 42,
      y,
      size: 9,
      font: fontBold,
      color: navy,
    });
    y -= 13;
  }
  y -= 6;

  for (const clause of template.clauses) {
    const lines = wrapText(`• ${clause}`, 88);
    for (const line of lines) {
      if (y < 140) break;
      page.drawText(line, {
        x: 48,
        y,
        size: 9,
        font: fontRegular,
        color: slate,
      });
      y -= 13;
    }
    y -= 3;
  }

  if (fields.federalNotice && y > 135) {
    const fedLines = wrapText(fields.federalNotice, 88);
    for (const line of fedLines) {
      if (y < 120) break;
      page.drawText(line, {
        x: 42,
        y,
        size: 8,
        font: fontRegular,
        color: muted,
      });
      y -= 11;
    }
  }

  // Signature block
  const sigY = Math.max(115, y - 24);
  page.drawLine({
    start: { x: 42, y: sigY },
    end: { x: 265, y: sigY },
    thickness: 0.75,
    color: slate,
  });
  page.drawText(`BUYER: ${fields.buyerSigner}`, {
    x: 42,
    y: sigY - 13,
    size: 8.5,
    font: fontBold,
    color: navy,
  });
  page.drawText(fields.buyerEntity, {
    x: 42,
    y: sigY - 24,
    size: 8,
    font: fontRegular,
    color: slate,
  });

  page.drawLine({
    start: { x: 330, y: sigY },
    end: { x: width - 42, y: sigY },
    thickness: 0.75,
    color: slate,
  });
  page.drawText(`SELLER / PR: ${fields.recipientName}`, {
    x: 330,
    y: sigY - 13,
    size: 8.5,
    font: fontBold,
    color: navy,
  });
  page.drawText(`On behalf of ${fields.estateName}`, {
    x: 330,
    y: sigY - 24,
    size: 8,
    font: fontRegular,
    color: slate,
  });

  // UPL Guardrail Footer
  page.drawRectangle({
    x: 42,
    y: 34,
    width: width - 84,
    height: 30,
    color: bannerBg,
    borderColor: border,
    borderWidth: 0.5,
  });
  page.drawText(
    'INFORMATIONAL WORKFLOW TEMPLATE ONLY — NOT LEGAL ADVICE. Review jurisdiction-specific probate rules and',
    {
      x: 50,
      y: 51,
      size: 7.5,
      font: fontBold,
      color: muted,
    }
  );
  page.drawText(
    'obtain counsel review prior to court submission or contract execution. Generated by CaseLot.',
    {
      x: 50,
      y: 41,
      size: 7.5,
      font: fontRegular,
      color: muted,
    }
  );

  const bytes = await doc.save();
  const safeCase = fields.caseNumber.replace(/[^a-zA-Z0-9_-]/g, '_');
  const safeSlug = template.id.replace(/^tpl-/, '');
  const fileName = `CaseLot_${safeCase}_${safeSlug}.pdf`;
  const blob = new Blob([bytes as unknown as BlobPart], { type: 'application/pdf' });
  const blobUrl = URL.createObjectURL(blob);

  return { bytes, blobUrl, fileName };
}
