import type {
  CrmDeal,
  ProbatePricingBreakdown,
  PropertyComp,
  PropertyMarketIntel,
  ThirdPartyIntegration,
} from '../types/caselot';

export const SEED_INTEGRATIONS: ThirdPartyIntegration[] = [
  {
    id: 'int-zillow-bridge',
    name: 'Zillow & Bridge Interactive AVM',
    category: 'Valuation & MLS',
    description: 'Sync Zestimate valuation ranges, Rent Zestimates, and public tax parcel attributes.',
    endpointUrl: 'https://api.bridgedataoutput.com/api/v2/zestimates_v2/zestimates',
    authHeaderName: 'Authorization',
    apiKeyMasked: 'Bearer br_live_••••84a2',
    enabled: true,
    events: ['deal.imported', 'property.viewed'],
    lastStatus: 'Active · Fallback AVM Ready',
  },
  {
    id: 'int-redfin-comps',
    name: 'Redfin Market & Sold Comps Feed',
    category: 'Valuation & MLS',
    description: 'Pull neighborhood DOM, sale-to-list ratios, and 90-day MLS comparable sales.',
    endpointUrl: 'https://www.redfin.com/stingray/api/home/details/avm',
    authHeaderName: 'X-Api-Key',
    apiKeyMasked: 'rf_feed_••••39c1',
    enabled: true,
    events: ['property.viewed'],
    lastStatus: 'Active · Comps Synced',
  },
  {
    id: 'int-batchleads',
    name: 'BatchLeads / PropStream Skip Trace',
    category: 'Skip Trace',
    description: 'Auto-enrich Executor/PR and Heir phone numbers, emails, and current mailing addresses.',
    endpointUrl: 'https://api.batchleads.io/api/v1/property/skip-trace',
    authHeaderName: 'Authorization',
    apiKeyMasked: 'Bearer bl_••••••••',
    enabled: false,
    events: ['deal.imported'],
  },
  {
    id: 'int-lob-mail',
    name: 'Lob Certified Direct Mail',
    category: 'Direct Mail',
    description: 'Dispatch automated probate outreach letters and postcards when a deal enters Outreach Sent.',
    endpointUrl: 'https://api.lob.com/v1/letters',
    authHeaderName: 'Authorization',
    apiKeyMasked: 'Basic live_••••910f',
    enabled: false,
    events: ['stage.changed'],
  },
  {
    id: 'int-docusign',
    name: 'DocuSign eSignature Packets',
    category: 'eSignature',
    description: 'Route auto-populated Probate Purchase Agreements and State Addenda for remote PR signing.',
    endpointUrl: 'https://na4.docusign.net/restapi/v2.1/envelopes',
    authHeaderName: 'Authorization',
    apiKeyMasked: 'Bearer ds_••••••••',
    enabled: false,
    events: ['pdf.generated'],
  },
  {
    id: 'int-zapier-hook',
    name: 'Zapier / Make / Custom Webhook',
    category: 'Automation Webhook',
    description: 'Broadcast JSON probate deal payloads to Salesforce, HubSpot, Podio, Slack, or custom pipelines.',
    endpointUrl: 'https://httpbin.org/post',
    authHeaderName: 'X-CaseLot-Signature',
    apiKeyMasked: 'whsec_caselot_2026',
    enabled: true,
    events: ['deal.imported', 'stage.changed', 'docket.extracted'],
    lastStatus: 'Ready for live webhook test',
  },
];

function deterministicHash(input: string): number {
  let h = 2166136261;
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h);
}

export function buildZillowAndRedfinUrls(deal: CrmDeal): { zillowUrl: string; redfinUrl: string } {
  const full = `${deal.property.address} ${deal.property.city} ${deal.property.stateCode} ${deal.property.zip}`.trim();
  const zillowSlug = full
    .replace(/[^a-zA-Z0-9\s-]/g, '')
    .trim()
    .replace(/\s+/g, '-');
  const zillowUrl = `https://www.zillow.com/homes/${encodeURIComponent(zillowSlug)}_rb/`;
  const redfinUrl = `https://www.redfin.com/stingray/do/query-location?location=${encodeURIComponent(full)}&v=2`;
  return { zillowUrl, redfinUrl };
}

export function buildPropertyMarketIntelligence(
  deal: CrmDeal,
  rehabOverride?: number
): PropertyMarketIntel {
  const { property } = deal;
  const seed = deterministicHash(property.parcelId + property.address);
  const baseAssessed = Math.max(85000, property.assessedValue);

  // Market valuations typically track 6%-16% above county tax assessed values
  const zillowMultiplier = 1.07 + ((seed % 9) / 100);
  const redfinMultiplier = 1.05 + (((seed >> 3) % 10) / 100);

  const zillowZestimate = Math.round((baseAssessed * zillowMultiplier) / 500) * 500;
  const zillowSpread = Math.round(zillowZestimate * 0.055);
  const zillowLow = zillowZestimate - zillowSpread;
  const zillowHigh = zillowZestimate + zillowSpread;
  const zillowRentZestimate = Math.round((zillowZestimate * 0.0068) / 25) * 25;
  const zillowThirtyDayChangePct = Number((((seed % 26) - 6) / 10).toFixed(1));

  const redfinEstimate = Math.round((baseAssessed * redfinMultiplier) / 500) * 500;
  const redfinAvgDom = 21 + (seed % 29);
  const redfinSaleToListPct = Number((97.2 + ((seed % 26) / 10)).toFixed(1));
  const safeSqft = Math.max(700, property.sqft || 1850);
  const redfinPricePerSqft = Math.round(redfinEstimate / safeSqft);

  const isLand = property.propertyType === 'Land / Lot';
  const isMulti = property.propertyType === 'Multi-Family';
  const bedrooms = isLand ? 0 : isMulti ? 6 : 3 + (seed % 2);
  const bathrooms = isLand ? 0 : isMulti ? 4 : 2 + ((seed % 3 === 0) ? 0.5 : 0);
  const lotSqft = isLand ? safeSqft * 4 : 6200 + (seed % 4800);
  const zoning =
    property.propertyType === 'Commercial'
      ? 'C-2 Neighborhood Commercial'
      : isMulti
        ? 'R-3 Multi-Family Residential'
        : isLand
          ? 'R-1A Vacant Residential Tract'
          : 'R-1 Single-Family Detached';

  const taxRateMap: Record<string, number> = {
    TX: 2.18,
    AZ: 0.64,
    FL: 1.72,
    IL: 2.12,
    GA: 1.04,
  };
  const taxRatePct = taxRateMap[property.stateCode] ?? 1.25;
  const annualPropertyTax = Math.round(baseAssessed * (taxRatePct / 100));

  const rehabEstimate =
    rehabOverride !== undefined
      ? Math.max(0, rehabOverride)
      : isLand
        ? 4500
        : Math.round((zillowZestimate * 0.075) / 500) * 500;

  const avgArv = Math.round((zillowZestimate + redfinEstimate) / 2);
  const recommendedMao = Math.max(
    0,
    Math.round((avgArv * 0.72 - rehabEstimate - property.estimatedDebt) / 500) * 500
  );

  const streetNum = Number.parseInt(property.address.match(/^\d+/)?.[0] ?? '1200', 10) || 1200;
  const streetTokens = property.address.replace(/^\d+\s+/, '');

  const comps: PropertyComp[] = [
    {
      address: `${streetNum + 18} ${streetTokens}`,
      soldPrice: Math.round((avgArv * 1.02) / 500) * 500,
      soldDate: '2026-10-18',
      sqft: safeSqft + 90,
      beds: bedrooms,
      baths: bathrooms,
      distanceMiles: 0.24,
      pricePerSqft: Math.round((avgArv * 1.02) / (safeSqft + 90)),
      source: 'Redfin',
    },
    {
      address: `${Math.max(102, streetNum - 42)} Oakwood Trace`,
      soldPrice: Math.round((avgArv * 0.96) / 500) * 500,
      soldDate: '2026-09-29',
      sqft: Math.max(650, safeSqft - 110),
      beds: bedrooms,
      baths: Math.max(1, bathrooms - 0.5),
      distanceMiles: 0.41,
      pricePerSqft: Math.round((avgArv * 0.96) / Math.max(650, safeSqft - 110)),
      source: 'Zillow',
    },
    {
      address: `${streetNum + 104} Crestview Ln`,
      soldPrice: Math.round((avgArv * 1.045) / 500) * 500,
      soldDate: '2026-09-04',
      sqft: safeSqft + 180,
      beds: bedrooms + (isLand ? 0 : 1),
      baths: bathrooms,
      distanceMiles: 0.68,
      pricePerSqft: Math.round((avgArv * 1.045) / (safeSqft + 180)),
      source: 'Redfin',
    },
  ];

  const { zillowUrl, redfinUrl } = buildZillowAndRedfinUrls(deal);

  return {
    zillowZestimate,
    zillowLow,
    zillowHigh,
    zillowRentZestimate,
    zillowThirtyDayChangePct,
    zillowUrl,
    redfinEstimate,
    redfinAvgDom,
    redfinSaleToListPct,
    redfinPricePerSqft,
    redfinUrl,
    bedrooms,
    bathrooms,
    lotSqft,
    zoning,
    annualPropertyTax,
    taxRatePct,
    rehabEstimate,
    recommendedMao,
    comps,
  };
}

export interface JurisdictionFeeSchedule {
  jurisdictionId: string;
  label: string;
  filingFee: number;
  publicationNoticeFee: number;
  bondAndAppraisalFee: number;
  attorneyFeeModel: string;
  statutoryBasis: string;
  computeAttorneyFee: (estateValue: number) => number;
  computeExecutorFee: (estateValue: number) => number;
  monthlyTaxInsuranceRate: number;
}

const FEE_SCHEDULES: JurisdictionFeeSchedule[] = [
  {
    jurisdictionId: 'tx-harris',
    label: 'Harris County, TX (Probate Courts 1–4)',
    filingFee: 360,
    publicationNoticeFee: 195,
    bondAndAppraisalFee: 250,
    attorneyFeeModel: 'Independent Flat / Hourly Typical ($3,500–$6,500)',
    statutoryBasis: 'Tex. Est. Code §352.051 & Harris County Clerk 2026 Fee Schedule',
    computeAttorneyFee: (val) => Math.round(3200 + Math.min(val, 900000) * 0.004),
    computeExecutorFee: (val) => Math.round(val * 0.015), // Up to 5% statutory in TX; many family PRs waive or take ~1.5%
    monthlyTaxInsuranceRate: 0.026 / 12,
  },
  {
    jurisdictionId: 'tx-travis',
    label: 'Travis County, TX (Probate Court No. 1 & 2)',
    filingFee: 365,
    publicationNoticeFee: 185,
    bondAndAppraisalFee: 225,
    attorneyFeeModel: 'Independent Flat / Hourly Typical ($3,200–$5,800)',
    statutoryBasis: 'Tex. Est. Code §352.051 & Travis County Clerk 2026 Schedule',
    computeAttorneyFee: (val) => Math.round(3000 + Math.min(val, 900000) * 0.0038),
    computeExecutorFee: (val) => Math.round(val * 0.015),
    monthlyTaxInsuranceRate: 0.024 / 12,
  },
  {
    jurisdictionId: 'az-maricopa',
    label: 'Maricopa County, AZ (Superior Court Probate)',
    filingFee: 334,
    publicationNoticeFee: 240,
    bondAndAppraisalFee: 350,
    attorneyFeeModel: 'Reasonable Hourly Rate (A.R.S. §14-3720)',
    statutoryBasis: 'Maricopa Superior Court 2026 Civil/Probate Filing Fees',
    computeAttorneyFee: (val) => Math.round(3800 + Math.min(val, 800000) * 0.005),
    computeExecutorFee: (val) => Math.round(val * 0.018),
    monthlyTaxInsuranceRate: 0.012 / 12,
  },
  {
    jurisdictionId: 'fl-miamidade',
    label: 'Miami-Dade County, FL (11th Judicial Circuit)',
    filingFee: 401,
    publicationNoticeFee: 265,
    bondAndAppraisalFee: 425,
    attorneyFeeModel: 'Presumed Reasonable Graduated Tier (Fla. Stat. §733.6171)',
    statutoryBasis: 'Fla. Stat. §733.6171 (3% tier up to $1M) & Miami-Dade Clerk 2026',
    computeAttorneyFee: (val) => (val <= 100000 ? 3000 : Math.round(val * 0.03)),
    computeExecutorFee: (val) => Math.round(val * 0.03),
    monthlyTaxInsuranceRate: 0.028 / 12,
  },
  {
    jurisdictionId: 'il-cook',
    label: 'Cook County, IL (Circuit Court Probate Division)',
    filingFee: 388,
    publicationNoticeFee: 295,
    bondAndAppraisalFee: 480,
    attorneyFeeModel: 'Court-Reviewed Reasonable Fee (755 ILCS 5/27-2)',
    statutoryBasis: 'Cook County Clerk 2026 Probate Fee Schedule',
    computeAttorneyFee: (val) => Math.round(4200 + Math.min(val, 900000) * 0.006),
    computeExecutorFee: (val) => Math.round(val * 0.02),
    monthlyTaxInsuranceRate: 0.027 / 12,
  },
  {
    jurisdictionId: 'ga-fulton',
    label: 'Fulton County, GA (Probate Court)',
    filingFee: 215,
    publicationNoticeFee: 165,
    bondAndAppraisalFee: 200,
    attorneyFeeModel: 'Flat / Hourly Counsel (O.C.G.A. §53-7-6)',
    statutoryBasis: 'Georgia Probate Court Uniform 2026 Fee Schedule',
    computeAttorneyFee: (val) => Math.round(2800 + Math.min(val, 800000) * 0.004),
    computeExecutorFee: (val) => Math.round(val * 0.025), // 2.5% receipts/disbursements statutory benchmark
    monthlyTaxInsuranceRate: 0.016 / 12,
  },
];

export function getAllJurisdictionFeeSchedules(): JurisdictionFeeSchedule[] {
  return FEE_SCHEDULES;
}

export function calculateCurrentProbatePricing(
  jurisdictionId: string,
  propertyValue: number,
  estimatedDebt = 0
): ProbatePricingBreakdown {
  const safeValue = Math.max(50000, propertyValue);
  const schedule =
    FEE_SCHEDULES.find((s) => s.jurisdictionId === jurisdictionId) ?? FEE_SCHEDULES[0];

  const attorneyFeeEstimate = schedule.computeAttorneyFee(safeValue);
  const executorFeeEstimate = schedule.computeExecutorFee(safeValue);
  const sixMonthHoldingCost = Math.round(safeValue * schedule.monthlyTaxInsuranceRate * 6 + 1800);
  const totalProbateCarryCost =
    schedule.filingFee +
    schedule.publicationNoticeFee +
    schedule.bondAndAppraisalFee +
    attorneyFeeEstimate +
    executorFeeEstimate +
    sixMonthHoldingCost;

  // Traditional listing net proceeds: 7% agent commission + closing costs minus liens and probate carry cost
  const agentAndClosing = Math.round(safeValue * 0.075);
  const traditionalNetProceeds = Math.max(
    0,
    safeValue - estimatedDebt - agentAndClosing - totalProbateCarryCost
  );

  // Fast cash probate offer (~78% of market value, zero agent commissions, buyer covers title/closing, shorter carry)
  const fastCashGross = Math.round((safeValue * 0.78) / 500) * 500;
  const reducedCarry = schedule.filingFee + schedule.publicationNoticeFee + Math.round(attorneyFeeEstimate * 0.75);
  const fastCashNetProceeds = Math.max(0, fastCashGross - estimatedDebt - reducedCarry);

  return {
    jurisdictionLabel: schedule.label,
    statutoryBasis: schedule.statutoryBasis,
    filingFee: schedule.filingFee,
    publicationNoticeFee: schedule.publicationNoticeFee,
    bondAndAppraisalFee: schedule.bondAndAppraisalFee,
    attorneyFeeEstimate,
    attorneyFeeModel: schedule.attorneyFeeModel,
    executorFeeEstimate,
    sixMonthHoldingCost,
    totalProbateCarryCost,
    traditionalNetProceeds,
    fastCashNetProceeds,
  };
}

export interface DealStrategyBreakdown {
  blendedArv: number;
  purchaseBasis: number;
  rehabBudget: number;
  // Strategy 1: Fix & Flip
  flipHoldingAndSellingCosts: number;
  flipProjectedNetProfit: number;
  flipRoiPct: number;
  // Strategy 2: Buy & Hold + DSCR
  grossMonthlyRent: number;
  monthlyOperatingExpenses: number;
  monthlyNoi: number;
  annualCapRatePct: number;
  dscrMonthlyDebtService: number;
  dscrRatio: number;
  dscrQualifies: boolean;
  monthlyNetCashFlow: number;
  cashOnCashPct: number;
  // Strategy 3: Seller Financing / Installment Sale
  sellerDownPayment: number;
  sellerFinancedPrincipal: number;
  sellerMonthlyPayment: number;
  sellerTotalInterestEarned: number;
  sellerMonthlyCashFlow: number;
}

export interface SellerFinanceTerms {
  purchasePrice?: number;
  downPaymentPct: number;
  interestRatePct: number;
  termYears: number;
}

export function calculateMonthlyMortgagePayment(
  principal: number,
  annualRatePct: number,
  years: number
): number {
  const p = Math.max(0, principal);
  const n = Math.max(1, Math.round(years * 12));
  if (p === 0) return 0;
  const r = Math.max(0, annualRatePct) / 100 / 12;
  if (r === 0) return Math.round(p / n);
  const factor = Math.pow(1 + r, n);
  return Math.round((p * (r * factor)) / (factor - 1));
}

export function calculateDealStrategies(
  deal: CrmDeal,
  rehabBudget: number,
  sellerTerms: SellerFinanceTerms = {
    downPaymentPct: 15,
    interestRatePct: 5.5,
    termYears: 20,
  }
): DealStrategyBreakdown {
  const intel = buildPropertyMarketIntelligence(deal, rehabBudget);
  const blendedArv = Math.round((intel.zillowZestimate + intel.redfinEstimate) / 2);
  const purchaseBasis = Math.max(
    50000,
    deal.offerAmount > 0 ? deal.offerAmount : intel.recommendedMao || Math.round(blendedArv * 0.72)
  );

  // 1. Fix & Flip (9% agent/closing/carry reserve on ARV)
  const flipHoldingAndSellingCosts = Math.round(blendedArv * 0.09);
  const flipTotalIn = purchaseBasis + rehabBudget + flipHoldingAndSellingCosts;
  const flipProjectedNetProfit = blendedArv - flipTotalIn;
  const flipRoiPct =
    purchaseBasis + rehabBudget > 0
      ? Number(((flipProjectedNetProfit / (purchaseBasis + rehabBudget)) * 100).toFixed(1))
      : 0;

  // 2. Buy & Hold Rental + DSCR (assume 75% LTV DSCR loan @ 7.15% 30yr after rehab)
  const grossMonthlyRent = intel.zillowRentZestimate;
  const monthlyTax = Math.round(intel.annualPropertyTax / 12);
  const monthlyInsurance = Math.round((blendedArv * 0.0045) / 12);
  const monthlyVacancyAndCapEx = Math.round(grossMonthlyRent * 0.12);
  const monthlyManagement = Math.round(grossMonthlyRent * 0.08);
  const monthlyOperatingExpenses =
    monthlyTax + monthlyInsurance + monthlyVacancyAndCapEx + monthlyManagement;
  const monthlyNoi = Math.max(0, grossMonthlyRent - monthlyOperatingExpenses);

  const allInBasis = purchaseBasis + rehabBudget;
  const annualCapRatePct =
    allInBasis > 0 ? Number((((monthlyNoi * 12) / allInBasis) * 100).toFixed(2)) : 0;

  const dscrLoanAmount = Math.round(allInBasis * 0.75);
  const dscrMonthlyDebtService = calculateMonthlyMortgagePayment(dscrLoanAmount, 7.15, 30);
  const dscrRatio =
    dscrMonthlyDebtService > 0
      ? Number((monthlyNoi / dscrMonthlyDebtService).toFixed(2))
      : 0;
  const dscrQualifies = dscrRatio >= 1.2;
  const monthlyNetCashFlow = monthlyNoi - dscrMonthlyDebtService;
  const cashInvested = Math.max(1, Math.round(allInBasis * 0.25) + 4500);
  const cashOnCashPct = Number((((monthlyNetCashFlow * 12) / cashInvested) * 100).toFixed(1));

  // 3. Seller Financing (Creative Installment Offer directly to Estate / Heirs)
  const sfPrice = sellerTerms.purchasePrice ?? Math.round((blendedArv * 0.88) / 500) * 500;
  const sellerDownPayment = Math.round(sfPrice * (sellerTerms.downPaymentPct / 100));
  const sellerFinancedPrincipal = Math.max(0, sfPrice - sellerDownPayment);
  const sellerMonthlyPayment = calculateMonthlyMortgagePayment(
    sellerFinancedPrincipal,
    sellerTerms.interestRatePct,
    sellerTerms.termYears
  );
  const sellerTotalInterestEarned = Math.max(
    0,
    sellerMonthlyPayment * sellerTerms.termYears * 12 - sellerFinancedPrincipal
  );
  const sellerMonthlyCashFlow = monthlyNoi - sellerMonthlyPayment;

  return {
    blendedArv,
    purchaseBasis,
    rehabBudget,
    flipHoldingAndSellingCosts,
    flipProjectedNetProfit,
    flipRoiPct,
    grossMonthlyRent,
    monthlyOperatingExpenses,
    monthlyNoi,
    annualCapRatePct,
    dscrMonthlyDebtService,
    dscrRatio,
    dscrQualifies,
    monthlyNetCashFlow,
    cashOnCashPct,
    sellerDownPayment,
    sellerFinancedPrincipal,
    sellerMonthlyPayment,
    sellerTotalInterestEarned,
    sellerMonthlyCashFlow,
  };
}

export interface AvmAuditReport {
  spreadPct: number;
  confidenceLabel: 'High Consensus' | 'Moderate Variance' | 'Verify Local Comps';
  requiresFieldInspection: boolean;
  warnings: string[];
}

export function auditValuationConfidence(
  deal: CrmDeal,
  zillowZestimate: number,
  redfinEstimate: number
): AvmAuditReport {
  const values = [deal.property.assessedValue, zillowZestimate, redfinEstimate].filter((v) => v > 0);
  const minVal = Math.min(...values);
  const maxVal = Math.max(...values);
  const spreadPct = minVal > 0 ? Number((((maxVal - minVal) / minVal) * 100).toFixed(1)) : 0;

  const warnings: string[] = [
    'Automated Zillow/Redfin models do not reflect interior estate cleanout or deferred maintenance.',
  ];
  if (spreadPct >= 14) {
    warnings.push(
      `Assessor vs. Retail AVM spread is ${spreadPct}% — pull 3 hyper-local MLS comps within 0.5 miles before binding offer.`
    );
  }
  if (deal.property.matchConfidence < 95) {
    warnings.push(
      `Parcel cross-match confidence is ${deal.property.matchConfidence}% (${deal.property.matchSource}); confirm deed vesting at County Recorder.`
    );
  }

  return {
    spreadPct,
    confidenceLabel:
      spreadPct >= 15
        ? 'Verify Local Comps'
        : spreadPct >= 10
          ? 'Moderate Variance'
          : 'High Consensus',
    requiresFieldInspection: spreadPct >= 12 || deal.property.matchConfidence < 95,
    warnings,
  };
}

export interface StakeholderHierarchySummary {
  primaryDecisionMaker: CrmDeal['stakeholders'][number] | null;
  outOfStatePr: boolean;
  prStateCode: string | null;
  routingAdvice: string;
  contactReadiness: 'Verified PR Direct' | 'Route via Probate Counsel' | 'Skip-Trace Needed';
}

export function analyzeStakeholderHierarchy(deal: CrmDeal): StakeholderHierarchySummary {
  const pr =
    deal.stakeholders.find((s) => s.role === 'Executor / PR') ??
    deal.stakeholders.find((s) => s.role === 'Heir') ??
    null;
  const attorney = deal.stakeholders.find((s) => s.role === 'Probate Attorney') ?? null;

  const stateMatch = pr?.mailingAddress.match(/,\s*([A-Z]{2})\s+\d{5}/);
  const prStateCode = stateMatch ? stateMatch[1] : null;
  const outOfStatePr = Boolean(
    prStateCode && prStateCode !== deal.property.stateCode.toUpperCase()
  );

  if (deal.probateCase.hasAttorney && attorney) {
    return {
      primaryDecisionMaker: pr,
      outOfStatePr,
      prStateCode,
      contactReadiness: 'Route via Probate Counsel',
      routingAdvice: `Estate is represented by ${attorney.fullName}. Send formal LOI & Proof of Funds directly to counsel or CC both PR and counsel.`,
    };
  }

  if (pr && pr.verified) {
    return {
      primaryDecisionMaker: pr,
      outOfStatePr,
      prStateCode,
      contactReadiness: 'Verified PR Direct',
      routingAdvice: outOfStatePr
        ? `Out-of-state Personal Representative in ${prStateCode} managing a ${deal.property.stateCode} property. Emphasize remote notarization & estate cleanout relief.`
        : `Verified Pro Se Personal Representative on file. Use compassionate direct mail first, then DNC-scrubbed manual call.`,
    };
  }

  return {
    primaryDecisionMaker: pr,
    outOfStatePr,
    prStateCode,
    contactReadiness: 'Skip-Trace Needed',
    routingAdvice:
      'Decedent phone/address records are excluded. Run live Skip Trace specifically on the appointed Executor/PR before outreach.',
  };
}

export type OutreachTone = 'empathetic-caretaker' | 'out-of-state-relief' | 'counsel-loi';

export function generateCompassionateOutreach(
  deal: CrmDeal,
  tone: OutreachTone,
  buyerEntity: string,
  offerAmount: number
): { subject: string; body: string } {
  const hierarchy = analyzeStakeholderHierarchy(deal);
  const prName = hierarchy.primaryDecisionMaker?.fullName ?? 'Personal Representative';
  const firstName = prName.split(' ')[0] || 'there';
  const addr = `${deal.property.address}, ${deal.property.city}, ${deal.property.stateCode}`;
  const priceText = `$${Math.round(offerAmount).toLocaleString('en-US')}`;

  if (tone === 'counsel-loi') {
    return {
      subject: `Non-Binding Cash Acquisition Proposal — Estate of ${deal.probateCase.decedentName} (${deal.probateCase.caseNumber})`,
      body: `Dear ${
        deal.stakeholders.find((s) => s.role === 'Probate Attorney')?.fullName ?? prName
      },\n\nWe are writing respectfully regarding the real property at ${addr} in ${
        deal.property.countyName
      } County (${deal.probateCase.caseNumber}). ${buyerEntity} specializes in clean, court-compliant probate real estate closings.\n\nWe would be pleased to submit an as-is offer of ${priceText} with zero broker commissions, buyer-paid standard title/escrow fees, and a closing schedule aligned directly with Letters of Authority and any applicable court confirmation window. Proof of funds is attached upon request.\n\nRespectfully,\n${buyerEntity}`,
    };
  }

  if (tone === 'out-of-state-relief') {
    return {
      subject: `Turnkey Estate Property Relief for ${deal.property.address}`,
      body: `Dear ${firstName},\n\nPlease accept our sincere condolences on the passing of ${deal.probateCase.decedentName}. Managing an estate home in ${deal.property.city}, ${deal.property.stateCode} from out of state can feel overwhelming.\n\nAt ${buyerEntity}, we handle every detail locally so you do not have to travel, clean out remaining belongings, or coordinate repairs. We can purchase ${addr} completely as-is for ${priceText} with mobile notary closing on your timeline—whether you want to close in 21 days or wait until probate steps are complete.\n\nThere is zero pressure and zero obligation. Reply or call whenever it is convenient for your family.\n\nWarm regards,\n${buyerEntity}`,
    };
  }

  return {
    subject: `Respectful Note Regarding ${deal.property.address}`,
    body: `Dear ${firstName},\n\nWe are sorry for your family’s loss of ${deal.probateCase.decedentName}. We know settling an estate takes time, and the last thing you need is pushy sales calls.\n\nIf the estate eventually decides to sell ${addr} without making repairs, staging, or paying listing commissions, ${buyerEntity} would be grateful for the chance to make a straightforward, transparent offer (currently modeled around ${priceText} as-is) on whatever schedule works best for you and your family.\n\nWishing you peace and clarity as you navigate this process.\n\nSincerely,\n${buyerEntity}`,
  };
}

