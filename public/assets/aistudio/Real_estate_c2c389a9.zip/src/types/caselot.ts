export type WorkspaceId = 'discover' | 'property' | 'pipeline' | 'hub' | 'engage' | 'connectors';

export type PlanTier = 'free' | 'pro' | 'enterprise';
export type ThemeMode = 'light' | 'dark';

export type DealStage =
  | 'New Lead'
  | 'Verified Real Estate'
  | 'Outreach Sent'
  | 'In Negotiation'
  | 'Offer / LOI Sent'
  | 'Under Contract'
  | 'Probate Court Approval'
  | 'Closed';

export const DEAL_STAGES: DealStage[] = [
  'New Lead',
  'Verified Real Estate',
  'Outreach Sent',
  'In Negotiation',
  'Offer / LOI Sent',
  'Under Contract',
  'Probate Court Approval',
  'Closed',
];

export type ConnectorStatus = 'Live Automated' | 'Scheduled Daily' | 'Manual / FOIA CSV';
export type AdminType = 'Independent' | 'Dependent / Supervised' | 'Informal' | 'Summary';
export type PropertyType = 'Single-Family' | 'Multi-Family' | 'Land / Lot' | 'Commercial';
export type StakeholderRole = 'Executor / PR' | 'Heir' | 'Probate Attorney';

export interface OfficialLink {
  label: string;
  department: 'Probate Clerk' | 'Tax Assessor' | 'County Recorder' | 'Fee Schedule';
  url: string;
  portalVendor: string;
}

export interface JurisdictionRules {
  adminTypesSummary: string;
  courtConfirmationRequired: boolean;
  overbidProcess: string;
  typicalTimeline: string;
  creditorClaimPeriod: string;
  homesteadNote: string;
}

export interface Jurisdiction {
  id: string;
  stateCode: string;
  stateName: string;
  countyName: string;
  courtSystemType: string;
  scrapingAdapter: string;
  connectorStatus: ConnectorStatus;
  lastSyncedAt: string;
  rules: JurisdictionRules;
  officialLinks: OfficialLink[];
  checklistTemplates: string[];
}

export interface DocketEvent {
  id: string;
  date: string;
  title: string;
  documentType: string;
  notes: string;
}

export interface Stakeholder {
  id: string;
  role: StakeholderRole;
  fullName: string;
  mailingAddress: string;
  phone: string;
  email: string;
  verified: boolean;
}

export interface ActivityLog {
  id: string;
  timestamp: string;
  channel: 'Call' | 'SMS' | 'Direct Mail' | 'Email' | 'Note';
  summary: string;
}

export interface PropertyRecord {
  id: string;
  parcelId: string;
  address: string;
  city: string;
  stateCode: string;
  zip: string;
  countyName: string;
  legalDescription: string;
  assessedValue: number;
  estimatedDebt: number;
  propertyType: PropertyType;
  sqft: number;
  yearBuilt: number;
  lat: number;
  lng: number;
  sceneX: number;
  sceneZ: number;
  ownerName: string;
  matchConfidence: number;
  matchSource: 'County Tax Roll Cross-Match' | 'Inventory & Appraisement PDF' | 'GIS Parcel Match';
}

export interface ProbateCase {
  id: string;
  jurisdictionId: string;
  caseNumber: string;
  decedentName: string;
  dateOfDeath: string;
  filingDate: string;
  caseType: string;
  adminType: AdminType;
  probateStage: string;
  hasAttorney: boolean;
  rawDocketText: string;
  aiSummary: string;
  docketTimeline: DocketEvent[];
}

export interface CrmDeal {
  id: string;
  inPipeline: boolean;
  stage: DealStage;
  offerAmount: number;
  notes: string;
  nextFollowupAt: string;
  probateCase: ProbateCase;
  property: PropertyRecord;
  stakeholders: Stakeholder[];
  activities: ActivityLog[];
  checklistCompleted: Record<string, boolean>;
}

export interface DiscoverFilters {
  stateCode: string;
  countyName: string;
  filingWindowDays: number; // 0 = all
  propertyType: string; // 'All' or PropertyType
  minEquity: number;
  attorneyStatus: 'all' | 'no-attorney' | 'represented';
  adminType: 'all' | AdminType;
  searchQuery: string;
}

export interface SavedSearch {
  id: string;
  name: string;
  filters: DiscoverFilters;
  alertFrequency: 'Daily Digest' | 'Instant' | 'Weekly';
  createdAt: string;
}

export interface FormTemplate {
  id: string;
  title: string;
  category: 'Outreach' | 'Offer & Contract' | 'Court Filing';
  stateScope: string; // 'ALL' or stateCode e.g. 'TX'
  description: string;
  clauses: string[];
}

export interface GeneratedDoc {
  id: string;
  dealId: string;
  templateId: string;
  templateTitle: string;
  fileName: string;
  createdAt: string;
  offerAmount: number;
  buyerEntity: string;
  recipientName: string;
}

export interface ExtractedDocketData {
  decedentName: string;
  dateOfDeath: string;
  caseNumber: string;
  caseType: string;
  adminType: AdminType;
  probateStage: string;
  executorName: string;
  executorAddress: string;
  probateAttorney: string;
  propertyAddress: string;
  city: string;
  stateCode: string;
  countyName: string;
  parcelId: string;
  assessedValue: number;
  estimatedDebt: number;
  propertyType: PropertyType;
  aiSummary: string;
}

export interface BuyerProfile {
  entityName: string;
  signerName: string;
  signerTitle: string;
  mailingAddress: string;
  phone: string;
  email: string;
  earnestMoney: number;
  inspectionDays: number;
  closingDays: number;
}

export type IntegrationCategory =
  | 'Valuation & MLS'
  | 'Skip Trace'
  | 'Direct Mail'
  | 'eSignature'
  | 'CRM Sync'
  | 'Automation Webhook';

export interface ThirdPartyIntegration {
  id: string;
  name: string;
  category: IntegrationCategory;
  description: string;
  endpointUrl: string;
  authHeaderName: string;
  apiKeyMasked: string;
  enabled: boolean;
  events: string[];
  isCustom?: boolean;
  lastTestedAt?: string;
  lastStatus?: string;
}

export interface PropertyComp {
  address: string;
  soldPrice: number;
  soldDate: string;
  sqft: number;
  beds: number;
  baths: number;
  distanceMiles: number;
  pricePerSqft: number;
  source: 'Zillow' | 'Redfin';
}

export interface PropertyMarketIntel {
  zillowZestimate: number;
  zillowLow: number;
  zillowHigh: number;
  zillowRentZestimate: number;
  zillowThirtyDayChangePct: number;
  zillowUrl: string;
  redfinEstimate: number;
  redfinAvgDom: number;
  redfinSaleToListPct: number;
  redfinPricePerSqft: number;
  redfinUrl: string;
  bedrooms: number;
  bathrooms: number;
  lotSqft: number;
  zoning: string;
  annualPropertyTax: number;
  taxRatePct: number;
  rehabEstimate: number;
  recommendedMao: number;
  comps: PropertyComp[];
}

export interface ProbatePricingBreakdown {
  jurisdictionLabel: string;
  statutoryBasis: string;
  filingFee: number;
  publicationNoticeFee: number;
  bondAndAppraisalFee: number;
  attorneyFeeEstimate: number;
  attorneyFeeModel: string;
  executorFeeEstimate: number;
  sixMonthHoldingCost: number;
  totalProbateCarryCost: number;
  traditionalNetProceeds: number;
  fastCashNetProceeds: number;
}

