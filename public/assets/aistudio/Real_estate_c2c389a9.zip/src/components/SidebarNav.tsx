import React, { useState } from 'react';
import {
  Building2,
  Check,
  Compass,
  Cpu,
  Crown,
  FileText,
  Kanban,
  Menu,
  Moon,
  Scale,
  Share2,
  Sun,
  UploadCloud,
  X,
} from 'lucide-react';
import type { CrmDeal, PlanTier, ThemeMode, WorkspaceId } from '../types/caselot';
import { calculateEstimatedEquity, formatCurrency } from '../utils/probateLogic';
import { PWAInstallButton } from './PWAComponents';

interface SidebarNavProps {
  activeWorkspace: WorkspaceId;
  onSelectWorkspace: (ws: WorkspaceId) => void;
  activeDeal: CrmDeal | null;
  pipelineCount: number;
  totalDealsCount: number;
  integrationsCount: number;
  theme: ThemeMode;
  onToggleTheme: () => void;
  planTier: PlanTier;
  onOpenPricing: () => void;
  onOpenIngest: () => void;
}

const NAV_ITEMS: {
  id: WorkspaceId;
  label: string;
  shortLabel: string;
  subtitle: string;
  icon: React.ComponentType<{ className?: string }>;
}[] = [
  {
    id: 'discover',
    label: 'US Discover',
    shortLabel: 'Discover',
    subtitle: 'Search, Maps & 3D Atlas',
    icon: Compass,
  },
  {
    id: 'property',
    label: 'Property 360°',
    shortLabel: '3D / AR / VR',
    subtitle: 'Twin, AR/VR & Deal Lab',
    icon: Building2,
  },
  {
    id: 'pipeline',
    label: 'Pipeline & CRM',
    shortLabel: 'Pipeline',
    subtitle: '8-Stage Acquisition Board',
    icon: Kanban,
  },
  {
    id: 'hub',
    label: 'US Compliance Hub',
    shortLabel: 'US Rules',
    subtitle: 'Federal, 50-State & Fees',
    icon: Scale,
  },
  {
    id: 'engage',
    label: 'Engage & Forms',
    shortLabel: 'Forms',
    subtitle: 'Compliant Offer Packets',
    icon: FileText,
  },
  {
    id: 'connectors',
    label: 'Apps & AI',
    shortLabel: 'Apps & AI',
    subtitle: 'Webhooks, TX & Ollama',
    icon: Cpu,
  },
];

const PLAN_LABELS: Record<PlanTier, string> = {
  free: 'Starter Free',
  pro: 'Acquisition Pro',
  enterprise: 'Enterprise AI',
};

export const SidebarNav: React.FC<SidebarNavProps> = ({
  activeWorkspace,
  onSelectWorkspace,
  activeDeal,
  pipelineCount,
  totalDealsCount,
  integrationsCount,
  theme,
  onToggleTheme,
  planTier,
  onOpenPricing,
  onOpenIngest,
}) => {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState(false);

  const handleSelectNav = (ws: WorkspaceId) => {
    onSelectWorkspace(ws);
    setDrawerOpen(false);
  };

  const handleCopyOnlineUrl = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      setCopiedUrl(true);
      window.setTimeout(() => setCopiedUrl(false), 2000);
    } catch {
      setCopiedUrl(false);
    }
  };

  const renderNavList = () => (
    <nav aria-label="Primary Workspaces" className="space-y-1">
      {NAV_ITEMS.map((item) => {
        const Icon = item.icon;
        const isActive = activeWorkspace === item.id;
        const countBadge =
          item.id === 'discover'
            ? totalDealsCount
            : item.id === 'pipeline'
              ? pipelineCount
              : item.id === 'connectors'
                ? integrationsCount
                : null;

        return (
          <button
            key={item.id}
            type="button"
            onClick={() => handleSelectNav(item.id)}
            className={`w-full flex items-center justify-between gap-2.5 px-3 py-2.5 min-h-[44px] rounded-xl text-left transition-colors ${
              isActive
                ? 'bg-sky-500/12 text-white border border-sky-500/35'
                : 'text-slate-300 hover:bg-white/[0.04] hover:text-white border border-transparent'
            }`}
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-sky-400' : 'text-slate-400'}`} />
              <div className="min-w-0">
                <div className="text-sm font-medium leading-tight">{item.label}</div>
                <div className="text-[11px] text-slate-400 truncate">{item.subtitle}</div>
              </div>
            </div>
            {countBadge !== null && (
              <span className="font-mono text-xs text-slate-300 tabular-nums shrink-0">
                {countBadge}
              </span>
            )}
          </button>
        );
      })}
    </nav>
  );

  const renderActiveEstateCard = () =>
    activeDeal ? (
      <button
        type="button"
        onClick={() => handleSelectNav('property')}
        className="w-full text-left p-4 border-t border-white/[0.08] bg-white/[0.02] hover:bg-white/[0.05] transition-colors"
      >
        <div className="flex items-center justify-between gap-2">
          <span className="text-[11px] font-medium text-slate-400">Active US Estate</span>
          <span className="text-[11px] font-semibold text-sky-400">3D / AR / VR →</span>
        </div>
        <div className="text-sm font-semibold text-white mt-0.5 truncate">
          {activeDeal.property.address}
        </div>
        <div className="text-xs text-slate-400 mt-0.5 truncate">
          {activeDeal.property.countyName}, {activeDeal.property.stateCode} ·{' '}
          <span className="font-mono">{activeDeal.probateCase.caseNumber}</span>
        </div>
        <div className="mt-2 pt-2 border-t border-white/[0.08] flex items-center justify-between text-xs">
          <span className="text-slate-400">Est. Equity</span>
          <span className="font-mono font-semibold text-emerald-400 tabular-nums">
            {formatCurrency(
              calculateEstimatedEquity(
                activeDeal.property.assessedValue,
                activeDeal.property.estimatedDebt
              )
            )}
          </span>
        </div>
      </button>
    ) : null;

  return (
    <>
      {/* Mobile-First Sticky Top App Bar (56px = h-14) */}
      <header className="lg:hidden sticky top-0 z-40 h-14 bg-[#070B14] text-slate-100 border-b border-white/[0.08] px-3 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <button
            type="button"
            aria-label="Open navigation menu"
            aria-expanded={drawerOpen}
            onClick={() => setDrawerOpen(true)}
            className="w-11 h-11 -ml-1 rounded-lg flex items-center justify-center text-slate-200 hover:bg-white/[0.06] active:bg-white/10 shrink-0"
          >
            <Menu className="w-5 h-5" />
          </button>
          <span className="font-display text-base font-bold tracking-tight text-white truncate">
            CaseLot US
          </span>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          <button
            type="button"
            onClick={onToggleTheme}
            aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
            className="w-10 h-10 rounded-lg border border-white/10 bg-white/[0.04] hover:bg-white/10 text-slate-300 flex items-center justify-center"
          >
            {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
          </button>

          <button
            type="button"
            onClick={onOpenPricing}
            aria-label={`Current plan: ${PLAN_LABELS[planTier]}. Open plans`}
            className="px-2.5 h-10 rounded-lg border border-white/10 bg-white/[0.04] hover:bg-white/10 text-slate-200 text-xs font-medium flex items-center gap-1 whitespace-nowrap"
          >
            <Crown className="w-3.5 h-3.5 text-amber-400" />
            <span>{planTier === 'free' ? 'Free' : planTier === 'pro' ? 'Pro' : 'AI'}</span>
          </button>

          <button
            type="button"
            onClick={onOpenIngest}
            className="px-3 h-10 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap"
          >
            <UploadCloud className="w-3.5 h-3.5" />
            Ingest
          </button>
        </div>
      </header>

      {/* Mobile Slide-Over Hamburger Navigation Drawer */}
      {drawerOpen && (
        <div
          className="lg:hidden fixed inset-0 z-50 flex"
          role="dialog"
          aria-modal="true"
          aria-label="Mobile Navigation Drawer"
        >
          <div
            className="fixed inset-0 bg-slate-950/75"
            onClick={() => setDrawerOpen(false)}
          />
          <div className="relative w-[284px] max-w-[85vw] h-full bg-[#070B14] text-slate-100 border-r border-white/[0.08] flex flex-col justify-between overflow-y-auto shadow-2xl">
            <div className="p-4 space-y-4">
              <div className="flex items-center justify-between gap-2 pb-3 border-b border-white/[0.08]">
                <div>
                  <span className="font-display text-lg font-bold text-white">CaseLot US</span>
                  <p className="text-[11px] text-slate-400">US Probate & Spatial Intel</p>
                </div>
                <button
                  type="button"
                  aria-label="Close navigation menu"
                  onClick={() => setDrawerOpen(false)}
                  className="w-11 h-11 rounded-lg flex items-center justify-center text-slate-300 hover:bg-white/[0.06]"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {renderNavList()}

              <div className="pt-4 border-t border-white/[0.08] space-y-2">
                <button
                  type="button"
                  onClick={() => {
                    setDrawerOpen(false);
                    onOpenIngest();
                  }}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold flex items-center justify-center gap-2"
                >
                  <UploadCloud className="w-4 h-4" />
                  Ingest US Filing / PDF
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setDrawerOpen(false);
                    onOpenPricing();
                  }}
                  className="w-full px-3.5 py-2 rounded-xl border border-white/10 bg-white/[0.04] hover:bg-white/[0.08] text-slate-200 text-xs font-medium flex items-center justify-between gap-2"
                >
                  <span className="flex items-center gap-2 truncate">
                    <Crown className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span className="truncate">{PLAN_LABELS[planTier]}</span>
                  </span>
                  <span className="text-[11px] font-semibold text-sky-400 shrink-0">
                    {planTier === 'free' ? 'Plans' : 'Manage'}
                  </span>
                </button>

                <PWAInstallButton compact />

                <button
                  type="button"
                  onClick={() => void handleCopyOnlineUrl()}
                  className="w-full px-3 py-2 rounded-xl border border-white/10 bg-white/[0.03] hover:bg-white/[0.08] text-slate-200 text-xs font-medium flex items-center justify-center gap-2"
                >
                  {copiedUrl ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Share2 className="w-3.5 h-3.5 text-slate-400" />}
                  {copiedUrl ? 'Copied Online App URL' : 'Copy Online App URL'}
                </button>
              </div>
            </div>

            {renderActiveEstateCard()}
          </div>
        </div>
      )}

      {/* Desktop Left Sidebar (lg and above) */}
      <aside className="hidden lg:flex lg:w-[260px] shrink-0 bg-[#070B14] text-slate-100 border-r border-white/[0.08] flex-col justify-between">
        <div className="p-5">
          <div className="flex items-center justify-between gap-2">
            <div>
              <span className="font-display text-lg font-bold tracking-tight text-white">
                CaseLot US
              </span>
              <p className="text-xs text-slate-400 mt-0.5">US Probate & Spatial Intel</p>
            </div>

            <button
              type="button"
              onClick={onToggleTheme}
              aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
              title={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
              className="p-2 rounded-lg border border-white/10 bg-white/[0.04] hover:bg-white/10 text-slate-300 hover:text-white transition-colors"
            >
              {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
            </button>
          </div>

          <div className="mt-6">{renderNavList()}</div>

          <div className="mt-5 pt-5 border-t border-white/[0.08] space-y-2.5">
            <button
              type="button"
              onClick={onOpenIngest}
              className="w-full px-3.5 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold flex items-center justify-center gap-2 transition-colors whitespace-nowrap"
            >
              <UploadCloud className="w-4 h-4" />
              Ingest US Filing / PDF
            </button>

            <button
              type="button"
              onClick={onOpenPricing}
              className="w-full px-3.5 py-2 rounded-xl border border-white/10 bg-white/[0.04] hover:bg-white/[0.08] text-slate-200 text-xs font-medium flex items-center justify-between gap-2 transition-colors"
            >
              <span className="flex items-center gap-2 truncate">
                <Crown className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span className="truncate">{PLAN_LABELS[planTier]}</span>
              </span>
              <span className="text-[11px] font-semibold text-sky-400 shrink-0">
                {planTier === 'free' ? 'Plans' : 'Manage'}
              </span>
            </button>

            <PWAInstallButton />

            <button
              type="button"
              onClick={() => void handleCopyOnlineUrl()}
              className="w-full px-3.5 py-2 rounded-xl border border-white/10 bg-white/[0.03] hover:bg-white/[0.08] text-slate-300 text-xs font-medium flex items-center justify-center gap-2 transition-colors whitespace-nowrap"
            >
              {copiedUrl ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Share2 className="w-3.5 h-3.5 text-slate-400" />}
              {copiedUrl ? 'Online URL Copied' : 'Share Online URL'}
            </button>
          </div>
        </div>

        {renderActiveEstateCard()}
      </aside>

      {/* Mobile Fixed Bottom Thumb-Zone Navigation Bar (64px = h-16) */}
      <nav
        aria-label="Mobile Quick Navigation"
        className="lg:hidden fixed bottom-0 left-0 right-0 z-40 h-16 bg-[#070B14]/95 border-t border-white/[0.08] grid grid-cols-4 items-center px-1"
      >
        {[
          { id: 'discover' as const, label: 'Search', icon: Compass },
          { id: 'property' as const, label: '3D/AR/VR', icon: Building2 },
          { id: 'pipeline' as const, label: 'Pipeline', icon: Kanban },
        ].map((tab) => {
          const Icon = tab.icon;
          const active = activeWorkspace === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => handleSelectNav(tab.id)}
              className={`h-full flex flex-col items-center justify-center gap-1 text-[11px] font-medium ${
                active ? 'text-sky-400' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
        <button
          type="button"
          onClick={() => setDrawerOpen(true)}
          className="h-full flex flex-col items-center justify-center gap-1 text-[11px] font-medium text-slate-400 hover:text-slate-200"
        >
          <Menu className="w-4 h-4" />
          <span>Menu</span>
        </button>
      </nav>
    </>
  );
};
