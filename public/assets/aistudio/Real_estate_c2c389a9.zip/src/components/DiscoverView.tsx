import React, { useMemo, useState } from 'react';
import {
  ArrowRight,
  Bookmark,
  Building2,
  ChevronRight,
  Database,
  Download,
  Filter,
  Globe2,
  Layers,
  Loader2,
  Lock,
  MapPin,
  Plus,
  RotateCcw,
  Scale,
  Search,
  Sparkles,
  Trash2,
  UploadCloud,
} from 'lucide-react';
import type {
  CrmDeal,
  DiscoverFilters,
  Jurisdiction,
  PlanTier,
  SavedSearch,
  ThemeMode,
} from '../types/caselot';
import {
  calculateEstimatedEquity,
  filterProbateDeals,
  formatCurrency,
  hasActiveSearchFilters,
  parseNaturalLanguageQueryFallback,
} from '../utils/probateLogic';
import { US_STATE_PROBATE_RULES, getStateProbateStatute } from '../utils/usRegulations';
import { analyzeStakeholderHierarchy } from '../utils/valuationAndIntegrations';
import { SpatialAtlas3D } from './SpatialAtlas3D';
import { GoogleParcelMap } from './GoogleParcelMap';

interface DiscoverViewProps {
  deals: CrmDeal[];
  jurisdictions: Jurisdiction[];
  filters: DiscoverFilters;
  onChangeFilters: (next: DiscoverFilters) => void;
  savedSearches: SavedSearch[];
  onSaveSearch: (name: string, alertFrequency: SavedSearch['alertFrequency']) => void;
  onDeleteSavedSearch: (id: string) => void;
  selectedDealId: string | null;
  onSelectDeal: (dealId: string) => void;
  onOpenDossier: (dealId: string) => void;
  onOpenPropertyPage: (dealId: string) => void;
  onAddToPipeline: (dealId: string) => void;
  onOpenHubForState: (stateCode: string) => void;
  onOpenIngest: () => void;
  mapsApiKey: string;
  theme: ThemeMode;
  planTier: PlanTier;
  onRequireUpgrade: (featureName: string) => void;
}

type MapDisplayMode = 'google' | '3d' | 'split' | 'hidden';

const CURATED_US_PRESETS: {
  id: string;
  title: string;
  regionLabel: string;
  summary: string;
  filters: Partial<DiscoverFilters>;
}[] = [
  {
    id: 'preset-tx-prose',
    title: 'Texas Independent · Pro Se',
    regionLabel: 'Harris & Travis Counties, TX',
    summary: 'No court confirmation delay, unrepresented executors, $150k+ net equity.',
    filters: {
      stateCode: 'TX',
      countyName: 'ALL',
      adminType: 'Independent',
      attorneyStatus: 'no-attorney',
      minEquity: 150000,
      propertyType: 'All',
      searchQuery: '',
    },
  },
  {
    id: 'preset-sunbelt',
    title: 'Sunbelt High-Equity Estates',
    regionLabel: 'Maricopa, AZ & Miami-Dade, FL',
    summary: 'High-equity single-family & multi-family probate filings in fast-appreciating metros.',
    filters: {
      stateCode: 'AZ',
      countyName: 'Maricopa',
      adminType: 'all',
      attorneyStatus: 'all',
      minEquity: 200000,
      propertyType: 'All',
      searchQuery: '',
    },
  },
  {
    id: 'preset-fl-commercial',
    title: 'Florida Circuit & Summary',
    regionLabel: 'Miami-Dade County, FL',
    summary: 'Formal power-of-sale & Summary Administration (>2 yr) residential and commercial tracts.',
    filters: {
      stateCode: 'FL',
      countyName: 'Miami-Dade',
      adminType: 'all',
      attorneyStatus: 'all',
      minEquity: 100000,
      propertyType: 'All',
      searchQuery: '',
    },
  },
];

export const DiscoverView: React.FC<DiscoverViewProps> = ({
  deals,
  jurisdictions,
  filters,
  onChangeFilters,
  savedSearches,
  onSaveSearch,
  onDeleteSavedSearch,
  selectedDealId,
  onSelectDeal,
  onOpenDossier,
  onOpenPropertyPage,
  onAddToPipeline,
  onOpenHubForState,
  onOpenIngest,
  mapsApiKey,
  theme,
  planTier,
  onRequireUpgrade,
}) => {
  const [searchExecuted, setSearchExecuted] = useState<boolean>(() =>
    hasActiveSearchFilters(filters)
  );
  const [aiQuery, setAiQuery] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const [aiBanner, setAiBanner] = useState<string | null>(null);
  const [mapMode, setMapMode] = useState<MapDisplayMode>('google');
  const [showSaveForm, setShowSaveForm] = useState(false);
  const [saveName, setSaveName] = useState('');
  const [saveFrequency, setSaveFrequency] = useState<SavedSearch['alertFrequency']>('Daily Digest');

  const connectedStateCodes = useMemo(
    () => new Set(jurisdictions.map((j) => j.stateCode)),
    [jurisdictions]
  );

  const availableCounties = useMemo(() => {
    return jurisdictions.filter(
      (j) => filters.stateCode === 'ALL' || j.stateCode === filters.stateCode
    );
  }, [jurisdictions, filters.stateCode]);

  const activeJurisdiction = useMemo(() => {
    if (filters.countyName !== 'ALL') {
      return jurisdictions.find(
        (j) =>
          j.countyName === filters.countyName &&
          (filters.stateCode === 'ALL' || j.stateCode === filters.stateCode)
      );
    }
    return undefined;
  }, [jurisdictions, filters.countyName, filters.stateCode]);

  const filteredDeals = useMemo(() => filterProbateDeals(deals, filters), [deals, filters]);

  const totalFilteredEquity = useMemo(
    () =>
      filteredDeals.reduce(
        (sum, d) => sum + calculateEstimatedEquity(d.property.assessedValue, d.property.estimatedDebt),
        0
      ),
    [filteredDeals]
  );

  const showResultsWorkspace = searchExecuted || hasActiveSearchFilters(filters);

  const runStructuredSearch = () => {
    setSearchExecuted(true);
  };

  const handleAiSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = aiQuery.trim();
    if (!trimmed) {
      setSearchExecuted(true);
      return;
    }

    setAiLoading(true);
    setAiBanner(null);
    try {
      const res = await fetch('/api/ai/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: trimmed }),
      });
      if (!res.ok) throw new Error('Search request failed');
      const data = await res.json();
      onChangeFilters({
        ...filters,
        ...data.filters,
      });
      setAiBanner(data.explanation || 'Applied AI search parameters.');
      setSearchExecuted(true);
    } catch {
      const patch = parseNaturalLanguageQueryFallback(trimmed);
      onChangeFilters({ ...filters, ...patch });
      setAiBanner('Applied structured US probate filter match.');
      setSearchExecuted(true);
    } finally {
      setAiLoading(false);
    }
  };

  const handleResetFilters = () => {
    setAiQuery('');
    setAiBanner(null);
    setSearchExecuted(false);
    onChangeFilters({
      stateCode: 'ALL',
      countyName: 'ALL',
      filingWindowDays: 0,
      propertyType: 'All',
      minEquity: 0,
      attorneyStatus: 'all',
      adminType: 'all',
      searchQuery: '',
    });
  };

  const handleApplyPreset = (presetFilters: Partial<DiscoverFilters>, label: string) => {
    onChangeFilters({
      stateCode: 'ALL',
      countyName: 'ALL',
      filingWindowDays: 0,
      propertyType: 'All',
      minEquity: 0,
      attorneyStatus: 'all',
      adminType: 'all',
      searchQuery: '',
      ...presetFilters,
    });
    setAiBanner(`Loaded US territory search: ${label}`);
    setSearchExecuted(true);
  };

  const handleCreateSavedSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!saveName.trim()) return;
    onSaveSearch(saveName.trim(), saveFrequency);
    setSaveName('');
    setShowSaveForm(false);
  };

  const handleBulkExportCsv = () => {
    if (planTier === 'free') {
      onRequireUpgrade('Bulk Tax-Roll & Direct Mail CSV Export');
      return;
    }
    const header = [
      'CaseNumber',
      'Decedent',
      'AdminType',
      'PropertyAddress',
      'City',
      'State',
      'County',
      'ZIP',
      'APN',
      'AssessedValue',
      'EstEquity',
    ];
    const rows = filteredDeals.map((d) =>
      [
        d.probateCase.caseNumber,
        `"${d.probateCase.decedentName}"`,
        d.probateCase.adminType,
        `"${d.property.address}"`,
        `"${d.property.city}"`,
        d.property.stateCode,
        d.property.countyName,
        d.property.zip,
        d.property.parcelId,
        d.property.assessedValue,
        calculateEstimatedEquity(d.property.assessedValue, d.property.estimatedDebt),
      ].join(',')
    );
    const csv = [header.join(','), ...rows].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `caselot-us-probate-export-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const renderFilterInputs = (compact = false) => (
    <div className={`grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2.5 ${compact ? '' : 'pt-3'}`}>
      <div>
        <label htmlFor="filter-state" className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
          US State (50 + DC)
        </label>
        <select
          id="filter-state"
          value={filters.stateCode}
          onChange={(e) => {
            onChangeFilters({
              ...filters,
              stateCode: e.target.value,
              countyName: 'ALL',
            });
          }}
          className="w-full px-2.5 py-2 rounded-lg border border-slate-300 dark:border-white/15 bg-white dark:bg-[#070B14] text-xs text-slate-900 dark:text-slate-100"
        >
          <option value="ALL">Select US State (All)</option>
          {US_STATE_PROBATE_RULES.map((st) => (
            <option key={st.stateCode} value={st.stateCode}>
              {st.stateName} ({st.stateCode}) {connectedStateCodes.has(st.stateCode) ? '· Live' : ''}
            </option>
          ))}
        </select>
      </div>

      <div>
        <label htmlFor="filter-county" className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
          County Docket
        </label>
        <select
          id="filter-county"
          value={filters.countyName}
          onChange={(e) =>
            onChangeFilters({
              ...filters,
              countyName: e.target.value,
            })
          }
          className="w-full px-2.5 py-2 rounded-lg border border-slate-300 dark:border-white/15 bg-white dark:bg-[#070B14] text-xs text-slate-900 dark:text-slate-100"
        >
          <option value="ALL">
            {availableCounties.length > 0 ? 'All Connected Counties' : 'Statutory Lookup / Ingest'}
          </option>
          {availableCounties.map((j) => (
            <option key={j.id} value={j.countyName}>
              {j.countyName} ({j.stateCode})
            </option>
          ))}
        </select>
      </div>

      <div>
        <label htmlFor="filter-property-type" className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
          Asset Type
        </label>
        <select
          id="filter-property-type"
          value={filters.propertyType}
          onChange={(e) => onChangeFilters({ ...filters, propertyType: e.target.value })}
          className="w-full px-2.5 py-2 rounded-lg border border-slate-300 dark:border-white/15 bg-white dark:bg-[#070B14] text-xs text-slate-900 dark:text-slate-100"
        >
          <option value="All">All Asset Types</option>
          <option value="Single-Family">Single-Family</option>
          <option value="Multi-Family">Multi-Family</option>
          <option value="Land / Lot">Land / Lot</option>
          <option value="Commercial">Commercial</option>
        </select>
      </div>

      <div>
        <label htmlFor="filter-admin" className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
          Administration
        </label>
        <select
          id="filter-admin"
          value={filters.adminType}
          onChange={(e) =>
            onChangeFilters({
              ...filters,
              adminType: e.target.value as DiscoverFilters['adminType'],
            })
          }
          className="w-full px-2.5 py-2 rounded-lg border border-slate-300 dark:border-white/15 bg-white dark:bg-[#070B14] text-xs text-slate-900 dark:text-slate-100"
        >
          <option value="all">All Admin Types</option>
          <option value="Independent">Independent</option>
          <option value="Dependent / Supervised">Dependent / Supervised</option>
          <option value="Informal">Informal</option>
          <option value="Summary">Summary</option>
        </select>
      </div>

      <div>
        <label htmlFor="filter-attorney" className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
          Representation
        </label>
        <select
          id="filter-attorney"
          value={filters.attorneyStatus}
          onChange={(e) =>
            onChangeFilters({
              ...filters,
              attorneyStatus: e.target.value as DiscoverFilters['attorneyStatus'],
            })
          }
          className="w-full px-2.5 py-2 rounded-lg border border-slate-300 dark:border-white/15 bg-white dark:bg-[#070B14] text-xs text-slate-900 dark:text-slate-100"
        >
          <option value="all">All Filings</option>
          <option value="no-attorney">No Attorney (Pro Se)</option>
          <option value="represented">Attorney Listed</option>
        </select>
      </div>

      <div>
        <label htmlFor="filter-equity" className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
          Min Net Equity
        </label>
        <select
          id="filter-equity"
          value={filters.minEquity}
          onChange={(e) => onChangeFilters({ ...filters, minEquity: Number(e.target.value) })}
          className="w-full px-2.5 py-2 rounded-lg border border-slate-300 dark:border-white/15 bg-white dark:bg-[#070B14] text-xs text-slate-900 dark:text-slate-100 tabular-nums"
        >
          <option value={0}>Any Equity</option>
          <option value={100000}>$100,000+</option>
          <option value={200000}>$200,000+</option>
          <option value={300000}>$300,000+</option>
          <option value={400000}>$400,000+</option>
        </select>
      </div>
    </div>
  );

  // ============================================================================
  // SEARCH-FIRST STUDIO (Initial simplified state — never dumps nationwide rows)
  // ============================================================================
  if (!showResultsWorkspace) {
    return (
      <div className="space-y-6 py-2">
        {/* Hero Search Gate */}
        <section className="bento-card spatial-hero-mesh p-6 sm:p-8 lg:p-10 space-y-6">
          <div className="max-w-3xl space-y-2.5">
            <div className="text-xs font-semibold uppercase tracking-wider text-sky-600 dark:text-sky-400">
              United States Probate & Off-Market Spatial Engine
            </div>
            <h1 className="font-display text-2xl sm:text-4xl font-bold tracking-tight text-slate-900 dark:text-white leading-[1.12]">
              Set your US search parameters to uncover matched estate properties.
            </h1>
            <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed">
              Query by US state, county, ZIP, equity spread, or administration type—then inspect
              matched estates with 3D/AR/VR property twins, creative underwriting, and federal/state compliance gates.
            </p>
          </div>

          {/* Primary Search Form */}
          <form onSubmit={handleAiSearch} className="space-y-4">
            <div className="flex flex-col sm:flex-row gap-2.5">
              <div className="relative flex-1">
                <Sparkles className="w-4 h-4 text-sky-500 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  aria-label="Search US probate properties by state, county, ZIP, or AI criteria"
                  value={aiQuery}
                  onChange={(e) => setAiQuery(e.target.value)}
                  placeholder='Search US estates: "Independent homes in Harris County TX over $200k equity, no attorney" or "77025"'
                  className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-300 dark:border-white/15 bg-white dark:bg-[#070B14] text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>

              <button
                type="submit"
                disabled={aiLoading}
                className="px-6 py-3 rounded-xl bg-sky-600 hover:bg-sky-500 disabled:opacity-60 text-white text-sm font-semibold flex items-center justify-center gap-2 whitespace-nowrap shrink-0 transition-colors"
              >
                {aiLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                Search US Estates
              </button>
            </div>

            {/* Structured Parameter Matrix */}
            <div className="bento-inset p-4 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-200">
                  Target Jurisdiction & Equity Parameters
                </span>
                <button
                  type="button"
                  onClick={runStructuredSearch}
                  className="text-xs font-semibold text-sky-600 dark:text-sky-400 hover:underline inline-flex items-center gap-1"
                >
                  Apply Selected Filters
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
              {renderFilterInputs(true)}
            </div>
          </form>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-200/80 dark:border-white/[0.08] text-xs text-slate-600 dark:text-slate-400">
            <div className="flex flex-wrap items-center gap-2">
              <Database className="w-3.5 h-3.5 text-sky-500" />
              <span>
                <strong className="text-slate-900 dark:text-white">{jurisdictions.length} Live US County Feeds</strong>{' '}
                (TX, AZ, FL, IL, GA) · All 50 States + DC Statutory Compliance Ready
              </span>
            </div>

            <button
              type="button"
              onClick={() => setSearchExecuted(true)}
              className="text-xs font-semibold text-slate-700 dark:text-slate-200 hover:text-sky-600 dark:hover:text-sky-400 underline underline-offset-4"
            >
              Browse All {deals.length} Connected US Estates
            </button>
          </div>
        </section>

        {/* Bento Row: Curated US Regional Presets + Saved Watchlist Alerts */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          <div className="lg:col-span-8 grid grid-cols-1 md:grid-cols-3 gap-4">
            {CURATED_US_PRESETS.map((preset) => (
              <button
                key={preset.id}
                type="button"
                onClick={() => handleApplyPreset(preset.filters, preset.title)}
                className="bento-card p-5 text-left hover:border-sky-500/50 transition-colors flex flex-col justify-between gap-4 group"
              >
                <div className="space-y-1.5">
                  <div className="text-[11px] font-mono text-sky-600 dark:text-sky-400">
                    {preset.regionLabel}
                  </div>
                  <h2 className="font-display text-base font-bold text-slate-900 dark:text-white group-hover:text-sky-500 transition-colors">
                    {preset.title}
                  </h2>
                  <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                    {preset.summary}
                  </p>
                </div>
                <div className="text-xs font-semibold text-slate-900 dark:text-slate-200 inline-flex items-center gap-1.5">
                  Run Territory Search
                  <ArrowRight className="w-3.5 h-3.5 text-sky-500" />
                </div>
              </button>
            ))}
          </div>

          {/* Saved Alerts & Quick Ingest Card */}
          <div className="lg:col-span-4 bento-card p-5 flex flex-col justify-between gap-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between gap-2">
                <h2 className="font-display text-sm font-bold text-slate-900 dark:text-white">
                  Saved Docket Alerts
                </h2>
                <span className="font-mono text-xs text-slate-500 dark:text-slate-400 tabular-nums">
                  {savedSearches.length} active
                </span>
              </div>

              <div className="space-y-2">
                {savedSearches.map((ss) => (
                  <div
                    key={ss.id}
                    className="bento-inset p-2.5 flex items-center justify-between gap-2 text-xs"
                  >
                    <button
                      type="button"
                      onClick={() => handleApplyPreset(ss.filters, ss.name)}
                      className="text-left min-w-0 flex-1 hover:text-sky-500 transition-colors"
                    >
                      <div className="font-semibold text-slate-900 dark:text-slate-100 truncate">
                        {ss.name}
                      </div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400">
                        {ss.alertFrequency} · Created {ss.createdAt}
                      </div>
                    </button>
                    <button
                      type="button"
                      aria-label={`Delete saved search ${ss.name}`}
                      onClick={() => onDeleteSavedSearch(ss.id)}
                      className="p-1.5 text-slate-400 hover:text-rose-500 shrink-0"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            <button
              type="button"
              onClick={onOpenIngest}
              className="w-full py-2.5 px-3 rounded-xl border border-slate-300 dark:border-white/15 hover:bg-slate-100 dark:hover:bg-white/[0.05] text-xs font-semibold text-slate-800 dark:text-slate-200 flex items-center justify-center gap-2 transition-colors"
            >
              <UploadCloud className="w-4 h-4 text-sky-500" />
              Ingest Any US Court Docket PDF
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ============================================================================
  // ACTIVE SEARCH RESULTS WORKSPACE
  // ============================================================================
  const selectedStateStatute =
    filters.stateCode !== 'ALL' ? getStateProbateStatute(filters.stateCode) : null;

  return (
    <div className="space-y-5">
      {/* Header & Map Switcher */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="flex flex-wrap items-center gap-2 text-xs text-sky-600 dark:text-sky-400 font-semibold">
            <span>United States Probate Results</span>
            <span className="text-slate-400">·</span>
            <button
              type="button"
              onClick={handleResetFilters}
              className="inline-flex items-center gap-1 hover:underline"
            >
              <RotateCcw className="w-3 h-3" />
              New Search / Edit Parameters
            </button>
          </div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-slate-900 dark:text-white mt-0.5">
            Matched US Probate Estates
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div
            role="group"
            aria-label="Map display mode"
            className="inline-flex rounded-lg border border-slate-300 dark:border-white/15 bg-white dark:bg-[#0B111E] p-0.5 text-xs"
          >
            <button
              type="button"
              onClick={() => setMapMode('google')}
              className={`px-2.5 py-1.5 rounded-md font-semibold flex items-center gap-1.5 whitespace-nowrap ${
                mapMode === 'google'
                  ? 'bg-slate-900 dark:bg-sky-600 text-white'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/[0.06]'
              }`}
            >
              <Globe2 className="w-3.5 h-3.5" />
              Google Maps
            </button>
            <button
              type="button"
              onClick={() => setMapMode('3d')}
              className={`px-2.5 py-1.5 rounded-md font-semibold flex items-center gap-1.5 whitespace-nowrap ${
                mapMode === '3d'
                  ? 'bg-slate-900 dark:bg-sky-600 text-white'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/[0.06]'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              3D Atlas
            </button>
            <button
              type="button"
              onClick={() => setMapMode('split')}
              className={`px-2.5 py-1.5 rounded-md font-semibold whitespace-nowrap ${
                mapMode === 'split'
                  ? 'bg-slate-900 dark:bg-sky-600 text-white'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/[0.06]'
              }`}
            >
              Split
            </button>
            <button
              type="button"
              onClick={() => setMapMode('hidden')}
              className={`px-2.5 py-1.5 rounded-md font-medium whitespace-nowrap ${
                mapMode === 'hidden'
                  ? 'bg-slate-900 dark:bg-sky-600 text-white'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-white/[0.06]'
              }`}
            >
              Hide
            </button>
          </div>

          <button
            type="button"
            onClick={() => setShowSaveForm((v) => !v)}
            className="px-3 py-2 rounded-lg bg-slate-900 dark:bg-white/[0.08] hover:bg-slate-800 dark:hover:bg-white/[0.14] border border-transparent dark:border-white/10 text-white text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap"
          >
            <Bookmark className="w-3.5 h-3.5" />
            Save Search
          </button>
        </div>
      </div>

      {/* Save Search Inline Bar */}
      {showSaveForm && (
        <form
          onSubmit={handleCreateSavedSearch}
          className="bento-card p-4 flex flex-wrap items-center gap-3"
        >
          <label htmlFor="saved-search-name" className="text-xs font-semibold text-slate-700 dark:text-slate-300">
            Save Current Filters:
          </label>
          <input
            id="saved-search-name"
            type="text"
            required
            value={saveName}
            onChange={(e) => setSaveName(e.target.value)}
            placeholder="e.g., Harris Independent Pro Se > $200k"
            className="flex-1 min-w-[220px] px-3 py-1.5 rounded-lg border border-slate-300 dark:border-white/15 bg-white dark:bg-[#070B14] text-xs text-slate-900 dark:text-slate-100"
          />
          <select
            aria-label="Alert frequency"
            value={saveFrequency}
            onChange={(e) => setSaveFrequency(e.target.value as SavedSearch['alertFrequency'])}
            className="px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-white/15 text-xs text-slate-800 dark:text-slate-100 bg-white dark:bg-[#070B14]"
          >
            <option value="Daily Digest">Daily Digest</option>
            <option value="Instant">Instant Alert</option>
            <option value="Weekly">Weekly Summary</option>
          </select>
          <button
            type="submit"
            className="px-3.5 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold"
          >
            Create Alert
          </button>
        </form>
      )}

      {/* Search & Filter Control Card */}
      <div className="bento-card p-4 space-y-3.5">
        <form onSubmit={handleAiSearch} className="flex flex-col sm:flex-row gap-2.5">
          <div className="relative flex-1">
            <Sparkles className="w-4 h-4 text-sky-500 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              aria-label="Smart AI Docket Search"
              value={aiQuery}
              onChange={(e) => setAiQuery(e.target.value)}
              placeholder='Refine US query: "Independent homes in Harris County with $200k equity and no attorney"'
              className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-300 dark:border-white/15 bg-white dark:bg-[#070B14] text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-sky-500"
            />
          </div>
          <button
            type="submit"
            disabled={aiLoading}
            className="px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 disabled:opacity-60 text-white text-xs font-semibold flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0"
          >
            {aiLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Search className="w-3.5 h-3.5" />}
            Run AI Search
          </button>
          <button
            type="button"
            onClick={handleResetFilters}
            className="px-3 py-2 rounded-lg border border-slate-300 dark:border-white/15 hover:bg-slate-50 dark:hover:bg-white/[0.06] text-xs font-medium text-slate-700 dark:text-slate-300 whitespace-nowrap shrink-0"
          >
            Clear Search
          </button>
        </form>

        {aiBanner && (
          <div className="px-3 py-2 rounded-lg bg-sky-50 dark:bg-sky-950/60 border border-sky-200 dark:border-sky-800 text-xs text-sky-900 dark:text-sky-200 flex items-center justify-between gap-2">
            <span>{aiBanner}</span>
            <button
              type="button"
              onClick={() => setAiBanner(null)}
              className="text-sky-700 dark:text-sky-300 hover:text-sky-950 dark:hover:text-white font-semibold"
            >
              Dismiss
            </button>
          </div>
        )}

        <div className="border-t border-slate-100 dark:border-white/[0.08]">
          {renderFilterInputs(false)}
        </div>

        {/* Active Connector Coverage Strip */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100 dark:border-white/[0.08] text-xs">
          <div className="flex items-center gap-2 text-slate-600 dark:text-slate-400">
            <Database className="w-3.5 h-3.5 text-slate-400" />
            {activeJurisdiction ? (
              <span>
                <strong className="text-slate-900 dark:text-slate-100">
                  {activeJurisdiction.countyName}, {activeJurisdiction.stateCode}
                </strong>{' '}
                · {activeJurisdiction.scrapingAdapter} · {activeJurisdiction.connectorStatus} ·
                Synced {activeJurisdiction.lastSyncedAt}
              </span>
            ) : (
              <span>
                Scope: <strong className="text-slate-900 dark:text-slate-100">United States ({filters.stateCode === 'ALL' ? 'Connected US Counties' : filters.stateCode})</strong>
              </span>
            )}
          </div>

          <div className="flex items-center gap-4 font-mono text-xs text-slate-700 dark:text-slate-300 tabular-nums">
            <span>{filteredDeals.length} matching estates</span>
            <span className="text-slate-300 dark:text-slate-700" aria-hidden="true">|</span>
            <span>{formatCurrency(totalFilteredEquity)} total equity</span>
          </div>
        </div>
      </div>

      {/* Saved Searches Quick Bar */}
      {savedSearches.length > 0 && (
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-medium text-slate-500 dark:text-slate-400 flex items-center gap-1 mr-1">
            <Filter className="w-3.5 h-3.5" />
            Saved Alerts:
          </span>
          {savedSearches.map((ss) => (
            <div
              key={ss.id}
              className="inline-flex items-center bg-white dark:bg-[#0B111E] border border-slate-200 dark:border-white/10 rounded-lg overflow-hidden text-xs"
            >
              <button
                type="button"
                onClick={() => handleApplyPreset(ss.filters, ss.name)}
                className="px-2.5 py-1.5 hover:bg-slate-50 dark:hover:bg-white/[0.05] text-slate-800 dark:text-slate-200 font-medium text-left"
              >
                {ss.name} <span className="text-slate-400">· {ss.alertFrequency}</span>
              </button>
              <button
                type="button"
                aria-label={`Delete saved search ${ss.name}`}
                onClick={() => onDeleteSavedSearch(ss.id)}
                className="px-2 py-1.5 border-l border-slate-200 dark:border-white/10 text-slate-400 hover:text-rose-500"
              >
                <Trash2 className="w-3 h-3" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Map Layer: Google Maps Parcel Explorer & 3D Spatial Atlas */}
      {mapMode !== 'hidden' && (
        <div className={mapMode === 'split' ? 'grid grid-cols-1 xl:grid-cols-2 gap-4' : 'space-y-4'}>
          {(mapMode === 'google' || mapMode === 'split') && (
            <GoogleParcelMap
              apiKey={mapsApiKey}
              deals={filteredDeals}
              selectedDealId={selectedDealId}
              theme={theme}
              onSelectDeal={onSelectDeal}
              onOpenDossier={onOpenDossier}
              onOpenPropertyPage={onOpenPropertyPage}
              onLocationFilter={(cityLabel) => {
                if (cityLabel) {
                  setAiBanner(`Google Maps US focused on ${cityLabel}.`);
                }
              }}
            />
          )}

          {(mapMode === '3d' || mapMode === 'split') && (
            <SpatialAtlas3D
              deals={filteredDeals}
              selectedDealId={selectedDealId}
              theme={theme}
              onSelectDeal={onSelectDeal}
              onOpenDossier={onOpenDossier}
            />
          )}
        </div>
      )}

      {/* High-Density Matched Estates Table / Cards */}
      <div className="bento-card overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-200/80 dark:border-white/[0.08] flex flex-wrap items-center justify-between gap-3">
          <h2 className="font-display text-sm font-semibold text-slate-900 dark:text-white">
            Assessor-Matched US Probate Docket Feed
          </h2>
          <div className="flex items-center gap-2.5">
            <div className="relative w-56 sm:w-64">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                aria-label="Filter table by address, decedent, ZIP, or case number"
                value={filters.searchQuery}
                onChange={(e) => onChangeFilters({ ...filters, searchQuery: e.target.value })}
                placeholder="Filter address, ZIP, APN..."
                className="w-full pl-8 pr-2.5 py-1.5 rounded-md border border-slate-300 dark:border-white/15 bg-white dark:bg-[#070B14] text-xs text-slate-900 dark:text-slate-100"
              />
            </div>

            <button
              type="button"
              onClick={handleBulkExportCsv}
              className="px-3 py-1.5 rounded-md border border-slate-300 dark:border-white/15 bg-white dark:bg-white/[0.04] hover:bg-slate-50 dark:hover:bg-white/[0.08] text-xs font-semibold text-slate-700 dark:text-slate-200 inline-flex items-center gap-1.5 whitespace-nowrap"
            >
              {planTier === 'free' ? <Lock className="w-3 h-3 text-amber-500" /> : <Download className="w-3 h-3" />}
              Export CSV
            </button>
          </div>
        </div>

        {filteredDeals.length === 0 ? (
          <div className="p-8 sm:p-10 space-y-5">
            {selectedStateStatute ? (
              <div className="bento-inset p-5 max-w-3xl mx-auto space-y-3 text-left">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <Scale className="w-4 h-4 text-sky-500" />
                    <h3 className="font-display text-sm font-bold text-slate-900 dark:text-white">
                      {selectedStateStatute.stateName} ({selectedStateStatute.stateCode}) — Statutory Rules Ready
                    </h3>
                  </div>
                  <span className="font-mono text-[11px] text-slate-500 dark:text-slate-400">
                    {selectedStateStatute.upcAdopted} · {selectedStateStatute.typicalTimelineMonths}
                  </span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  No pre-loaded live court dockets in <strong>{selectedStateStatute.stateName}</strong> match your current filter set yet. You can immediately paste or upload a {selectedStateStatute.stateName} court filing PDF for AI extraction, or inspect its full statutory playbook.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs pt-1">
                  <div>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400 block">Authority & Confirmation</span>
                    <span className="font-medium text-slate-900 dark:text-white">{selectedStateStatute.independentAuthority}</span>
                  </div>
                  <div>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400 block">Creditor Claim Window</span>
                    <span className="font-medium text-slate-900 dark:text-white">{selectedStateStatute.creditorClaimWindow}</span>
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-2.5 pt-2">
                  <button
                    type="button"
                    onClick={onOpenIngest}
                    className="px-3.5 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold inline-flex items-center gap-1.5"
                  >
                    <UploadCloud className="w-3.5 h-3.5" />
                    Ingest {selectedStateStatute.stateCode} Docket / PDF
                  </button>
                  <button
                    type="button"
                    onClick={() => onOpenHubForState(selectedStateStatute.stateCode)}
                    className="px-3.5 py-2 rounded-lg border border-slate-300 dark:border-white/15 bg-white dark:bg-white/[0.04] text-xs font-semibold text-slate-800 dark:text-slate-200 inline-flex items-center gap-1.5"
                  >
                    <Building2 className="w-3.5 h-3.5" />
                    Open {selectedStateStatute.stateName} Compliance Hub
                  </button>
                  <button
                    type="button"
                    onClick={handleResetFilters}
                    className="px-3.5 py-2 rounded-lg text-xs font-medium text-slate-600 dark:text-slate-400 hover:underline"
                  >
                    Return to Search Studio
                  </button>
                </div>
              </div>
            ) : (
              <div className="text-center">
                <MapPin className="w-6 h-6 text-slate-400 mx-auto mb-2" />
                <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">
                  No US probate properties match your current parameter combination.
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Lower your equity threshold, switch US counties, or ingest a new court docket PDF.
                </p>
                <button
                  type="button"
                  onClick={handleResetFilters}
                  className="mt-4 px-3.5 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold"
                >
                  Edit Search Parameters
                </button>
              </div>
            )}
          </div>
        ) : (
          <>
            {/* Mobile-First Card Feed (< md) */}
            <div className="md:hidden divide-y divide-slate-200 dark:divide-white/[0.08]">
              {filteredDeals.map((deal) => {
                const equity = calculateEstimatedEquity(
                  deal.property.assessedValue,
                  deal.property.estimatedDebt
                );
                const hierarchy = analyzeStakeholderHierarchy(deal);
                const isSelected = deal.id === selectedDealId;
                return (
                  <div
                    key={deal.id}
                    onClick={() => onSelectDeal(deal.id)}
                    className={`p-4 space-y-2.5 ${
                      isSelected ? 'bg-sky-50/70 dark:bg-sky-950/35' : ''
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <div className="font-semibold text-sm text-slate-900 dark:text-white truncate">
                          {deal.property.address}
                        </div>
                        <div className="text-xs text-slate-500 dark:text-slate-400">
                          {deal.property.city}, {deal.property.stateCode} {deal.property.zip} · {deal.property.countyName} County
                        </div>
                      </div>
                      <div className="text-right font-mono shrink-0 tabular-nums">
                        <div className="text-sm font-bold text-emerald-700 dark:text-emerald-400">
                          {formatCurrency(equity)}
                        </div>
                        <div className="text-[11px] text-slate-500 dark:text-slate-400">est. equity</div>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-600 dark:text-slate-400">
                      <span className="font-mono">{deal.probateCase.caseNumber}</span>
                      <span>
                        {deal.probateCase.adminType} ·{' '}
                        {hierarchy.outOfStatePr
                          ? `Out-of-State PR (${hierarchy.prStateCode})`
                          : deal.probateCase.hasAttorney
                            ? 'Attorney Listed'
                            : 'Pro Se'}
                      </span>
                    </div>

                    <div
                      className="flex flex-wrap items-center gap-2 pt-1"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <button
                        type="button"
                        onClick={() => onOpenPropertyPage(deal.id)}
                        className="flex-1 py-2 px-3 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold whitespace-nowrap"
                      >
                        Property 360° & AR/VR
                      </button>
                      <button
                        type="button"
                        onClick={() => onOpenDossier(deal.id)}
                        className="py-2 px-3 rounded-lg border border-slate-300 dark:border-white/15 bg-white dark:bg-white/[0.04] text-slate-700 dark:text-slate-200 text-xs font-semibold whitespace-nowrap"
                      >
                        Dossier
                      </button>
                      {!deal.inPipeline && (
                        <button
                          type="button"
                          onClick={() => onAddToPipeline(deal.id)}
                          className="py-2 px-3 rounded-lg border border-slate-300 dark:border-white/15 bg-white dark:bg-white/[0.04] text-slate-700 dark:text-slate-200 text-xs font-semibold whitespace-nowrap"
                        >
                          + Pipeline
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Desktop High-Density Table (md and above) */}
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-white/[0.08] bg-slate-50 dark:bg-[#070B14] text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                    <th className="py-2.5 px-4">Property & APN</th>
                    <th className="py-2.5 px-3">Jurisdiction & Docket</th>
                    <th className="py-2.5 px-3">PR & Counsel</th>
                    <th className="py-2.5 px-3 text-right">Assessor Value</th>
                    <th className="py-2.5 px-3 text-right">Est. Equity</th>
                    <th className="py-2.5 px-3">Data Confidence</th>
                    <th className="py-2.5 px-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-white/[0.06] text-xs">
                  {filteredDeals.map((deal) => {
                    const equity = calculateEstimatedEquity(
                      deal.property.assessedValue,
                      deal.property.estimatedDebt
                    );
                    const hierarchy = analyzeStakeholderHierarchy(deal);
                    const isSelected = deal.id === selectedDealId;
                    return (
                      <tr
                        key={deal.id}
                        onClick={() => onSelectDeal(deal.id)}
                        className={`cursor-pointer transition-colors ${
                          isSelected
                            ? 'bg-sky-50/70 dark:bg-sky-950/35'
                            : 'hover:bg-slate-50 dark:hover:bg-white/[0.03]'
                        }`}
                      >
                        <td className="py-3 px-4">
                          <div className="font-semibold text-slate-900 dark:text-white">{deal.property.address}</div>
                          <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                            {deal.property.city}, {deal.property.stateCode} {deal.property.zip} · {deal.property.propertyType} ·{' '}
                            <span className="font-mono">{deal.property.parcelId}</span>
                          </div>
                        </td>
                        <td className="py-3 px-3">
                          <div className="font-medium text-slate-900 dark:text-slate-200">
                            {deal.property.countyName} County, {deal.property.stateCode}
                          </div>
                          <div className="text-[11px] text-slate-500 dark:text-slate-400 font-mono mt-0.5 tabular-nums">
                            {deal.probateCase.caseNumber} · {deal.probateCase.filingDate}
                          </div>
                        </td>
                        <td className="py-3 px-3">
                          <div className="font-medium text-slate-900 dark:text-slate-200">
                            {deal.probateCase.adminType}
                            {hierarchy.outOfStatePr && (
                              <span className="ml-1.5 text-[11px] font-semibold text-amber-600 dark:text-amber-400">
                                · Out-of-State PR ({hierarchy.prStateCode})
                              </span>
                            )}
                          </div>
                          <div
                            className={`text-[11px] mt-0.5 ${
                              deal.probateCase.hasAttorney
                                ? 'text-slate-500 dark:text-slate-400'
                                : 'text-teal-700 dark:text-teal-400 font-semibold'
                            }`}
                          >
                            {deal.probateCase.hasAttorney ? 'Attorney Listed' : 'No Attorney (Pro Se)'}
                          </div>
                        </td>
                        <td className="py-3 px-3 text-right font-mono text-slate-700 dark:text-slate-300 tabular-nums">
                          {formatCurrency(deal.property.assessedValue)}
                        </td>
                        <td className="py-3 px-3 text-right font-mono font-semibold text-emerald-700 dark:text-emerald-400 tabular-nums">
                          {formatCurrency(equity)}
                        </td>
                        <td className="py-3 px-3">
                          <div className="font-mono font-semibold text-slate-800 dark:text-slate-200 tabular-nums">
                            {deal.property.matchConfidence}%
                          </div>
                          <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate max-w-[165px]">
                            {deal.property.matchSource}
                          </div>
                        </td>
                        <td
                          className="py-3 px-4 text-right whitespace-nowrap"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <div className="inline-flex items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => onOpenPropertyPage(deal.id)}
                              className="px-2.5 py-1 rounded-md bg-sky-600 hover:bg-sky-500 text-white text-[11px] font-semibold inline-flex items-center gap-1"
                            >
                              360° & AR/VR
                            </button>
                            {!deal.inPipeline ? (
                              <button
                                type="button"
                                onClick={() => onAddToPipeline(deal.id)}
                                className="px-2.5 py-1 rounded-md border border-slate-300 dark:border-white/15 bg-white dark:bg-white/[0.04] hover:bg-slate-50 dark:hover:bg-white/[0.08] text-slate-700 dark:text-slate-200 text-[11px] font-semibold inline-flex items-center gap-1"
                              >
                                <Plus className="w-3 h-3" />
                                Pipeline
                              </button>
                            ) : (
                              <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400 px-1.5">
                                {deal.stage}
                              </span>
                            )}
                            <button
                              type="button"
                              onClick={() => onOpenDossier(deal.id)}
                              className="px-2.5 py-1 rounded-md border border-slate-300 dark:border-white/15 bg-white dark:bg-white/[0.04] hover:bg-slate-50 dark:hover:bg-white/[0.08] text-slate-700 dark:text-slate-200 text-[11px] font-semibold inline-flex items-center gap-1"
                            >
                              Dossier
                              <ChevronRight className="w-3 h-3" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>
    </div>
  );
};
