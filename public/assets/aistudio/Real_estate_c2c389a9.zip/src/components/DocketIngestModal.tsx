import React, { useState } from 'react';
import { FileUp, Loader2, Sparkles, X } from 'lucide-react';
import type { AdminType, ExtractedDocketData, PropertyType } from '../types/caselot';
import { SAMPLE_RAW_DOCKETS } from '../data/seedData';
import { extractDocketFallback } from '../utils/probateLogic';

interface DocketIngestModalProps {
  onClose: () => void;
  onImportExtracted: (data: ExtractedDocketData, rawText: string) => void;
}

export const DocketIngestModal: React.FC<DocketIngestModalProps> = ({
  onClose,
  onImportExtracted,
}) => {
  const [rawText, setRawText] = useState(SAMPLE_RAW_DOCKETS[0].text);
  const [extracting, setExtracting] = useState(false);
  const [extracted, setExtracted] = useState<ExtractedDocketData | null>(null);
  const [sourceTag, setSourceTag] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleExtract = async (e: React.FormEvent) => {
    e.preventDefault();
    if (rawText.trim().length < 15) {
      setErrorMsg('Please paste court docket or Inventory PDF text (at least 15 characters).');
      return;
    }

    setExtracting(true);
    setErrorMsg(null);
    try {
      const res = await fetch('/api/ai/extract-docket', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rawText }),
      });
      if (!res.ok) throw new Error('Extraction request failed');
      const data = await res.json();
      setExtracted(data.extracted);
      setSourceTag(data.source || 'gemini-4-hydrogen');
    } catch {
      setExtracted(extractDocketFallback(rawText));
      setSourceTag('local-parser');
    } finally {
      setExtracting(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const text = await file.text();
    setRawText(text.slice(0, 12000));
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/65 flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="ingest-title"
    >
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden shadow-xl">
        <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 flex items-center justify-between">
          <div>
            <h2 id="ingest-title" className="font-display text-base font-bold text-slate-900 dark:text-white">
              Ingest Court Filing / Docket Text
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Extract structured probate parties, case metadata, and assessor-matched parcels into Discover & CRM.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close docket ingest modal"
            className="p-2 rounded-lg text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-200/70 dark:hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 overflow-y-auto grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Left: Raw Docket Input */}
          <form onSubmit={handleExtract} className="lg:col-span-6 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">Load Sample Filing:</span>
              <div className="flex flex-wrap gap-1.5">
                {SAMPLE_RAW_DOCKETS.map((sample) => (
                  <button
                    key={sample.label}
                    type="button"
                    onClick={() => {
                      setRawText(sample.text);
                      setExtracted(null);
                    }}
                    className="px-2 py-1 rounded border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-[11px] font-medium text-slate-700 dark:text-slate-200"
                  >
                    {sample.label.split('—')[0].trim()}
                  </button>
                ))}
              </div>
            </div>

            <label htmlFor="raw-docket-textarea" className="sr-only">
              Raw Court Docket Text
            </label>
            <textarea
              id="raw-docket-textarea"
              rows={11}
              value={rawText}
              onChange={(e) => setRawText(e.target.value)}
              placeholder="Paste raw court docket text, FOIA CSV row, or OCR Inventory & Appraisement..."
              className="w-full p-3 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 font-mono text-xs text-slate-900 dark:text-slate-100 leading-relaxed"
            />

            <div className="flex flex-wrap items-center justify-between gap-2">
              <label className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 inline-flex items-center gap-1.5 cursor-pointer">
                <FileUp className="w-3.5 h-3.5" />
                Upload .txt / .csv
                <input type="file" accept=".txt,.csv" onChange={handleFileUpload} className="sr-only" />
              </label>

              <button
                type="submit"
                disabled={extracting}
                className="px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 disabled:opacity-60 text-white text-xs font-semibold flex items-center gap-1.5"
              >
                {extracting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
                Run Structured Extraction
              </button>
            </div>

            {errorMsg && (
              <div className="p-2.5 rounded-lg bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-xs text-rose-800 dark:text-rose-200">
                {errorMsg}
              </div>
            )}
          </form>

          {/* Right: Structured Extracted JSON Fields */}
          <div className="lg:col-span-6 border border-slate-200 dark:border-slate-800 rounded-xl p-4 bg-slate-50 dark:bg-slate-950/60 flex flex-col justify-between">
            {!extracted ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-10">
                <Sparkles className="w-6 h-6 text-slate-400 mb-2" />
                <p className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Run Structured Extraction to inspect parsed fields
                </p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 max-w-xs">
                  Extracts decedent, executor, counsel, APN, assessed value, debt/liens, and administration type.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-2">
                  <span className="text-xs font-bold text-slate-900 dark:text-white">Extracted Probate Record</span>
                  <span className="font-mono text-[11px] text-slate-500 dark:text-slate-400">{sourceTag}</span>
                </div>

                <div className="grid grid-cols-2 gap-2.5 text-xs">
                  <div>
                    <label className="block text-[11px] text-slate-500 dark:text-slate-400">Decedent Name</label>
                    <input
                      type="text"
                      value={extracted.decedentName}
                      onChange={(e) => setExtracted({ ...extracted, decedentName: e.target.value })}
                      className="w-full px-2 py-1 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 mt-0.5"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-500 dark:text-slate-400">Case Number</label>
                    <input
                      type="text"
                      value={extracted.caseNumber}
                      onChange={(e) => setExtracted({ ...extracted, caseNumber: e.target.value })}
                      className="w-full px-2 py-1 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono text-slate-900 dark:text-slate-100 mt-0.5"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-500 dark:text-slate-400">Executor / PR</label>
                    <input
                      type="text"
                      value={extracted.executorName}
                      onChange={(e) => setExtracted({ ...extracted, executorName: e.target.value })}
                      className="w-full px-2 py-1 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 mt-0.5"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-500 dark:text-slate-400">Admin Type</label>
                    <select
                      value={extracted.adminType}
                      onChange={(e) => setExtracted({ ...extracted, adminType: e.target.value as AdminType })}
                      className="w-full px-2 py-1 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 mt-0.5"
                    >
                      <option value="Independent">Independent</option>
                      <option value="Dependent / Supervised">Dependent / Supervised</option>
                      <option value="Informal">Informal</option>
                      <option value="Summary">Summary</option>
                    </select>
                  </div>
                  <div className="col-span-2">
                    <label className="block text-[11px] text-slate-500 dark:text-slate-400">Property Address</label>
                    <input
                      type="text"
                      value={extracted.propertyAddress}
                      onChange={(e) => setExtracted({ ...extracted, propertyAddress: e.target.value })}
                      className="w-full px-2 py-1 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 mt-0.5"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-500 dark:text-slate-400">County / State</label>
                    <div className="flex gap-1.5 mt-0.5">
                      <input
                        type="text"
                        value={extracted.countyName}
                        onChange={(e) => setExtracted({ ...extracted, countyName: e.target.value })}
                        className="w-2/3 px-2 py-1 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                      />
                      <input
                        type="text"
                        value={extracted.stateCode}
                        onChange={(e) => setExtracted({ ...extracted, stateCode: e.target.value.toUpperCase() })}
                        className="w-1/3 px-2 py-1 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono text-slate-900 dark:text-slate-100"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-500 dark:text-slate-400">Property Type</label>
                    <select
                      value={extracted.propertyType}
                      onChange={(e) =>
                        setExtracted({ ...extracted, propertyType: e.target.value as PropertyType })
                      }
                      className="w-full px-2 py-1 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 mt-0.5"
                    >
                      <option value="Single-Family">Single-Family</option>
                      <option value="Multi-Family">Multi-Family</option>
                      <option value="Land / Lot">Land / Lot</option>
                      <option value="Commercial">Commercial</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-500 dark:text-slate-400">Assessed Value ($)</label>
                    <input
                      type="number"
                      value={extracted.assessedValue}
                      onChange={(e) =>
                        setExtracted({ ...extracted, assessedValue: Number(e.target.value) || 0 })
                      }
                      className="w-full px-2 py-1 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono text-slate-900 dark:text-slate-100 mt-0.5"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-500 dark:text-slate-400">Est. Debt / Liens ($)</label>
                    <input
                      type="number"
                      value={extracted.estimatedDebt}
                      onChange={(e) =>
                        setExtracted({ ...extracted, estimatedDebt: Number(e.target.value) || 0 })
                      }
                      className="w-full px-2 py-1 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono text-slate-900 dark:text-slate-100 mt-0.5"
                    />
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={() => onImportExtracted(extracted, rawText)}
                    className="px-4 py-1.5 rounded-lg bg-slate-900 dark:bg-sky-600 hover:bg-slate-800 dark:hover:bg-sky-500 text-white text-xs font-semibold"
                  >
                    Import to Discover & Pipeline
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
