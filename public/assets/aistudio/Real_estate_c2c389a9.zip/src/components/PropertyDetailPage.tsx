import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowLeft,
  Box,
  Building2,
  Calculator,
  Calendar,
  Check,
  Copy,
  ExternalLink,
  FileText,
  Globe,
  Home,
  Mail,
  Phone,
  Scale,
  ShieldCheck,
  TrendingUp,
  UserCheck,
} from 'lucide-react';
import type { CrmDeal, Jurisdiction, ThemeMode } from '../types/caselot';
import { calculateEstimatedEquity, formatCurrency } from '../utils/probateLogic';
import {
  analyzeStakeholderHierarchy,
  auditValuationConfidence,
  buildPropertyMarketIntelligence,
  calculateCurrentProbatePricing,
  calculateDealStrategies,
  generateCompassionateOutreach,
  type OutreachTone,
} from '../utils/valuationAndIntegrations';
import {
  calculateMinimumOverbidPrice,
  evaluateFederalCompliance,
  getStateProbateStatute,
} from '../utils/usRegulations';
import { GoogleProperty3DView } from './GoogleProperty3DView';
import { SpatialPropertyTwin3D } from './SpatialPropertyTwin3D';

interface PropertyDetailPageProps {
  deal: CrmDeal;
  allDeals: CrmDeal[];
  jurisdiction?: Jurisdiction;
  buyerEntity: string;
  mapsApiKey: string;
  theme: ThemeMode;
  onSelectDeal: (dealId: string) => void;
  onBackToDiscover: () => void;
  onAddToPipeline: (dealId: string) => void;
  onOpenEngage: (dealId: string) => void;
  onOpenHub: (dealId: string) => void;
}

type ImageryTab = 'spatial-twin' | 'google-maps';
type UnderwritingTab = 'flip' | 'rental' | 'seller-finance' | 'overbid';

export const PropertyDetailPage: React.FC<PropertyDetailPageProps> = ({
  deal,
  allDeals,
  jurisdiction,
  buyerEntity,
  mapsApiKey,
  theme,
  onSelectDeal,
  onBackToDiscover,
  onAddToPipeline,
  onOpenEngage,
  onOpenHub,
}) => {
  const baseIntel = useMemo(() => buildPropertyMarketIntelligence(deal), [deal]);
  const [rehabBudget, setRehabBudget] = useState<number>(baseIntel.rehabEstimate);
  const [imageryTab, setImageryTab] = useState<ImageryTab>('spatial-twin');
  const [underwritingTab, setUnderwritingTab] = useState<UnderwritingTab>('flip');

  // Seller Financing interactive levers
  const [sfDownPct, setSfDownPct] = useState<number>(15);
  const [sfRatePct, setSfRatePct] = useState<number>(5.5);
  const [sfTermYears, setSfTermYears] = useState<number>(20);

  // Compassionate Outreach Studio state
  const [outreachTone, setOutreachTone] = useState<OutreachTone>(
    deal.probateCase.hasAttorney ? 'counsel-loi' : 'empathetic-caretaker'
  );
  const [copiedOutreach, setCopiedOutreach] = useState(false);

  // Sync defaults when user switches selected property
  const [lastDealId, setLastDealId] = useState(deal.id);
  if (deal.id !== lastDealId) {
    setLastDealId(deal.id);
    setRehabBudget(baseIntel.rehabEstimate);
    setOutreachTone(deal.probateCase.hasAttorney ? 'counsel-loi' : 'empathetic-caretaker');
    setCopiedOutreach(false);
  }

  const intel = useMemo(
    () => buildPropertyMarketIntelligence(deal, rehabBudget),
    [deal, rehabBudget]
  );

  const avgMarketValue = Math.round((intel.zillowZestimate + intel.redfinEstimate) / 2);
  const probatePricing = useMemo(
    () =>
      calculateCurrentProbatePricing(
        deal.probateCase.jurisdictionId,
        avgMarketValue,
        deal.property.estimatedDebt
      ),
    [deal.probateCase.jurisdictionId, avgMarketValue, deal.property.estimatedDebt]
  );

  const strategies = useMemo(
    () =>
      calculateDealStrategies(deal, rehabBudget, {
        downPaymentPct: sfDownPct,
        interestRatePct: sfRatePct,
        termYears: sfTermYears,
      }),
    [deal, rehabBudget, sfDownPct, sfRatePct, sfTermYears]
  );

  const avmAudit = useMemo(
    () => auditValuationConfidence(deal, intel.zillowZestimate, intel.redfinEstimate),
    [deal, intel.zillowZestimate, intel.redfinEstimate]
  );

  const stakeholderHierarchy = useMemo(() => analyzeStakeholderHierarchy(deal), [deal]);

  const stateStatute = useMemo(
    () => getStateProbateStatute(deal.property.stateCode),
    [deal.property.stateCode]
  );

  const overbidResult = useMemo(
    () => calculateMinimumOverbidPrice(strategies.purchaseBasis, stateStatute.overbidFormula),
    [strategies.purchaseBasis, stateStatute.overbidFormula]
  );

  const federalCompliance = useMemo(
    () =>
      evaluateFederalCompliance({
        offerAmount: strategies.purchaseBasis,
        propertyType: deal.property.propertyType,
        sellerIsForeignEstateOrHeir: false,
        buyerIntendsPrimaryResidence: false,
        wholesaleAssignmentPlanned: false,
        outreachChannel: 'Direct Mail',
        hasPriorExpressWrittenConsent: false,
      }),
    [strategies.purchaseBasis, deal.property.propertyType]
  );

  const outreachDraft = useMemo(
    () =>
      generateCompassionateOutreach(
        deal,
        outreachTone,
        buyerEntity || 'Silvergate Probate Holdings LLC',
        strategies.purchaseBasis
      ),
    [deal, outreachTone, buyerEntity, strategies.purchaseBasis]
  );

  const assessorEquity = calculateEstimatedEquity(
    deal.property.assessedValue,
    deal.property.estimatedDebt
  );

  const handleCopyOutreach = async () => {
    const fullText = `Subject: ${outreachDraft.subject}\n\n${outreachDraft.body}`;
    try {
      await navigator.clipboard.writeText(fullText);
      setCopiedOutreach(true);
      setTimeout(() => setCopiedOutreach(false), 1800);
    } catch {
      setCopiedOutreach(false);
    }
  };

  return (
    <div className="space-y-5">
      {/* Top Breadcrumb & Quick Property Switcher */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={onBackToDiscover}
            className="px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700/80 bg-white dark:bg-[#0E1525] hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 inline-flex items-center gap-1.5 whitespace-nowrap"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            Back to US Search
          </button>

          <div>
            <h1 className="font-display text-xl sm:text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
              {deal.property.address}
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
              {deal.property.city}, {deal.property.stateCode} {deal.property.zip} ·{' '}
              {deal.property.countyName} County ·{' '}
              <span className="font-mono">{deal.property.parcelId}</span> ·{' '}
              <span className="font-mono">{deal.probateCase.caseNumber}</span>
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <select
            aria-label="Switch active property"
            value={deal.id}
            onChange={(e) => onSelectDeal(e.target.value)}
            className="px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700/80 bg-white dark:bg-[#0E1525] text-xs font-medium text-slate-900 dark:text-slate-100 max-w-[260px]"
          >
            {allDeals.map((d) => (
              <option key={d.id} value={d.id}>
                {d.property.address} ({d.property.stateCode})
              </option>
            ))}
          </select>

          {!deal.inPipeline && (
            <button
              type="button"
              onClick={() => onAddToPipeline(deal.id)}
              className="px-3.5 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold whitespace-nowrap"
            >
              Add to Pipeline
            </button>
          )}
          <button
            type="button"
            onClick={() => onOpenEngage(deal.id)}
            className="px-3.5 py-2 rounded-xl bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 text-white text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap"
          >
            <FileText className="w-3.5 h-3.5" />
            Draft Offer / PDF
          </button>
        </div>
      </div>

      {/* Spatial View Switcher + Interactive 3D / AR / VR / Google Maps Hero */}
      <div className="space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="inline-flex rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0B111E] p-1 gap-1">
            <button
              type="button"
              onClick={() => setImageryTab('spatial-twin')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold inline-flex items-center gap-1.5 transition-colors whitespace-nowrap ${
                imageryTab === 'spatial-twin'
                  ? 'bg-sky-600 text-white'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/70'
              }`}
            >
              <Box className="w-3.5 h-3.5" />
              3D Twin · AR & VR Lab
            </button>
            <button
              type="button"
              onClick={() => setImageryTab('google-maps')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold inline-flex items-center gap-1.5 transition-colors whitespace-nowrap ${
                imageryTab === 'google-maps'
                  ? 'bg-sky-600 text-white'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/70'
              }`}
            >
              <Globe className="w-3.5 h-3.5" />
              Google 3D Ring & Street View
            </button>
          </div>

          <span className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
            {deal.property.propertyType} · {deal.property.sqft.toLocaleString()} sqft · Lot{' '}
            {intel.lotSqft.toLocaleString()} sf
          </span>
        </div>

        {imageryTab === 'spatial-twin' ? (
          <SpatialPropertyTwin3D
            deal={deal}
            rehabBudget={rehabBudget}
            recommendedMao={intel.recommendedMao}
            lotSqft={intel.lotSqft}
            theme={theme}
          />
        ) : (
          <GoogleProperty3DView apiKey={mapsApiKey} property={deal.property} theme={theme} />
        )}
      </div>

      {/* AVM Variance & Field Inspection Alert Banner (Solves AVM Inaccuracy Complaints) */}
      <div
        className={`rounded-2xl border px-4 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs ${
          avmAudit.requiresFieldInspection
            ? 'bg-amber-50/90 dark:bg-amber-950/35 border-amber-200 dark:border-amber-800/70 text-amber-950 dark:text-amber-200'
            : 'bento-card text-slate-800 dark:text-slate-200'
        }`}
      >
        <div className="flex items-start gap-2.5">
          <AlertTriangle
            className={`w-4 h-4 shrink-0 mt-0.5 ${
              avmAudit.requiresFieldInspection
                ? 'text-amber-600 dark:text-amber-400'
                : 'text-sky-600 dark:text-sky-400'
            }`}
          />
          <div>
            <span className="font-semibold">
              AVM Valuation Audit — {avmAudit.confidenceLabel} ({avmAudit.spreadPct}% spread):
            </span>{' '}
            {avmAudit.warnings[0]}
            {avmAudit.warnings[1] ? ` ${avmAudit.warnings[1]}` : ''}
          </div>
        </div>
        <span className="font-mono text-[11px] font-semibold shrink-0">
          Match {deal.property.matchConfidence}%
        </span>
      </div>

      {/* Valuation & Market Intelligence Strip: County Assessor vs. Zillow vs. Redfin */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bento-card p-4 space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              County Assessor & Tax Roll
            </span>
            <Building2 className="w-4 h-4 text-slate-400" />
          </div>
          <div className="font-mono text-2xl font-bold text-slate-900 dark:text-white tabular-nums">
            {formatCurrency(deal.property.assessedValue)}
          </div>
          <div className="text-xs text-slate-600 dark:text-slate-400 space-y-1 pt-2 border-t border-slate-100 dark:border-slate-800">
            <div className="flex justify-between">
              <span>Est. Liens / Mortgage</span>
              <span className="font-mono font-semibold text-rose-600 dark:text-rose-400 tabular-nums">
                -{formatCurrency(deal.property.estimatedDebt)}
              </span>
            </div>
            <div className="flex justify-between">
              <span>Assessor Net Equity</span>
              <span className="font-mono font-semibold text-emerald-700 dark:text-emerald-400 tabular-nums">
                {formatCurrency(assessorEquity)}
              </span>
            </div>
            <div className="flex justify-between">
              <span>Est. Annual Property Tax ({intel.taxRatePct}%)</span>
              <span className="font-mono tabular-nums">
                {formatCurrency(intel.annualPropertyTax)}/yr
              </span>
            </div>
          </div>
        </div>

        <div className="bento-card p-4 space-y-2.5">
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs font-semibold text-sky-700 dark:text-sky-400">
              Zillow Zestimate® Intel
            </span>
            <a
              href={intel.zillowUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-[11px] font-semibold text-sky-600 dark:text-sky-400 hover:underline inline-flex items-center gap-1 whitespace-nowrap"
            >
              Open on Zillow
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="font-mono text-2xl font-bold text-slate-900 dark:text-white tabular-nums">
              {formatCurrency(intel.zillowZestimate)}
            </span>
            <span
              className={`font-mono text-xs font-semibold tabular-nums ${
                intel.zillowThirtyDayChangePct >= 0
                  ? 'text-emerald-700 dark:text-emerald-400'
                  : 'text-rose-600 dark:text-rose-400'
              }`}
            >
              {intel.zillowThirtyDayChangePct >= 0 ? '+' : ''}
              {intel.zillowThirtyDayChangePct}% (30d)
            </span>
          </div>
          <div className="text-xs text-slate-600 dark:text-slate-400 space-y-1 pt-2 border-t border-slate-100 dark:border-slate-800">
            <div className="flex justify-between">
              <span>Zestimate Range</span>
              <span className="font-mono tabular-nums">
                {formatCurrency(intel.zillowLow)} – {formatCurrency(intel.zillowHigh)}
              </span>
            </div>
            <div className="flex justify-between">
              <span>Rent Zestimate®</span>
              <span className="font-mono font-semibold text-slate-900 dark:text-slate-200 tabular-nums">
                {formatCurrency(intel.zillowRentZestimate)}/mo
              </span>
            </div>
            <div className="flex justify-between">
              <span>Gross Rent Yield</span>
              <span className="font-mono tabular-nums">
                {(((intel.zillowRentZestimate * 12) / intel.zillowZestimate) * 100).toFixed(1)}%
              </span>
            </div>
          </div>
        </div>

        <div className="bento-card p-4 space-y-2.5">
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs font-semibold text-rose-700 dark:text-rose-400">
              Redfin Market Estimate
            </span>
            <a
              href={intel.redfinUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-[11px] font-semibold text-rose-600 dark:text-rose-400 hover:underline inline-flex items-center gap-1 whitespace-nowrap"
            >
              Open on Redfin
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="font-mono text-2xl font-bold text-slate-900 dark:text-white tabular-nums">
              {formatCurrency(intel.redfinEstimate)}
            </span>
            <span className="font-mono text-xs text-slate-500 dark:text-slate-400 tabular-nums">
              ${intel.redfinPricePerSqft}/sqft
            </span>
          </div>
          <div className="text-xs text-slate-600 dark:text-slate-400 space-y-1 pt-2 border-t border-slate-100 dark:border-slate-800">
            <div className="flex justify-between">
              <span>Neighborhood Median DOM</span>
              <span className="font-mono font-semibold text-slate-900 dark:text-slate-200 tabular-nums">
                {intel.redfinAvgDom} days
              </span>
            </div>
            <div className="flex justify-between">
              <span>Avg Sale-to-List Ratio</span>
              <span className="font-mono tabular-nums">{intel.redfinSaleToListPct}%</span>
            </div>
            <div className="flex justify-between">
              <span>Zoning Classification</span>
              <span className="font-medium text-slate-800 dark:text-slate-200 truncate max-w-[160px]">
                {intel.zoning}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Main 2-Column Bento Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left 7 cols: Parcel Specs + Multi-Strategy Underwriting + Comps */}
        <div className="lg:col-span-7 space-y-5">
          {/* 4-Strategy Deal Underwriting Lab (Tranchi-Style Parity + Probate Overbid) */}
          <section className="bento-card p-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Calculator className="w-4 h-4 text-sky-600 dark:text-sky-400" />
                <h2 className="font-display text-sm font-bold text-slate-900 dark:text-white">
                  Multi-Strategy Deal Underwriting Lab
                </h2>
              </div>
              <span className="font-mono text-xs font-bold text-sky-700 dark:text-sky-400 tabular-nums">
                Offer Basis: {formatCurrency(strategies.purchaseBasis)} · MAO{' '}
                {formatCurrency(intel.recommendedMao)}
              </span>
            </div>

            {/* Rehab Budget Slider */}
            <div className="space-y-1.5 text-xs">
              <div className="flex items-center justify-between">
                <label
                  htmlFor="property-rehab-slider"
                  className="font-medium text-slate-700 dark:text-slate-300"
                >
                  Estimated Rehab / Estate Cleanout Budget
                </label>
                <span className="font-mono font-semibold text-slate-900 dark:text-white tabular-nums">
                  {formatCurrency(rehabBudget)}
                </span>
              </div>
              <input
                id="property-rehab-slider"
                type="range"
                min={0}
                max={120000}
                step={2500}
                value={rehabBudget}
                onChange={(e) => setRehabBudget(Number(e.target.value))}
                className="w-full accent-sky-600"
              />
            </div>

            {/* Strategy Mode Selector */}
            <div className="flex flex-wrap gap-1.5">
              {(
                [
                  { id: 'flip', label: 'Fix & Flip' },
                  { id: 'rental', label: 'Rental & DSCR' },
                  { id: 'seller-finance', label: 'Seller Financing' },
                  { id: 'overbid', label: `Court Overbid (${deal.property.stateCode})` },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setUnderwritingTab(tab.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-colors whitespace-nowrap ${
                    underwritingTab === tab.id
                      ? 'bg-sky-600 text-white border-sky-600'
                      : 'bg-white dark:bg-slate-900/70 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700/80 hover:bg-slate-50 dark:hover:bg-slate-800'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Tab 1: Fix & Flip */}
            {underwritingTab === 'flip' && (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div className="bento-inset p-3">
                  <div className="text-[11px] text-slate-500 dark:text-slate-400">Blended ARV</div>
                  <div className="font-mono font-bold text-slate-900 dark:text-white mt-0.5 tabular-nums">
                    {formatCurrency(strategies.blendedArv)}
                  </div>
                </div>
                <div className="bento-inset p-3">
                  <div className="text-[11px] text-slate-500 dark:text-slate-400">Hold/Sell (9%)</div>
                  <div className="font-mono font-bold text-slate-900 dark:text-white mt-0.5 tabular-nums">
                    {formatCurrency(strategies.flipHoldingAndSellingCosts)}
                  </div>
                </div>
                <div className="bento-inset p-3">
                  <div className="text-[11px] text-slate-500 dark:text-slate-400">Projected Net</div>
                  <div
                    className={`font-mono font-bold mt-0.5 tabular-nums ${
                      strategies.flipProjectedNetProfit >= 0
                        ? 'text-emerald-700 dark:text-emerald-400'
                        : 'text-rose-600 dark:text-rose-400'
                    }`}
                  >
                    {formatCurrency(strategies.flipProjectedNetProfit)}
                  </div>
                </div>
                <div className="bento-inset p-3">
                  <div className="text-[11px] text-slate-500 dark:text-slate-400">Unlevered ROI</div>
                  <div className="font-mono font-bold text-sky-700 dark:text-sky-400 mt-0.5 tabular-nums">
                    {strategies.flipRoiPct}%
                  </div>
                </div>
              </div>
            )}

            {/* Tab 2: Rental & DSCR */}
            {underwritingTab === 'rental' && (
              <div className="space-y-3 text-xs">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="bento-inset p-3">
                    <div className="text-[11px] text-slate-500 dark:text-slate-400">Est. Gross Rent</div>
                    <div className="font-mono font-bold text-slate-900 dark:text-white mt-0.5 tabular-nums">
                      {formatCurrency(strategies.grossMonthlyRent)}/mo
                    </div>
                  </div>
                  <div className="bento-inset p-3">
                    <div className="text-[11px] text-slate-500 dark:text-slate-400">Monthly NOI</div>
                    <div className="font-mono font-bold text-slate-900 dark:text-white mt-0.5 tabular-nums">
                      {formatCurrency(strategies.monthlyNoi)}/mo
                    </div>
                  </div>
                  <div className="bento-inset p-3">
                    <div className="text-[11px] text-slate-500 dark:text-slate-400">DSCR (75% LTV)</div>
                    <div
                      className={`font-mono font-bold mt-0.5 tabular-nums ${
                        strategies.dscrQualifies
                          ? 'text-emerald-700 dark:text-emerald-400'
                          : 'text-amber-600 dark:text-amber-400'
                      }`}
                    >
                      {strategies.dscrRatio}x {strategies.dscrQualifies ? '(Pass)' : '(Low)'}
                    </div>
                  </div>
                  <div className="bento-inset p-3">
                    <div className="text-[11px] text-slate-500 dark:text-slate-400">Cap / CoC</div>
                    <div className="font-mono font-bold text-sky-700 dark:text-sky-400 mt-0.5 tabular-nums">
                      {strategies.annualCapRatePct}% · {strategies.cashOnCashPct}%
                    </div>
                  </div>
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400">
                  Assumes 75% LTV DSCR loan @ 7.15% (30yr). Monthly Debt Service:{' '}
                  <strong className="font-mono text-slate-800 dark:text-slate-200">
                    {formatCurrency(strategies.dscrMonthlyDebtService)}/mo
                  </strong>{' '}
                  · Net Cash Flow:{' '}
                  <strong className="font-mono text-slate-800 dark:text-slate-200">
                    {formatCurrency(strategies.monthlyNetCashFlow)}/mo
                  </strong>
                </div>
              </div>
            )}

            {/* Tab 3: Creative Seller Financing */}
            {underwritingTab === 'seller-finance' && (
              <div className="space-y-3 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <div className="flex justify-between mb-1">
                      <label htmlFor="sf-down" className="text-slate-600 dark:text-slate-400">
                        Down Payment
                      </label>
                      <span className="font-mono font-semibold text-slate-900 dark:text-white">
                        {sfDownPct}%
                      </span>
                    </div>
                    <input
                      id="sf-down"
                      type="range"
                      min={5}
                      max={40}
                      step={5}
                      value={sfDownPct}
                      onChange={(e) => setSfDownPct(Number(e.target.value))}
                      className="w-full accent-sky-600"
                    />
                  </div>
                  <div>
                    <div className="flex justify-between mb-1">
                      <label htmlFor="sf-rate" className="text-slate-600 dark:text-slate-400">
                        Note Interest Rate
                      </label>
                      <span className="font-mono font-semibold text-slate-900 dark:text-white">
                        {sfRatePct.toFixed(1)}%
                      </span>
                    </div>
                    <input
                      id="sf-rate"
                      type="range"
                      min={3}
                      max={9}
                      step={0.5}
                      value={sfRatePct}
                      onChange={(e) => setSfRatePct(Number(e.target.value))}
                      className="w-full accent-sky-600"
                    />
                  </div>
                  <div>
                    <div className="flex justify-between mb-1">
                      <label htmlFor="sf-term" className="text-slate-600 dark:text-slate-400">
                        Amortization
                      </label>
                      <span className="font-mono font-semibold text-slate-900 dark:text-white">
                        {sfTermYears} yrs
                      </span>
                    </div>
                    <input
                      id="sf-term"
                      type="range"
                      min={10}
                      max={30}
                      step={5}
                      value={sfTermYears}
                      onChange={(e) => setSfTermYears(Number(e.target.value))}
                      className="w-full accent-sky-600"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="bento-inset p-3">
                    <div className="text-[11px] text-slate-500 dark:text-slate-400">Down Payment</div>
                    <div className="font-mono font-bold text-slate-900 dark:text-white mt-0.5 tabular-nums">
                      {formatCurrency(strategies.sellerDownPayment)}
                    </div>
                  </div>
                  <div className="bento-inset p-3">
                    <div className="text-[11px] text-slate-500 dark:text-slate-400">Monthly Note P&I</div>
                    <div className="font-mono font-bold text-slate-900 dark:text-white mt-0.5 tabular-nums">
                      {formatCurrency(strategies.sellerMonthlyPayment)}/mo
                    </div>
                  </div>
                  <div className="bento-inset p-3">
                    <div className="text-[11px] text-slate-500 dark:text-slate-400">Heir Interest Yield</div>
                    <div className="font-mono font-bold text-emerald-700 dark:text-emerald-400 mt-0.5 tabular-nums">
                      +{formatCurrency(strategies.sellerTotalInterestEarned)}
                    </div>
                  </div>
                  <div className="bento-inset p-3">
                    <div className="text-[11px] text-slate-500 dark:text-slate-400">Buyer Cash Flow</div>
                    <div
                      className={`font-mono font-bold mt-0.5 tabular-nums ${
                        strategies.sellerMonthlyCashFlow >= 0
                          ? 'text-emerald-700 dark:text-emerald-400'
                          : 'text-rose-600 dark:text-rose-400'
                      }`}
                    >
                      {formatCurrency(strategies.sellerMonthlyCashFlow)}/mo
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Tab 4: Court Overbid Exposure */}
            {underwritingTab === 'overbid' && (
              <div className="bento-inset p-3.5 space-y-2 text-xs">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="font-semibold text-slate-900 dark:text-white">
                    {stateStatute.stateName} ({stateStatute.stateCode}) Statutory Overbid Check
                  </span>
                  <span className="font-mono font-bold text-sky-700 dark:text-sky-400 tabular-nums">
                    Next Hearing Floor: {formatCurrency(overbidResult.minimumNextBid)}
                  </span>
                </div>
                <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                  {overbidResult.formulaSummary}
                </p>
                <div className="text-[11px] text-slate-500 dark:text-slate-400">
                  Admin Type: <strong className="text-slate-800 dark:text-slate-200">{deal.probateCase.adminType}</strong> ·{' '}
                  {stateStatute.courtConfirmationRule}
                </div>
              </div>
            )}
          </section>

          {/* Parcel Specs */}
          <section className="bento-card p-5 space-y-3">
            <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-2.5">
              <Home className="w-4 h-4 text-sky-600 dark:text-sky-400" />
              <h2 className="font-display text-sm font-bold text-slate-900 dark:text-white">
                Complete Parcel & Building Specifications
              </h2>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400">Property Type</div>
                <div className="font-semibold text-slate-900 dark:text-white mt-0.5">
                  {deal.property.propertyType}
                </div>
              </div>
              <div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400">Living Area</div>
                <div className="font-mono font-semibold text-slate-900 dark:text-white mt-0.5 tabular-nums">
                  {deal.property.sqft.toLocaleString()} sqft
                </div>
              </div>
              <div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400">Layout</div>
                <div className="font-mono font-semibold text-slate-900 dark:text-white mt-0.5 tabular-nums">
                  {intel.bedrooms} bd / {intel.bathrooms} ba
                </div>
              </div>
              <div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400">Year / Lot Size</div>
                <div className="font-mono font-semibold text-slate-900 dark:text-white mt-0.5 tabular-nums">
                  {deal.property.yearBuilt || 'Land'} · {intel.lotSqft.toLocaleString()} sf
                </div>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
              <span className="text-slate-500 dark:text-slate-400">Legal Description: </span>
              <span className="font-mono text-slate-800 dark:text-slate-200">
                {deal.property.legalDescription}
              </span>
            </div>
          </section>

          {/* Zillow & Redfin Sold Comparables */}
          <section className="bento-card overflow-hidden">
            <div className="px-5 py-3.5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-sky-600 dark:text-sky-400" />
                <h2 className="font-display text-sm font-bold text-slate-900 dark:text-white">
                  Nearby Sold Comparables (Zillow & Redfin MLS)
                </h2>
              </div>
              <span className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                90-Day Radius &le; 0.7 mi
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 text-[11px] text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                    <th className="py-2 px-4">Comparable Address</th>
                    <th className="py-2 px-3">Specs</th>
                    <th className="py-2 px-3 text-right">Sold Price</th>
                    <th className="py-2 px-3 text-right">$/SqFt</th>
                    <th className="py-2 px-4 text-right">Source / Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {intel.comps.map((comp) => (
                    <tr key={comp.address}>
                      <td className="py-2.5 px-4">
                        <div className="font-semibold text-slate-900 dark:text-white">
                          {comp.address}
                        </div>
                        <div className="text-[11px] text-slate-500 dark:text-slate-400">
                          {comp.distanceMiles} mi away
                        </div>
                      </td>
                      <td className="py-2.5 px-3 font-mono text-slate-700 dark:text-slate-300 tabular-nums">
                        {comp.beds}bd/{comp.baths}ba · {comp.sqft.toLocaleString()} sf
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono font-semibold text-emerald-700 dark:text-emerald-400 tabular-nums">
                        {formatCurrency(comp.soldPrice)}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono text-slate-700 dark:text-slate-300 tabular-nums">
                        ${comp.pricePerSqft}
                      </td>
                      <td className="py-2.5 px-4 text-right">
                        <div className="font-semibold text-slate-800 dark:text-slate-200">
                          {comp.source}
                        </div>
                        <div className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                          {comp.soldDate}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        </div>

        {/* Right 5 cols: Probate Pricing, Heir/PR Decision-Maker Tree + Outreach, Compliance Gate, Docket */}
        <div className="lg:col-span-5 space-y-5">
          {/* Current 2026 Probate Pricing Breakdown */}
          <section className="bento-card p-5 space-y-3">
            <div className="flex items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-2.5">
              <div className="flex items-center gap-2">
                <Scale className="w-4 h-4 text-sky-600 dark:text-sky-400" />
                <h2 className="font-display text-sm font-bold text-slate-900 dark:text-white">
                  Current 2026 Probate Cost Breakdown
                </h2>
              </div>
              <button
                type="button"
                onClick={() => onOpenHub(deal.id)}
                className="text-[11px] font-semibold text-sky-600 dark:text-sky-400 hover:underline whitespace-nowrap"
              >
                Open US Hub
              </button>
            </div>

            <div className="text-[11px] text-slate-500 dark:text-slate-400">
              {probatePricing.statutoryBasis}
            </div>

            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-600 dark:text-slate-400">Court Filing Fee</span>
                <span className="font-mono tabular-nums">{formatCurrency(probatePricing.filingFee)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600 dark:text-slate-400">Creditor Publication & Bond</span>
                <span className="font-mono tabular-nums">
                  {formatCurrency(
                    probatePricing.publicationNoticeFee + probatePricing.bondAndAppraisalFee
                  )}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600 dark:text-slate-400">Est. Probate Attorney Fee</span>
                <span className="font-mono tabular-nums">
                  {formatCurrency(probatePricing.attorneyFeeEstimate)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600 dark:text-slate-400">Est. PR Statutory Fee</span>
                <span className="font-mono tabular-nums">
                  {formatCurrency(probatePricing.executorFeeEstimate)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600 dark:text-slate-400">6-Month Tax/Ins/Utility Carry</span>
                <span className="font-mono tabular-nums">
                  {formatCurrency(probatePricing.sixMonthHoldingCost)}
                </span>
              </div>
              <div className="flex justify-between pt-2 border-t border-slate-200 dark:border-slate-800 font-semibold text-slate-900 dark:text-white">
                <span>Total Estate Probate Carry Cost</span>
                <span className="font-mono text-rose-600 dark:text-rose-400 tabular-nums">
                  {formatCurrency(probatePricing.totalProbateCarryCost)}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2.5 pt-2 text-xs">
              <div className="bento-inset p-2.5">
                <div className="text-[11px] text-slate-500 dark:text-slate-400">
                  Retail Listing Net (6 mo)
                </div>
                <div className="font-mono font-bold text-slate-900 dark:text-white mt-0.5 tabular-nums">
                  {formatCurrency(probatePricing.traditionalNetProceeds)}
                </div>
              </div>
              <div className="p-2.5 rounded-xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800">
                <div className="text-[11px] text-emerald-800 dark:text-emerald-300">
                  As-Is Cash Close Net (21d)
                </div>
                <div className="font-mono font-bold text-emerald-700 dark:text-emerald-400 mt-0.5 tabular-nums">
                  {formatCurrency(probatePricing.fastCashNetProceeds)}
                </div>
              </div>
            </div>
          </section>

          {/* Heir & Personal Representative Decision-Maker Tree + Compassionate Outreach Studio */}
          <section className="bento-card p-5 space-y-3.5">
            <div className="flex items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-2.5">
              <div className="flex items-center gap-2">
                <UserCheck className="w-4 h-4 text-sky-600 dark:text-sky-400" />
                <h2 className="font-display text-sm font-bold text-slate-900 dark:text-white">
                  Heir & PR Decision-Maker Tree
                </h2>
              </div>
              <span className="text-[11px] font-semibold text-sky-700 dark:text-sky-400">
                {stakeholderHierarchy.contactReadiness}
              </span>
            </div>

            {/* Decedent Excluded Banner + Out-of-State PR Detection */}
            <div className="bento-inset p-3 text-xs space-y-1.5">
              <div className="flex items-center justify-between gap-2">
                <span className="font-semibold text-slate-900 dark:text-white">
                  Decedent: {deal.probateCase.decedentName}
                </span>
                <span className="text-[11px] font-mono text-rose-600 dark:text-rose-400">
                  Phone/Records Excluded
                </span>
              </div>
              <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
                {stakeholderHierarchy.routingAdvice}
              </p>
              {stakeholderHierarchy.outOfStatePr && (
                <div className="text-[11px] font-semibold text-amber-700 dark:text-amber-300">
                  Out-of-State PR Detected ({stakeholderHierarchy.prStateCode} &rarr;{' '}
                  {deal.property.stateCode}) — High remote-close motivation
                </div>
              )}
            </div>

            {/* Living Stakeholders */}
            <div className="space-y-2 text-xs">
              {deal.stakeholders.map((st) => (
                <div key={st.id} className="bento-inset p-3 space-y-1">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-semibold text-slate-900 dark:text-white">
                      {st.fullName}
                    </span>
                    <span className="text-[11px] font-medium text-sky-700 dark:text-sky-400">
                      {st.role}
                    </span>
                  </div>
                  <div className="text-slate-600 dark:text-slate-400">{st.mailingAddress}</div>
                  <div className="font-mono text-[11px] text-slate-700 dark:text-slate-300 flex flex-wrap items-center gap-3">
                    <span className="inline-flex items-center gap-1">
                      <Phone className="w-3 h-3 text-slate-400" />
                      {st.phone}
                    </span>
                    <span className="inline-flex items-center gap-1">
                      <Mail className="w-3 h-3 text-slate-400" />
                      {st.email}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {/* Compassionate Outreach Studio */}
            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-2.5">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-bold text-slate-900 dark:text-white">
                  Compassionate Outreach Studio
                </span>
                <button
                  type="button"
                  onClick={handleCopyOutreach}
                  className="px-2.5 py-1 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-[11px] font-semibold text-slate-700 dark:text-slate-200 inline-flex items-center gap-1 whitespace-nowrap"
                >
                  {copiedOutreach ? (
                    <>
                      <Check className="w-3 h-3 text-emerald-500" />
                      Copied
                    </>
                  ) : (
                    <>
                      <Copy className="w-3 h-3" />
                      Copy Draft
                    </>
                  )}
                </button>
              </div>

              <div className="flex flex-wrap gap-1.5">
                {(
                  [
                    { id: 'empathetic-caretaker', label: 'Empathetic Letter' },
                    { id: 'out-of-state-relief', label: 'Out-of-State Relief' },
                    { id: 'counsel-loi', label: 'Counsel Formal LOI' },
                  ] as const
                ).map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => setOutreachTone(t.id)}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold border transition-colors whitespace-nowrap ${
                      outreachTone === t.id
                        ? 'bg-sky-600 text-white border-sky-600'
                        : 'bg-white dark:bg-slate-900/70 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700/80'
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>

              <div className="bento-inset p-3 text-[11px] space-y-1.5">
                <div className="font-semibold text-slate-900 dark:text-white">
                  {outreachDraft.subject}
                </div>
                <pre className="whitespace-pre-wrap font-sans text-slate-600 dark:text-slate-300 leading-relaxed">
                  {outreachDraft.body}
                </pre>
              </div>
            </div>
          </section>

          {/* Federal & State Regulatory Compliance Gate */}
          <section className="bento-card p-5 space-y-3">
            <div className="flex items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-2.5">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <h2 className="font-display text-sm font-bold text-slate-900 dark:text-white">
                  Federal & {stateStatute.stateCode} Compliance Gate
                </h2>
              </div>
              <span className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                {stateStatute.upcAdopted}
              </span>
            </div>

            <div className="bento-inset p-3 text-xs space-y-1">
              <div className="font-semibold text-slate-900 dark:text-white">
                {stateStatute.stateName} Real Property Rule · Creditor Window:{' '}
                {stateStatute.creditorClaimWindow}
              </div>
              <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
                {stateStatute.homesteadAndSpousalNote}
              </p>
            </div>

            <div className="space-y-2 text-[11px]">
              {federalCompliance.checks.map((chk) => (
                <div key={chk.id} className="bento-inset p-2.5 flex items-start justify-between gap-2">
                  <div>
                    <div className="font-semibold text-slate-900 dark:text-white">
                      {chk.statute} — {chk.title}
                    </div>
                    <p className="text-slate-600 dark:text-slate-400 mt-0.5">{chk.requiredAction}</p>
                  </div>
                  <span
                    className={`font-semibold shrink-0 ${
                      chk.severity === 'warning'
                        ? 'text-rose-600 dark:text-rose-400'
                        : chk.severity === 'caution'
                          ? 'text-amber-600 dark:text-amber-400'
                          : 'text-emerald-700 dark:text-emerald-400'
                    }`}
                  >
                    {chk.status}
                  </span>
                </div>
              ))}
            </div>
          </section>

          {/* Docket Timeline */}
          <section className="bento-card p-5 space-y-3">
            <div className="flex items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-2.5">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-sky-600 dark:text-sky-400" />
                <h2 className="font-display text-sm font-bold text-slate-900 dark:text-white">
                  Court Docket Timeline
                </h2>
              </div>
              <span className="text-[11px] text-slate-500 dark:text-slate-400">
                {jurisdiction?.countyName ?? deal.property.countyName} Court
              </span>
            </div>

            <div className="space-y-2.5 text-xs">
              {deal.probateCase.docketTimeline.map((ev) => (
                <div key={ev.id} className="bento-inset p-2.5">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-semibold text-slate-900 dark:text-white">{ev.title}</span>
                    <span className="font-mono text-[11px] text-slate-500 dark:text-slate-400 tabular-nums">
                      {ev.date}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-600 dark:text-slate-400 mt-0.5">{ev.notes}</p>
                </div>
              ))}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};
