/// <reference types="google.maps" />
import React, { useEffect, useRef, useState } from 'react';
import {
  APIProvider,
  AdvancedMarker,
  ColorScheme,
  Map as GoogleMap,
  Pin,
  useMapsLibrary,
} from '@vis.gl/react-google-maps';
import {
  GestureHandling,
  Map3D,
  MapMode,
  Marker3D,
  type Map3DRef,
} from '@vis.gl/react-google-maps/3d';
import {
  Compass,
  Eye,
  Globe2,
  MapPin,
  Orbit,
  Pause,
  RotateCcw,
} from 'lucide-react';
import type { PropertyRecord, ThemeMode } from '../types/caselot';

interface GoogleProperty3DViewProps {
  apiKey: string;
  property: PropertyRecord;
  theme: ThemeMode;
}

type ViewTab = '3d-ring' | 'satellite-45' | 'street-view';

function hasWebGL2(): boolean {
  try {
    const canvas = document.createElement('canvas');
    return Boolean(canvas.getContext('webgl2'));
  } catch {
    return false;
  }
}

const StreetViewPanel: React.FC<{ lat: number; lng: number; address: string }> = ({
  lat,
  lng,
  address,
}) => {
  const streetViewLib = useMapsLibrary('streetView');
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [statusMessage, setStatusMessage] = useState<string>('Loading 360° street imagery...');
  const [unavailable, setUnavailable] = useState(false);

  useEffect(() => {
    if (!streetViewLib || !containerRef.current) return;
    let cancelled = false;

    const svService = new streetViewLib.StreetViewService();
    svService
      .getPanorama({
        location: { lat, lng },
        radius: 150,
      })
      .then((res) => {
        if (cancelled || !containerRef.current) return;
        const panoData = res.data;
        if (!panoData?.location?.pano) {
          setUnavailable(true);
          setStatusMessage('No street-level panorama found within 150m of this parcel.');
          return;
        }
        setUnavailable(false);
        setStatusMessage('');
        new streetViewLib.StreetViewPanorama(containerRef.current, {
          pano: panoData.location.pano,
          pov: { heading: 15, pitch: 4 },
          zoom: 1,
          addressControl: true,
          linksControl: true,
          panControl: true,
          enableCloseButton: false,
        });
      })
      .catch(() => {
        if (!cancelled) {
          setUnavailable(true);
          setStatusMessage('Street View panorama unavailable for this parcel coordinate.');
        }
      });

    return () => {
      cancelled = true;
    };
  }, [streetViewLib, lat, lng]);

  return (
    <div className="relative w-full h-[360px] sm:h-[420px] bg-slate-950">
      <div ref={containerRef} className="w-full h-full" aria-label={`360 Street View of ${address}`} />
      {(unavailable || statusMessage) && (
        <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center bg-slate-950/85 text-slate-200">
          <Eye className="w-6 h-6 text-sky-400 mb-2" />
          <p className="text-xs font-medium max-w-sm">{statusMessage}</p>
        </div>
      )}
    </div>
  );
};

const Map3DViewer: React.FC<{
  property: PropertyRecord;
  theme: ThemeMode;
  onFallbackTo2D: () => void;
}> = ({ property, onFallbackTo2D }) => {
  const map3dRef = useRef<Map3DRef | null>(null);
  const [orbiting, setOrbiting] = useState(false);
  const [cameraTilt, setCameraTilt] = useState(66);
  const [cameraRange, setCameraRange] = useState(235);
  const [cameraHeading, setCameraHeading] = useState(25);

  const startOrbitRing = () => {
    if (!map3dRef.current) return;
    setOrbiting(true);
    map3dRef.current.flyCameraAround({
      camera: {
        center: { lat: property.lat, lng: property.lng, altitude: 22 },
        tilt: 67,
        range: 205,
        heading: cameraHeading,
      },
      durationMillis: 7000,
      repeatCount: 1,
    });
  };

  const stopOrbitRing = () => {
    map3dRef.current?.stopCameraAnimation();
    setOrbiting(false);
  };

  const resetCamera = () => {
    stopOrbitRing();
    setCameraTilt(66);
    setCameraRange(235);
    setCameraHeading(25);
    map3dRef.current?.flyCameraTo({
      endCamera: {
        center: { lat: property.lat, lng: property.lng, altitude: 22 },
        tilt: 66,
        range: 235,
        heading: 25,
      },
      durationMillis: 900,
    });
  };

  const applyCameraPreset = (tilt: number, range: number, heading: number) => {
    stopOrbitRing();
    setCameraTilt(tilt);
    setCameraRange(range);
    setCameraHeading(heading);
    map3dRef.current?.flyCameraTo({
      endCamera: {
        center: { lat: property.lat, lng: property.lng, altitude: 18 },
        tilt,
        range,
        heading,
      },
      durationMillis: 850,
    });
  };

  return (
    <div className="relative w-full h-[360px] sm:h-[420px] bg-slate-950">
      <Map3D
        ref={map3dRef}
        mode={MapMode.HYBRID}
        gestureHandling={GestureHandling.GREEDY}
        defaultCenter={{ lat: property.lat, lng: property.lng, altitude: 22 }}
        defaultTilt={cameraTilt}
        defaultRange={cameraRange}
        defaultHeading={cameraHeading}
        internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
        onAnimationEnd={() => setOrbiting(false)}
        onError={() => onFallbackTo2D()}
        className="w-full h-full"
      >
        <Marker3D
          position={{ lat: property.lat, lng: property.lng, altitude: 14 }}
          altitudeMode="RELATIVE_TO_MESH"
          label={property.address}
        />
      </Map3D>

      {/* Bottom 3D Orbit Ring Control Bar */}
      <div className="absolute bottom-3 left-3 right-3 z-10 flex flex-wrap items-center justify-between gap-2 pointer-events-none">
        <div className="pointer-events-auto inline-flex flex-wrap items-center gap-1.5 rounded-lg bg-slate-950/90 border border-slate-700/80 p-1.5 shadow-lg">
          <button
            type="button"
            onClick={orbiting ? stopOrbitRing : startOrbitRing}
            className="px-3 py-1.5 rounded-md bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap"
          >
            {orbiting ? <Pause className="w-3.5 h-3.5" /> : <Orbit className="w-3.5 h-3.5" />}
            {orbiting ? 'Stop 360° Orbit' : '360° Orbit Ring'}
          </button>

          <button
            type="button"
            onClick={() => applyCameraPreset(70, 145, cameraHeading)}
            className="px-2.5 py-1.5 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-medium whitespace-nowrap"
          >
            Close-Up
          </button>
          <button
            type="button"
            onClick={() => applyCameraPreset(45, 420, 0)}
            className="px-2.5 py-1.5 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-medium whitespace-nowrap"
          >
            Block Context
          </button>
          <button
            type="button"
            onClick={resetCamera}
            aria-label="Reset 3D camera"
            className="p-1.5 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-300"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>

        <button
          type="button"
          onClick={onFallbackTo2D}
          className="pointer-events-auto px-2.5 py-1.5 rounded-lg bg-slate-950/90 border border-slate-700/80 text-[11px] font-medium text-slate-300 hover:text-white whitespace-nowrap"
        >
          Switch to 45° Satellite
        </button>
      </div>
    </div>
  );
};

export const GoogleProperty3DView: React.FC<GoogleProperty3DViewProps> = ({
  apiKey,
  property,
  theme,
}) => {
  const [webglSupported] = useState<boolean>(() => hasWebGL2());
  const [viewTab, setViewTab] = useState<ViewTab>(webglSupported ? '3d-ring' : 'satellite-45');
  const [satelliteHeading, setSatelliteHeading] = useState(0);

  if (!apiKey) {
    return (
      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 text-center space-y-2">
        <MapPin className="w-6 h-6 text-sky-600 mx-auto" />
        <h3 className="font-display text-sm font-bold text-slate-900 dark:text-white">
          3D Aerial & Street View Ready
        </h3>
        <p className="text-xs text-slate-600 dark:text-slate-400 max-w-md mx-auto">
          Set <span className="font-mono">VITE_GOOGLE_MAPS_API_KEY</span> to render Photorealistic 3D Tiles, 360° camera orbit rings, and Street View for {property.address}.
        </p>
      </div>
    );
  }

  return (
    <section
      aria-label="Google Maps 3D Property View"
      className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden"
      data-testid="property-3d-google-view"
    >
      <div className="px-4 py-2.5 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2 text-xs min-w-0">
          <Compass className="w-4 h-4 text-sky-600 dark:text-sky-400 shrink-0" />
          <span className="font-display font-semibold text-slate-900 dark:text-white truncate">
            3D Property Ring & Street Imagery
          </span>
          <span className="text-slate-400 hidden sm:inline">·</span>
          <span className="text-[11px] font-mono text-slate-500 dark:text-slate-400 hidden sm:inline tabular-nums">
            {property.lat.toFixed(4)}, {property.lng.toFixed(4)}
          </span>
        </div>

        <div
          role="group"
          aria-label="Property imagery mode"
          className="inline-flex rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 p-0.5 text-xs"
        >
          <button
            type="button"
            onClick={() => setViewTab('3d-ring')}
            className={`px-2.5 py-1 rounded-md font-semibold flex items-center gap-1 whitespace-nowrap ${
              viewTab === '3d-ring'
                ? 'bg-slate-900 dark:bg-sky-600 text-white'
                : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Orbit className="w-3.5 h-3.5" />
            3D Aerial Ring
          </button>
          <button
            type="button"
            onClick={() => setViewTab('satellite-45')}
            className={`px-2.5 py-1 rounded-md font-semibold flex items-center gap-1 whitespace-nowrap ${
              viewTab === 'satellite-45'
                ? 'bg-slate-900 dark:bg-sky-600 text-white'
                : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Globe2 className="w-3.5 h-3.5" />
            45° Satellite
          </button>
          <button
            type="button"
            onClick={() => setViewTab('street-view')}
            className={`px-2.5 py-1 rounded-md font-semibold flex items-center gap-1 whitespace-nowrap ${
              viewTab === 'street-view'
                ? 'bg-slate-900 dark:bg-sky-600 text-white'
                : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            360° Street View
          </button>
        </div>
      </div>

      <APIProvider
        apiKey={apiKey}
        libraries={['marker', 'places', 'maps3d', 'streetView']}
        language="en"
        region="US"
      >
        {viewTab === '3d-ring' && (
          <Map3DViewer
            key={property.id}
            property={property}
            theme={theme}
            onFallbackTo2D={() => setViewTab('satellite-45')}
          />
        )}

        {viewTab === 'satellite-45' && (
          <div className="relative w-full h-[360px] sm:h-[420px]">
            <GoogleMap
              mapId="DEMO_MAP_ID"
              center={{ lat: property.lat, lng: property.lng }}
              zoom={19}
              mapTypeId="hybrid"
              tilt={45}
              heading={satelliteHeading}
              gestureHandling="greedy"
              colorScheme={theme === 'dark' ? ColorScheme.DARK : ColorScheme.LIGHT}
              internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
              className="w-full h-full"
            >
              <AdvancedMarker
                position={{ lat: property.lat, lng: property.lng }}
                title={property.address}
              >
                <Pin background="#0284c7" borderColor="#0f172a" glyphColor="#ffffff" scale={1.2} />
              </AdvancedMarker>
            </GoogleMap>

            <div className="absolute bottom-3 left-3 z-10 flex items-center gap-1.5 rounded-lg bg-slate-950/90 border border-slate-700/80 p-1.5">
              <button
                type="button"
                onClick={() => setSatelliteHeading((h) => (h + 90) % 360)}
                className="px-3 py-1.5 rounded-md bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Rotate 90° ({satelliteHeading}°)
              </button>
            </div>
          </div>
        )}

        {viewTab === 'street-view' && (
          <StreetViewPanel
            lat={property.lat}
            lng={property.lng}
            address={property.address}
          />
        )}
      </APIProvider>
    </section>
  );
};
