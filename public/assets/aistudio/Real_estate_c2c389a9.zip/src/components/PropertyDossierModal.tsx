import React, { useState } from 'react';
import {
  Building2,
  Calendar,
  FileCheck,
  Mail,
  MapPin,
  MessageSquare,
  Phone,
  Scale,
  Send,
  UserCheck,
  X,
} from 'lucide-react';
import type { ActivityLog, CrmDeal, DealStage, Jurisdiction } from '../types/caselot';
import { DEAL_STAGES } from '../types/caselot';
import { calculateEstimatedEquity, formatCurrency } from '../utils/probateLogic';

interface PropertyDossierModalProps {
  deal: CrmDeal;
  jurisdiction: Jurisdiction | undefined;
  onClose: () => void;
  onUpdateStage: (dealId: string, stage: DealStage, addToPipeline?: boolean) => void;
  onUpdateOfferAndNotes: (dealId: string, offerAmount: number, notes: string, nextFollowupAt: string) => void;
  onAddActivity: (dealId: string, channel: ActivityLog['channel'], summary: string) => void;
  onJumpToHub: (dealId: string) => void;
  onJumpToEngage: (dealId: string) => void;
}

export const PropertyDossierModal: React.FC<PropertyDossierModalProps> = ({
  deal,
  jurisdiction,
  onClose,
  onUpdateStage,
  onUpdateOfferAndNotes,
  onAddActivity,
  onJumpToHub,
  onJumpToEngage,
}) => {
  const [offerDraft, setOfferDraft] = useState(String(deal.offerAmount));
  const [notesDraft, setNotesDraft] = useState(deal.notes);
  const [followupDraft, setFollowupDraft] = useState(deal.nextFollowupAt);
  const [activityChannel, setActivityChannel] = useState<ActivityLog['channel']>('Call');
  const [activityText, setActivityText] = useState('');
  const [savedNotice, setSavedNotice] = useState(false);

  const equity = calculateEstimatedEquity(deal.property.assessedValue, deal.property.estimatedDebt);

  const handleSaveTerms = (e: React.FormEvent) => {
    e.preventDefault();
    const numericOffer = Number(offerDraft.replace(/[^0-9]/g, '')) || deal.offerAmount;
    onUpdateOfferAndNotes(deal.id, numericOffer, notesDraft, followupDraft);
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 1800);
  };

  const handleLogActivity = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activityText.trim()) return;
    onAddActivity(deal.id, activityChannel, activityText.trim());
    setActivityText('');
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/75 flex items-center justify-center p-3 lg:p-6"
      role="dialog"
      aria-modal="true"
      aria-labelledby="dossier-title"
    >
      <div className="bg-white dark:bg-[#0B111E] border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-6xl max-h-[92vh] flex flex-col overflow-hidden shadow-2xl">
        {/* Dossier Top Header */}
        <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#070B14] flex flex-wrap items-center justify-between gap-4">
          <div className="min-w-0">
            <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
              <span className="font-mono font-semibold text-slate-700 dark:text-slate-300">
                {deal.probateCase.caseNumber}
              </span>
              <span aria-hidden="true">·</span>
              <span>
                {deal.property.countyName} County, {deal.property.stateCode}
              </span>
              <span aria-hidden="true">·</span>
              <span>{deal.probateCase.adminType}</span>
            </div>
            <h2 id="dossier-title" className="font-display text-lg font-bold text-slate-900 dark:text-white truncate mt-0.5">
              {deal.property.address}, {deal.property.city}, {deal.property.stateCode} {deal.property.zip}
            </h2>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => onJumpToHub(deal.id)}
              className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1.5 whitespace-nowrap"
            >
              <Scale className="w-3.5 h-3.5" />
              Local Playbook
            </button>
            <button
              type="button"
              onClick={() => onJumpToEngage(deal.id)}
              className="px-3 py-1.5 rounded-lg bg-slate-900 dark:bg-sky-600 hover:bg-slate-800 dark:hover:bg-sky-500 text-xs font-semibold text-white flex items-center gap-1.5 whitespace-nowrap"
            >
              <FileCheck className="w-3.5 h-3.5" />
              Auto-Fill Forms
            </button>
            <button
              type="button"
              onClick={onClose}
              aria-label="Close property dossier"
              className="p-2 rounded-lg text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-200/70 dark:hover:bg-slate-800"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Split-Screen Content */}
        <div className="flex-1 overflow-y-auto grid grid-cols-1 lg:grid-cols-12 divide-y lg:divide-y-0 lg:divide-x divide-slate-200 dark:divide-slate-800">
          {/* Left Column: Property Details, Assessor Match & Docket Timeline */}
          <div className="lg:col-span-6 p-5 space-y-5">
            {/* Valuation & Assessor Strip */}
            <div className="grid grid-cols-3 gap-3 border border-slate-200 dark:border-slate-800 rounded-lg p-3.5 bg-slate-50 dark:bg-slate-950/60">
              <div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400">Assessor Value</div>
                <div className="font-mono text-base font-bold text-slate-900 dark:text-white tabular-nums mt-0.5">
                  {formatCurrency(deal.property.assessedValue)}
                </div>
              </div>
              <div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400">Est. Debt / Liens</div>
                <div className="font-mono text-base font-semibold text-slate-700 dark:text-slate-300 tabular-nums mt-0.5">
                  {formatCurrency(deal.property.estimatedDebt)}
                </div>
              </div>
              <div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400">Est. Net Equity</div>
                <div className="font-mono text-base font-bold text-emerald-700 dark:text-emerald-400 tabular-nums mt-0.5">
                  {formatCurrency(equity)}
                </div>
              </div>
            </div>

            {/* Parcel & Assessor Cross-Match Details */}
            <div>
              <h3 className="text-xs font-semibold text-slate-900 dark:text-white uppercase tracking-wider mb-2.5">
                Parcel & Assessor Cross-Reference
              </h3>
              <dl className="grid grid-cols-2 gap-x-4 gap-y-2.5 text-xs border-t border-slate-100 dark:border-slate-800 pt-2.5">
                <div>
                  <dt className="text-slate-500 dark:text-slate-400">Decedent / Owner</dt>
                  <dd className="font-medium text-slate-900 dark:text-slate-100 mt-0.5">
                    {deal.probateCase.decedentName} (DOD {deal.probateCase.dateOfDeath})
                  </dd>
                </div>
                <div>
                  <dt className="text-slate-500 dark:text-slate-400">APN / Parcel ID</dt>
                  <dd className="font-mono font-medium text-slate-900 dark:text-slate-100 mt-0.5">{deal.property.parcelId}</dd>
                </div>
                <div>
                  <dt className="text-slate-500 dark:text-slate-400">Property Profile</dt>
                  <dd className="font-medium text-slate-900 dark:text-slate-100 mt-0.5">
                    {deal.property.propertyType} · {deal.property.sqft.toLocaleString()} sqft
                    {deal.property.yearBuilt > 0 ? ` · Built ${deal.property.yearBuilt}` : ''}
                  </dd>
                </div>
                <div>
                  <dt className="text-slate-500 dark:text-slate-400">Match Confidence</dt>
                  <dd className="font-medium text-emerald-700 dark:text-emerald-400 mt-0.5 tabular-nums">
                    {deal.property.matchConfidence}% · {deal.property.matchSource}
                  </dd>
                </div>
                <div className="col-span-2">
                  <dt className="text-slate-500 dark:text-slate-400">Legal Description</dt>
                  <dd className="font-mono text-[11px] text-slate-700 dark:text-slate-300 mt-0.5">
                    {deal.property.legalDescription}
                  </dd>
                </div>
              </dl>

              <div className="mt-3 p-3 rounded-lg bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                <span className="font-semibold text-slate-900 dark:text-white">AI Docket Brief: </span>
                {deal.probateCase.aiSummary}
              </div>
            </div>

            {/* Court Docket Timeline */}
            <div>
              <div className="flex items-center justify-between mb-2.5">
                <h3 className="text-xs font-semibold text-slate-900 dark:text-white uppercase tracking-wider">
                  Linked Court Docket Timeline
                </h3>
                <span className="text-[11px] text-slate-500 dark:text-slate-400">
                  {jurisdiction?.scrapingAdapter ?? 'County Portal'}
                </span>
              </div>
              <div className="space-y-2.5 border-t border-slate-100 dark:border-slate-800 pt-2.5">
                {deal.probateCase.docketTimeline.map((evt) => (
                  <div
                    key={evt.id}
                    className="flex items-start gap-3 p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950/50 text-xs"
                  >
                    <span className="font-mono text-[11px] text-slate-500 dark:text-slate-400 shrink-0 tabular-nums mt-0.5">
                      {evt.date}
                    </span>
                    <div className="min-w-0">
                      <div className="font-semibold text-slate-900 dark:text-white">{evt.title}</div>
                      <div className="text-slate-500 dark:text-slate-400 mt-0.5">
                        {evt.documentType} — {evt.notes}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column: Pipeline Controls, Stakeholders, Outreach & Notes */}
          <div className="lg:col-span-6 p-5 space-y-5">
            {/* Stage Progression & Offer Form */}
            <form onSubmit={handleSaveTerms} className="space-y-3 border border-slate-200 dark:border-slate-800 rounded-lg p-4 bg-slate-50 dark:bg-slate-950/60">
              <div className="flex items-center justify-between gap-3">
                <label htmlFor="dossier-stage" className="text-xs font-semibold text-slate-900 dark:text-white">
                  Acquisition Pipeline Stage
                </label>
                {!deal.inPipeline && (
                  <button
                    type="button"
                    onClick={() => onUpdateStage(deal.id, 'Verified Real Estate', true)}
                    className="px-2.5 py-1 rounded bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold"
                  >
                    Add to Pipeline
                  </button>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                <div>
                  <select
                    id="dossier-stage"
                    value={deal.stage}
                    onChange={(e) => onUpdateStage(deal.id, e.target.value as DealStage, true)}
                    className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-medium text-slate-900 dark:text-slate-100"
                  >
                    {DEAL_STAGES.map((st) => (
                      <option key={st} value={st}>
                        {st}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label htmlFor="dossier-offer" className="sr-only">
                    Offer Amount
                  </label>
                  <input
                    id="dossier-offer"
                    type="text"
                    value={offerDraft}
                    onChange={(e) => setOfferDraft(e.target.value)}
                    placeholder="Offer USD"
                    className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono text-xs text-slate-900 dark:text-slate-100"
                  />
                </div>
                <div>
                  <label htmlFor="dossier-followup" className="sr-only">
                    Next Follow-up Date
                  </label>
                  <div className="relative flex items-center">
                    <Calendar className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 pointer-events-none" />
                    <input
                      id="dossier-followup"
                      type="date"
                      value={followupDraft}
                      onChange={(e) => setFollowupDraft(e.target.value)}
                      className="w-full pl-8 pr-2 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono text-xs text-slate-900 dark:text-slate-100"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label htmlFor="dossier-notes" className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1">
                  Acquisition Underwriting & Title Notes
                </label>
                <textarea
                  id="dossier-notes"
                  rows={2}
                  value={notesDraft}
                  onChange={(e) => setNotesDraft(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="flex items-center justify-between">
                <span className="text-[11px] text-emerald-700 dark:text-emerald-400 font-medium">
                  {savedNotice ? 'Saved deal updates' : ''}
                </span>
                <button
                  type="submit"
                  className="px-3 py-1.5 rounded-lg bg-slate-900 dark:bg-sky-600 hover:bg-slate-800 dark:hover:bg-sky-500 text-white text-xs font-semibold"
                >
                  Save Deal Terms
                </button>
              </div>
            </form>

            {/* Stakeholders */}
            <div>
              <h3 className="text-xs font-semibold text-slate-900 dark:text-white uppercase tracking-wider mb-2.5">
                Stakeholders ({deal.stakeholders.length})
              </h3>
              <div className="space-y-2 border-t border-slate-100 dark:border-slate-800 pt-2.5">
                {deal.stakeholders.map((st) => (
                  <div
                    key={st.id}
                    className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950/50 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                  >
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 text-xs">
                        <span className="font-semibold text-slate-900 dark:text-white">{st.fullName}</span>
                        <span className="text-slate-500 dark:text-slate-400">· {st.role}</span>
                        {st.verified && (
                          <span className="inline-flex items-center gap-0.5 text-[11px] text-emerald-700 dark:text-emerald-400 font-medium">
                            <UserCheck className="w-3 h-3" /> Verified
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 flex items-center gap-1.5 truncate">
                        <MapPin className="w-3 h-3 shrink-0" />
                        <span className="truncate">{st.mailingAddress}</span>
                      </div>
                      <div className="text-[11px] text-slate-600 dark:text-slate-400 font-mono mt-1 flex flex-wrap items-center gap-3">
                        <span className="inline-flex items-center gap-1">
                          <Phone className="w-3 h-3 text-slate-400" />
                          {st.phone}
                        </span>
                        <span className="inline-flex items-center gap-1">
                          <Mail className="w-3 h-3 text-slate-400" />
                          {st.email}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
                {deal.stakeholders.length === 0 && (
                  <p className="text-xs text-slate-500 dark:text-slate-400">No stakeholders parsed yet.</p>
                )}
              </div>
            </div>

            {/* Outreach & Activity Logger */}
            <div>
              <h3 className="text-xs font-semibold text-slate-900 dark:text-white uppercase tracking-wider mb-2.5">
                Outreach Log & Tasks
              </h3>
              <form onSubmit={handleLogActivity} className="flex gap-2 mb-3">
                <select
                  aria-label="Outreach channel"
                  value={activityChannel}
                  onChange={(e) => setActivityChannel(e.target.value as ActivityLog['channel'])}
                  className="px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-medium text-slate-800 dark:text-slate-100 shrink-0"
                >
                  <option value="Call">Call</option>
                  <option value="SMS">SMS</option>
                  <option value="Direct Mail">Direct Mail</option>
                  <option value="Email">Email</option>
                  <option value="Note">Note</option>
                </select>
                <input
                  type="text"
                  value={activityText}
                  onChange={(e) => setActivityText(e.target.value)}
                  placeholder="Log call outcome, postcard batch, or follow-up note..."
                  className="flex-1 px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-slate-100"
                />
                <button
                  type="submit"
                  aria-label="Log activity"
                  className="px-3 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold flex items-center gap-1 shrink-0"
                >
                  <Send className="w-3.5 h-3.5" />
                  Log
                </button>
              </form>

              <div className="space-y-2 max-h-48 overflow-y-auto">
                {deal.activities.map((act) => (
                  <div
                    key={act.id}
                    className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 text-xs flex items-start gap-2.5"
                  >
                    <MessageSquare className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                    <div className="min-w-0">
                      <div className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">
                        {act.timestamp} · <span className="font-sans font-semibold text-slate-700 dark:text-slate-300">{act.channel}</span>
                      </div>
                      <p className="text-slate-800 dark:text-slate-200 mt-0.5">{act.summary}</p>
                    </div>
                  </div>
                ))}
                {deal.activities.length === 0 && (
                  <div className="text-xs text-slate-500 dark:text-slate-400 py-3 text-center border border-dashed border-slate-200 dark:border-slate-800 rounded-lg">
                    No outreach logged yet. Record your first call, mail piece, or note above.
                  </div>
                )}
              </div>
            </div>

            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
              <span className="flex items-center gap-1.5">
                <Building2 className="w-3.5 h-3.5" />
                {jurisdiction?.courtSystemType ?? 'County Probate Court'}
              </span>
              <span>Synced {jurisdiction?.lastSyncedAt ?? 'Today'}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
