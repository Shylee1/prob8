import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { Compass, Eye, EyeOff, Focus, Layers, RotateCcw } from 'lucide-react';
import type { CrmDeal } from '../types/caselot';
import { calculateEstimatedEquity, formatCurrency } from '../utils/probateLogic';

interface SpatialAtlas3DProps {
  deals: CrmDeal[];
  selectedDealId: string | null;
  theme?: 'light' | 'dark';
  onSelectDeal: (dealId: string) => void;
  onOpenDossier: (dealId: string) => void;
}

type CameraPreset = 'overview' | 'focus' | 'courthouse';

const _vecTarget = new THREE.Vector3();
const _vecPos = new THREE.Vector3();

function createArchitecturalGridTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    ctx.fillStyle = '#e8edf3';
    ctx.fillRect(0, 0, 512, 512);

    // Subtle parcel survey grid
    ctx.strokeStyle = 'rgba(100, 116, 139, 0.16)';
    ctx.lineWidth = 1;
    for (let i = 0; i <= 512; i += 32) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, 512);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(0, i);
      ctx.lineTo(512, i);
      ctx.stroke();
    }

    // Major arterial block lines
    ctx.strokeStyle = 'rgba(51, 65, 85, 0.24)';
    ctx.lineWidth = 2;
    for (let i = 0; i <= 512; i += 128) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, 512);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(0, i);
      ctx.lineTo(512, i);
      ctx.stroke();
    }
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(8, 8);
  return tex;
}

function createContactShadowTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    const grad = ctx.createRadialGradient(64, 64, 8, 64, 64, 60);
    grad.addColorStop(0, 'rgba(15, 23, 42, 0.42)');
    grad.addColorStop(0.55, 'rgba(15, 23, 42, 0.18)');
    grad.addColorStop(1, 'rgba(15, 23, 42, 0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 128, 128);
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function buildCourthouseGroup(shadowTex: THREE.CanvasTexture): THREE.Group {
  const group = new THREE.Group();
  group.name = 'CountyCourthouse';

  const limestoneMat = new THREE.MeshStandardMaterial({
    color: 0xe2e8f0,
    roughness: 0.78,
    metalness: 0.05,
  });
  const graniteMat = new THREE.MeshStandardMaterial({
    color: 0x475569,
    roughness: 0.55,
    metalness: 0.15,
  });
  const bronzeMat = new THREE.MeshStandardMaterial({
    color: 0xb45309,
    roughness: 0.28,
    metalness: 0.85,
  });
  const glassMat = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    roughness: 0.15,
    metalness: 0.6,
  });

  // Contact shadow disc
  const shadowDisc = new THREE.Mesh(
    new THREE.CircleGeometry(3.2, 32),
    new THREE.MeshBasicMaterial({
      map: shadowTex,
      transparent: true,
      depthWrite: false,
      opacity: 0.55,
    })
  );
  shadowDisc.rotation.x = -Math.PI / 2;
  shadowDisc.position.y = 0.015;
  group.add(shadowDisc);

  // 1. Stepped granite base plinth (bottom-center flush y=0)
  const base = new THREE.Mesh(new THREE.BoxGeometry(4.4, 0.28, 3.4), graniteMat);
  base.position.y = 0.14;
  base.castShadow = true;
  base.receiveShadow = true;
  group.add(base);

  const upperStep = new THREE.Mesh(new THREE.BoxGeometry(3.9, 0.22, 2.9), limestoneMat);
  upperStep.position.y = 0.39;
  upperStep.castShadow = true;
  upperStep.receiveShadow = true;
  group.add(upperStep);

  // 2. Main courthouse chamber body
  const hall = new THREE.Mesh(new THREE.BoxGeometry(3.2, 1.35, 2.2), limestoneMat);
  hall.position.y = 1.175;
  hall.castShadow = true;
  hall.receiveShadow = true;
  group.add(hall);

  // 3. Portico columns (front + back colonnade)
  const colGeo = new THREE.CylinderGeometry(0.085, 0.1, 1.35, 14);
  for (let i = -1.2; i <= 1.21; i += 0.6) {
    const colFront = new THREE.Mesh(colGeo, limestoneMat);
    colFront.position.set(i, 1.175, 1.28);
    colFront.castShadow = true;
    group.add(colFront);
  }

  // 4. Recessed bronze/glass courtroom entrance
  const entry = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.95, 0.12), glassMat);
  entry.position.set(0, 0.98, 1.11);
  group.add(entry);

  // 5. Entablature cornice
  const cornice = new THREE.Mesh(new THREE.BoxGeometry(3.6, 0.2, 2.85), graniteMat);
  cornice.position.y = 1.95;
  cornice.castShadow = true;
  group.add(cornice);

  // 6. Rotunda drum & copper/bronze cupola dome
  const drum = new THREE.Mesh(new THREE.CylinderGeometry(0.75, 0.82, 0.55, 24), limestoneMat);
  drum.position.y = 2.32;
  drum.castShadow = true;
  group.add(drum);

  const dome = new THREE.Mesh(
    new THREE.SphereGeometry(0.74, 24, 16, 0, Math.PI * 2, 0, Math.PI / 2),
    bronzeMat
  );
  dome.position.y = 2.58;
  dome.castShadow = true;
  group.add(dome);

  const finial = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.06, 0.35, 10), bronzeMat);
  finial.position.y = 3.45;
  group.add(finial);

  return group;
}

function buildPropertyParcelGroup(
  deal: CrmDeal,
  isSelected: boolean,
  shadowTex: THREE.CanvasTexture
): { group: THREE.Group; proxy: THREE.Mesh; ring: THREE.Mesh } {
  const group = new THREE.Group();
  group.position.set(deal.property.sceneX, 0, deal.property.sceneZ);

  const equity = calculateEstimatedEquity(deal.property.assessedValue, deal.property.estimatedDebt);
  const scaleFactor = deal.property.propertyType === 'Multi-Family' || deal.property.propertyType === 'Commercial' ? 1.2 : 1.0;

  // Color encoding by representation / administration / equity
  const accentHex = isSelected
    ? 0x0284c7
    : deal.probateCase.hasAttorney
      ? 0x475569
      : 0x0f766e;

  const wallMat = new THREE.MeshStandardMaterial({
    color: isSelected ? 0xf8fafc : 0xf1f5f9,
    roughness: 0.78,
    metalness: 0.06,
  });

  const roofMat = new THREE.MeshStandardMaterial({
    color: accentHex,
    roughness: 0.38,
    metalness: 0.32,
  });

  const padMat = new THREE.MeshStandardMaterial({
    color: isSelected ? 0xbae6fd : 0xcbd5e1,
    roughness: 0.85,
    metalness: 0.05,
  });

  const trimMat = new THREE.MeshStandardMaterial({
    color: 0x334155,
    roughness: 0.25,
    metalness: 0.72,
  });

  // Contact shadow disc
  const shadowDisc = new THREE.Mesh(
    new THREE.CircleGeometry(1.45 * scaleFactor, 24),
    new THREE.MeshBasicMaterial({
      map: shadowTex,
      transparent: true,
      depthWrite: false,
      opacity: isSelected ? 0.52 : 0.36,
    })
  );
  shadowDisc.rotation.x = -Math.PI / 2;
  shadowDisc.position.y = 0.015;
  group.add(shadowDisc);

  // 1. Parcel lot pad (flush on ground)
  const lotPad = new THREE.Mesh(new THREE.BoxGeometry(2.2 * scaleFactor, 0.08, 1.9 * scaleFactor), padMat);
  lotPad.position.y = 0.04;
  lotPad.receiveShadow = true;
  group.add(lotPad);

  if (deal.property.propertyType === 'Land / Lot') {
    // Survey boundary posts & corner marker monument
    const monument = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.35, 0.42), roofMat);
    monument.position.y = 0.255;
    monument.castShadow = true;
    group.add(monument);

    const postGeo = new THREE.CylinderGeometry(0.035, 0.035, 0.45, 8);
    const corners: [number, number][] = [
      [-0.85, -0.72],
      [0.85, -0.72],
      [-0.85, 0.72],
      [0.85, 0.72],
    ];
    for (const [cx, cz] of corners) {
      const post = new THREE.Mesh(postGeo, trimMat);
      post.position.set(cx, 0.3, cz);
      group.add(post);
    }
  } else {
    const heightScale = THREE.MathUtils.clamp(0.75 + equity / 500000, 0.8, 1.55);

    // 2. Primary building hull
    const body = new THREE.Mesh(
      new THREE.BoxGeometry(1.35 * scaleFactor, 0.78 * heightScale, 1.05 * scaleFactor),
      wallMat
    );
    body.position.set(-0.1, 0.08 + 0.39 * heightScale, 0);
    body.castShadow = true;
    body.receiveShadow = true;
    group.add(body);

    // 3. Secondary wing / garage mass
    const wing = new THREE.Mesh(
      new THREE.BoxGeometry(0.62 * scaleFactor, 0.56 * heightScale, 0.76 * scaleFactor),
      wallMat
    );
    wing.position.set(0.62 * scaleFactor, 0.08 + 0.28 * heightScale, 0.08);
    wing.castShadow = true;
    group.add(wing);

    // 4. Pitched or commercial parapet roof
    if (deal.property.propertyType === 'Commercial') {
      const parapet = new THREE.Mesh(
        new THREE.BoxGeometry(1.44 * scaleFactor, 0.14, 1.14 * scaleFactor),
        roofMat
      );
      parapet.position.set(-0.1, 0.08 + 0.78 * heightScale + 0.07, 0);
      parapet.castShadow = true;
      group.add(parapet);
    } else {
      const roof = new THREE.Mesh(
        new THREE.ConeGeometry(1.06 * scaleFactor, 0.52, 4),
        roofMat
      );
      roof.rotation.y = Math.PI / 4;
      roof.position.set(-0.1, 0.08 + 0.78 * heightScale + 0.26, 0);
      roof.castShadow = true;
      group.add(roof);
    }

    // 5. Window/door architectural trim accent
    const entryFrame = new THREE.Mesh(
      new THREE.BoxGeometry(0.28, 0.42, 0.06),
      trimMat
    );
    entryFrame.position.set(-0.1, 0.3, 0.53 * scaleFactor);
    group.add(entryFrame);
  }

  // 6. Selection halo ring (offset on Y to prevent Z-fighting)
  const ring = new THREE.Mesh(
    new THREE.RingGeometry(1.28 * scaleFactor, 1.42 * scaleFactor, 32),
    new THREE.MeshBasicMaterial({
      color: isSelected ? 0x0284c7 : 0x0f766e,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: isSelected ? 0.92 : 0.0,
    })
  );
  ring.rotation.x = -Math.PI / 2;
  ring.position.y = 0.035;
  group.add(ring);

  // Invisible raycast proxy box on layer 1 for fast picking
  const proxy = new THREE.Mesh(
    new THREE.BoxGeometry(2.3 * scaleFactor, 1.8, 2.0 * scaleFactor),
    new THREE.MeshBasicMaterial({ visible: false })
  );
  proxy.position.y = 0.9;
  proxy.layers.set(1);
  proxy.userData.dealId = deal.id;
  group.add(proxy);

  return { group, proxy, ring };
}

export const SpatialAtlas3D: React.FC<SpatialAtlas3DProps> = ({
  deals,
  selectedDealId,
  theme = 'light',
  onSelectDeal,
  onOpenDossier,
}) => {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const [hoveredDealId, setHoveredDealId] = useState<string | null>(null);
  const [controlsCollapsed, setControlsCollapsed] = useState(false);
  const [activePreset, setActivePreset] = useState<CameraPreset>('overview');
  const [contextLost, setContextLost] = useState(false);

  const callbacksRef = useRef({ onSelectDeal, onOpenDossier });
  callbacksRef.current = { onSelectDeal, onOpenDossier };

  const dealsRef = useRef(deals);
  dealsRef.current = deals;

  const selectedIdRef = useRef(selectedDealId);
  selectedIdRef.current = selectedDealId;

  const themeRef = useRef(theme);
  themeRef.current = theme;

  const sceneApiRef = useRef<{
    syncParcels: () => void;
    flyToPreset: (preset: CameraPreset) => void;
    applyTheme: (mode: 'light' | 'dark') => void;
  } | null>(null);

  // Initialize Three.js WebGL scene once
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const isSoftwareGl = (() => {
      const probeCanvas = document.createElement('canvas');
      const gl = probeCanvas.getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    const width = container.clientWidth || 900;
    const height = container.clientHeight || 380;

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.08;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.setSize(width, height);
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.appendChild(renderer.domElement);

    const handleContextLost = (e: Event) => {
      e.preventDefault();
      setContextLost(true);
    };
    const handleContextRestored = () => {
      setContextLost(false);
    };
    renderer.domElement.addEventListener('webglcontextlost', handleContextLost);
    renderer.domElement.addEventListener('webglcontextrestored', handleContextRestored);

    const scene = new THREE.Scene();
    const initialBgHex = themeRef.current === 'dark' ? 0x0f172a : 0xdbe4ee;
    scene.background = new THREE.Color(initialBgHex);
    scene.fog = new THREE.FogExp2(initialBgHex, 0.018);

    // Studio environment map on all devices
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 160);
    camera.position.set(14, 11.5, 16);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.target.set(0, 0.6, 0);
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.07;
    controls.maxPolarAngle = Math.PI / 2 - 0.08;
    controls.minDistance = 5;
    controls.maxDistance = 36;

    // Warm key light + cool sky/ground fill
    const hemiLight = new THREE.HemisphereLight(0xe0f2fe, 0x64748b, 0.85);
    hemiLight.position.set(0, 30, 0);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xfff4e0, 1.75);
    keyLight.position.set(12, 18, 10);
    keyLight.castShadow = !isSoftwareGl;
    keyLight.shadow.mapSize.set(1024, 1024);
    keyLight.shadow.camera.near = 2;
    keyLight.shadow.camera.far = 48;
    keyLight.shadow.camera.left = -16;
    keyLight.shadow.camera.right = 16;
    keyLight.shadow.camera.top = 16;
    keyLight.shadow.camera.bottom = -16;
    keyLight.shadow.bias = -0.0005;
    keyLight.shadow.normalBias = 0.02;
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0xbae6fd, 0.55);
    rimLight.position.set(-14, 9, -12);
    scene.add(rimLight);

    // Terrain ground plane with procedural survey grid texture
    const gridTex = createArchitecturalGridTexture();
    gridTex.anisotropy = renderer.capabilities.getMaxAnisotropy();
    const groundMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      map: gridTex,
      roughness: 0.92,
      metalness: 0.02,
    });
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(90, 90), groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground);

    // Subtle arterial avenue strips (offset Y >= 0.02 to avoid Z-fighting)
    const roadMat = new THREE.MeshStandardMaterial({
      color: 0xcbd5e1,
      roughness: 0.85,
      metalness: 0.05,
    });
    const avenueNS = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.02, 34), roadMat);
    avenueNS.position.set(0, 0.015, 0);
    scene.add(avenueNS);
    const avenueEW = new THREE.Mesh(new THREE.BoxGeometry(34, 0.02, 1.1), roadMat);
    avenueEW.position.set(0, 0.015, 0);
    scene.add(avenueEW);

    const shadowTex = createContactShadowTexture();
    const courthouse = buildCourthouseGroup(shadowTex);
    scene.add(courthouse);

    const parcelsRoot = new THREE.Group();
    scene.add(parcelsRoot);

    let pickProxies: THREE.Mesh[] = [];
    const ringsById = new Map<string, THREE.Mesh>();

    let frameId = 0;
    let renderBusy = false;
    let renderDirty = false;
    let isTransitioning = false;
    let lastTime = performance.now();

    const desiredCamPos = new THREE.Vector3(14, 11.5, 16);
    const desiredTarget = new THREE.Vector3(0, 0.6, 0);

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync ? gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0) : null;
      gl.flush();
      const poll = () => {
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (sync && state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    function requestRender() {
      if (renderBusy) {
        renderDirty = true;
        return;
      }
      renderBusy = true;
      frameId = requestAnimationFrame((now) => {
        renderDirty = false;
        const delta = Math.min((now - lastTime) / 1000, 0.1);
        lastTime = now;

        if (isTransitioning) {
          const factor = 1 - Math.exp(-7 * delta);
          camera.position.lerp(_vecPos.copy(desiredCamPos), factor);
          controls.target.lerp(_vecTarget.copy(desiredTarget), factor);
          if (
            camera.position.distanceTo(desiredCamPos) < 0.06 &&
            controls.target.distanceTo(desiredTarget) < 0.05
          ) {
            camera.position.copy(desiredCamPos);
            controls.target.copy(desiredTarget);
            isTransitioning = false;
          }
        }

        controls.update();
        renderer.render(scene, camera);

        const done = () => {
          renderBusy = false;
          if (renderDirty || isTransitioning) {
            requestRender();
          }
        };
        if (isSoftwareGl) afterDraw(done);
        else done();
      });
    }

    function disposeGroupChildren(grp: THREE.Group) {
      grp.traverse((obj) => {
        if (obj instanceof THREE.Mesh) {
          obj.geometry.dispose();
          if (Array.isArray(obj.material)) {
            obj.material.forEach((m) => m.dispose());
          } else {
            obj.material.dispose();
          }
        }
      });
    }

    function syncParcels() {
      disposeGroupChildren(parcelsRoot);
      parcelsRoot.clear();
      pickProxies = [];
      ringsById.clear();

      for (const deal of dealsRef.current) {
        const isSel = deal.id === selectedIdRef.current;
        const { group, proxy, ring } = buildPropertyParcelGroup(deal, isSel, shadowTex);
        parcelsRoot.add(group);
        pickProxies.push(proxy);
        ringsById.set(deal.id, ring);
      }
      requestRender();
    }

    function flyToPreset(preset: CameraPreset) {
      if (preset === 'overview') {
        desiredCamPos.set(14, 11.5, 16);
        desiredTarget.set(0, 0.6, 0);
      } else if (preset === 'courthouse') {
        desiredCamPos.set(5.2, 4.4, 6.2);
        desiredTarget.set(0, 1.3, 0);
      } else if (preset === 'focus') {
        const active = dealsRef.current.find((d) => d.id === selectedIdRef.current) ?? dealsRef.current[0];
        if (active) {
          desiredTarget.set(active.property.sceneX, 0.6, active.property.sceneZ);
          desiredCamPos.set(active.property.sceneX + 5.2, 4.6, active.property.sceneZ + 5.6);
        }
      }
      isTransitioning = true;
      lastTime = performance.now();
      requestRender();
    }

    function applyTheme(mode: 'light' | 'dark') {
      const hex = mode === 'dark' ? 0x0f172a : 0xdbe4ee;
      scene.background = new THREE.Color(hex);
      scene.fog = new THREE.FogExp2(hex, 0.018);
      groundMat.color.setHex(mode === 'dark' ? 0x475569 : 0xffffff);
      roadMat.color.setHex(mode === 'dark' ? 0x334155 : 0xcbd5e1);
      requestRender();
    }

    sceneApiRef.current = { syncParcels, flyToPreset, applyTheme };
    applyTheme(themeRef.current);

    const handleControlStart = () => {
      isTransitioning = false;
    };
    const handleControlChange = () => {
      requestRender();
    };
    controls.addEventListener('start', handleControlStart);
    controls.addEventListener('change', handleControlChange);

    // Raycasting for parcel selection
    const raycaster = new THREE.Raycaster();
    raycaster.layers.set(1);
    const pointer = new THREE.Vector2();
    let lastMove = 0;

    const updatePointer = (ev: PointerEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      pointer.x = ((ev.clientX - rect.left) / rect.width) * 2 - 1;
      pointer.y = -((ev.clientY - rect.top) / rect.height) * 2 + 1;
    };

    const handlePointerMove = (ev: PointerEvent) => {
      const now = performance.now();
      if (now - lastMove < 50) return;
      lastMove = now;
      updatePointer(ev);
      raycaster.setFromCamera(pointer, camera);
      const hits = raycaster.intersectObjects(pickProxies, false);
      const hitId = hits.length > 0 ? String(hits[0].object.userData.dealId) : null;
      renderer.domElement.style.cursor = hitId ? 'pointer' : 'grab';
      setHoveredDealId((prev) => (prev === hitId ? prev : hitId));
    };

    let downPos = { x: 0, y: 0 };
    const handlePointerDown = (ev: PointerEvent) => {
      downPos = { x: ev.clientX, y: ev.clientY };
    };

    const handlePointerUp = (ev: PointerEvent) => {
      const dist = Math.hypot(ev.clientX - downPos.x, ev.clientY - downPos.y);
      if (dist > 6) return; // Dragged camera, not a click
      updatePointer(ev);
      raycaster.setFromCamera(pointer, camera);
      const hits = raycaster.intersectObjects(pickProxies, false);
      if (hits.length > 0) {
        const hitId = String(hits[0].object.userData.dealId);
        callbacksRef.current.onSelectDeal(hitId);
      }
    };

    renderer.domElement.addEventListener('pointermove', handlePointerMove);
    renderer.domElement.addEventListener('pointerdown', handlePointerDown);
    renderer.domElement.addEventListener('pointerup', handlePointerUp);

    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth || 900;
      const h = container.clientHeight || 380;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
      requestRender();
    };
    window.addEventListener('resize', handleResize);

    // Initial build & pre-warm
    syncParcels();
    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }
    requestRender();

    return () => {
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      window.removeEventListener('resize', handleResize);
      controls.removeEventListener('start', handleControlStart);
      controls.removeEventListener('change', handleControlChange);
      renderer.domElement.removeEventListener('pointermove', handlePointerMove);
      renderer.domElement.removeEventListener('pointerdown', handlePointerDown);
      renderer.domElement.removeEventListener('pointerup', handlePointerUp);
      renderer.domElement.removeEventListener('webglcontextlost', handleContextLost);
      renderer.domElement.removeEventListener('webglcontextrestored', handleContextRestored);
      disposeGroupChildren(parcelsRoot);
      disposeGroupChildren(courthouse);
      gridTex.dispose();
      shadowTex.dispose();
      groundMat.dispose();
      roadMat.dispose();
      controls.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  // Re-sync 3D parcels when filtered deals or selected deal changes
  useEffect(() => {
    sceneApiRef.current?.syncParcels();
  }, [deals, selectedDealId]);

  useEffect(() => {
    sceneApiRef.current?.applyTheme(theme);
  }, [theme]);

  const activeDeal = deals.find((d) => d.id === (hoveredDealId || selectedDealId)) ?? null;

  const triggerPreset = (preset: CameraPreset) => {
    setActivePreset(preset);
    sceneApiRef.current?.flyToPreset(preset);
  };

  return (
    <section
      aria-label="3D Jurisdictional & Parcel Intelligence Atlas"
      className="relative w-full h-[360px] rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden bg-slate-200 dark:bg-slate-900"
      data-testid="spatial-atlas-3d"
    >
      <div ref={mountRef} className="w-full h-full" />

      {contextLost && (
        <div className="absolute inset-0 flex items-center justify-center bg-slate-900/90 text-white text-sm">
          3D WebGL context paused — restoring viewport...
        </div>
      )}

      {/* Top-Left Minimal Legend Badge (no backdrop-blur over WebGL) */}
      <div className="pointer-events-none absolute top-3 left-3 flex flex-col gap-1.5">
        <div className="bg-slate-900/90 text-white px-3 py-1.5 rounded-lg border border-slate-700/80 text-xs flex items-center gap-3">
          <span className="font-display font-semibold tracking-tight">Spatial Parcel Atlas</span>
          <span className="text-slate-400" aria-hidden="true">·</span>
          <span className="text-slate-300 tabular-nums">{deals.length} Mapped Parcels</span>
        </div>

        {activeDeal && (
          <div className="pointer-events-auto bg-white/95 dark:bg-slate-900/95 text-slate-900 dark:text-slate-100 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm max-w-xs">
            <div className="flex items-center justify-between gap-3">
              <span className="font-semibold text-xs truncate">{activeDeal.property.address}</span>
              <span className="font-mono text-[11px] font-semibold text-teal-700 dark:text-teal-400 tabular-nums shrink-0">
                {formatCurrency(
                  calculateEstimatedEquity(
                    activeDeal.property.assessedValue,
                    activeDeal.property.estimatedDebt
                  )
                )}{' '}
                eq
              </span>
            </div>
            <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 truncate">
              {activeDeal.property.countyName}, {activeDeal.property.stateCode} ·{' '}
              {activeDeal.probateCase.adminType} ·{' '}
              {activeDeal.probateCase.hasAttorney ? 'Attorney' : 'Pro Se'}
            </div>
            <button
              type="button"
              onClick={() => onOpenDossier(activeDeal.id)}
              className="mt-1.5 text-[11px] font-semibold text-sky-700 dark:text-sky-400 hover:text-sky-900 dark:hover:text-sky-300 underline underline-offset-2"
            >
              Inspect Dossier
            </button>
          </div>
        )}
      </div>

      {/* Collapsible Bottom Control Dock (Zero Viewport Occlusion) */}
      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex flex-col items-center z-10 max-w-[94%]">
        <button
          type="button"
          onClick={() => setControlsCollapsed((v) => !v)}
          className="mb-1.5 px-3 py-1 rounded-md bg-slate-900/90 text-slate-200 hover:text-white border border-slate-700 text-[11px] font-medium flex items-center gap-1.5 whitespace-nowrap"
          aria-expanded={!controlsCollapsed}
        >
          {controlsCollapsed ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
          {controlsCollapsed ? 'Show Controls' : 'Hide Controls'}
        </button>

        {!controlsCollapsed && (
          <div className="bg-slate-900/92 text-slate-100 px-2.5 py-1.5 rounded-lg border border-slate-700 flex items-center gap-1.5 overflow-x-auto">
            <button
              type="button"
              onClick={() => triggerPreset('overview')}
              className={`px-2.5 py-1 rounded text-xs font-medium flex items-center gap-1.5 whitespace-nowrap shrink-0 transition-colors ${
                activePreset === 'overview'
                  ? 'bg-sky-600 text-white'
                  : 'text-slate-300 hover:bg-slate-800'
              }`}
            >
              <RotateCcw className="w-3.5 h-3.5" />
              County Overview
            </button>
            <button
              type="button"
              onClick={() => triggerPreset('focus')}
              className={`px-2.5 py-1 rounded text-xs font-medium flex items-center gap-1.5 whitespace-nowrap shrink-0 transition-colors ${
                activePreset === 'focus'
                  ? 'bg-sky-600 text-white'
                  : 'text-slate-300 hover:bg-slate-800'
              }`}
            >
              <Focus className="w-3.5 h-3.5" />
              Focus Parcel
            </button>
            <button
              type="button"
              onClick={() => triggerPreset('courthouse')}
              className={`px-2.5 py-1 rounded text-xs font-medium flex items-center gap-1.5 whitespace-nowrap shrink-0 transition-colors ${
                activePreset === 'courthouse'
                  ? 'bg-sky-600 text-white'
                  : 'text-slate-300 hover:bg-slate-800'
              }`}
            >
              <Compass className="w-3.5 h-3.5" />
              Courthouse Axis
            </button>

            <span className="h-4 w-px bg-slate-700 mx-1 shrink-0" aria-hidden="true" />

            <div className="flex items-center gap-2.5 px-2 text-[11px] text-slate-300 whitespace-nowrap shrink-0">
              <span className="inline-flex items-center gap-1">
                <span className="w-2.5 h-2.5 rounded-xs bg-teal-600 inline-block" />
                Pro Se
              </span>
              <span className="inline-flex items-center gap-1">
                <span className="w-2.5 h-2.5 rounded-xs bg-slate-500 inline-block" />
                Represented
              </span>
              <span className="inline-flex items-center gap-1">
                <Layers className="w-3 h-3 text-sky-400" />
                Height = Equity
              </span>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
