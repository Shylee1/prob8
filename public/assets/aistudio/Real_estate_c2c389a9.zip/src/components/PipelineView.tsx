import React, { useMemo, useState } from 'react';
import { ArrowLeft, ArrowRight, Calendar, FileText, MapPin } from 'lucide-react';
import type { CrmDeal, DealStage } from '../types/caselot';
import { DEAL_STAGES } from '../types/caselot';
import {
  calculateEstimatedEquity,
  computePipelineMetrics,
  formatCurrency,
} from '../utils/probateLogic';

interface PipelineViewProps {
  deals: CrmDeal[];
  onMoveStage: (dealId: string, nextStage: DealStage) => void;
  onOpenDossier: (dealId: string) => void;
  onOpenForms: (dealId: string) => void;
}

export const PipelineView: React.FC<PipelineViewProps> = ({
  deals,
  onMoveStage,
  onOpenDossier,
  onOpenForms,
}) => {
  const [draggedDealId, setDraggedDealId] = useState<string | null>(null);
  const [stateFilter, setStateFilter] = useState('ALL');

  const pipelineDeals = useMemo(() => {
    return deals.filter(
      (d) => d.inPipeline && (stateFilter === 'ALL' || d.property.stateCode === stateFilter)
    );
  }, [deals, stateFilter]);

  const metrics = useMemo(() => computePipelineMetrics(pipelineDeals), [pipelineDeals]);

  const handleDrop = (stage: DealStage) => {
    if (draggedDealId) {
      onMoveStage(draggedDealId, stage);
      setDraggedDealId(null);
    }
  };

  return (
    <div className="space-y-5">
      {/* Header & Summary Strip */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
            Acquisition Pipeline & CRM
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
            Drag cards across probate acquisition stages or inspect split-screen property dossiers.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <label htmlFor="pipeline-state-filter" className="text-xs font-medium text-slate-600 dark:text-slate-400">
            Jurisdiction:
          </label>
          <select
            id="pipeline-state-filter"
            value={stateFilter}
            onChange={(e) => setStateFilter(e.target.value)}
            className="px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700/80 bg-white dark:bg-[#0E1525] text-xs font-medium text-slate-900 dark:text-slate-100"
          >
            <option value="ALL">All US States</option>
            <option value="TX">Texas (TX)</option>
            <option value="AZ">Arizona (AZ)</option>
            <option value="FL">Florida (FL)</option>
            <option value="IL">Illinois (IL)</option>
            <option value="GA">Georgia (GA)</option>
          </select>
        </div>
      </div>

      {/* Pipeline KPI Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bento-card p-4">
          <div className="text-xs text-slate-500 dark:text-slate-400">Active Pipeline Estates</div>
          <div className="font-mono text-xl font-bold text-slate-900 dark:text-white tabular-nums mt-1">
            {metrics.totalPipelineDeals}
          </div>
        </div>
        <div className="bento-card p-4">
          <div className="text-xs text-slate-500 dark:text-slate-400">Gross Assessor Valuation</div>
          <div className="font-mono text-xl font-bold text-slate-900 dark:text-white tabular-nums mt-1">
            {formatCurrency(metrics.totalAssessedValue)}
          </div>
        </div>
        <div className="bento-card p-4">
          <div className="text-xs text-slate-500 dark:text-slate-400">Pipeline Net Equity</div>
          <div className="font-mono text-xl font-bold text-emerald-700 dark:text-emerald-400 tabular-nums mt-1">
            {formatCurrency(metrics.totalEstimatedEquity)}
          </div>
        </div>
        <div className="bento-card p-4">
          <div className="text-xs text-slate-500 dark:text-slate-400">In Court Approval</div>
          <div className="font-mono text-xl font-bold text-sky-700 dark:text-sky-400 tabular-nums mt-1">
            {metrics.courtApprovalCount}
          </div>
        </div>
      </div>

      {/* 8-Stage Horizontal Kanban Board */}
      <div className="overflow-x-auto pb-3">
        <div className="flex gap-3 min-w-max">
          {DEAL_STAGES.map((stage, stageIdx) => {
            const columnDeals = pipelineDeals.filter((d) => d.stage === stage);
            const columnEquity = metrics.stageEquity[stage] || 0;

            return (
              <div
                key={stage}
                onDragOver={(e) => e.preventDefault()}
                onDrop={() => handleDrop(stage)}
                className="w-[272px] shrink-0 bg-slate-100/80 dark:bg-[#080D18] border border-slate-200 dark:border-slate-800/90 rounded-2xl flex flex-col max-h-[640px]"
              >
                <div className="p-3 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1424] rounded-t-2xl">
                  <div className="flex items-center justify-between gap-2">
                    <h2 className="font-display text-xs font-bold text-slate-900 dark:text-white truncate">
                      {stage}
                    </h2>
                    <span className="font-mono text-xs font-semibold text-slate-500 dark:text-slate-400 tabular-nums">
                      {columnDeals.length}
                    </span>
                  </div>
                  <div className="font-mono text-[11px] text-emerald-700 dark:text-emerald-400 tabular-nums mt-0.5">
                    {formatCurrency(columnEquity)} eq
                  </div>
                </div>

                <div className="p-2.5 space-y-2.5 overflow-y-auto flex-1">
                  {columnDeals.map((deal) => {
                    const equity = calculateEstimatedEquity(
                      deal.property.assessedValue,
                      deal.property.estimatedDebt
                    );
                    const prevStage = stageIdx > 0 ? DEAL_STAGES[stageIdx - 1] : null;
                    const nextStage =
                      stageIdx < DEAL_STAGES.length - 1 ? DEAL_STAGES[stageIdx + 1] : null;

                    return (
                      <article
                        key={deal.id}
                        draggable
                        onDragStart={() => setDraggedDealId(deal.id)}
                        className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg p-3 hover:border-slate-300 dark:hover:border-slate-700 transition-colors"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <button
                            type="button"
                            onClick={() => onOpenDossier(deal.id)}
                            className="text-left font-semibold text-xs text-slate-900 dark:text-white hover:text-sky-700 dark:hover:text-sky-400 leading-snug"
                          >
                            {deal.property.address}
                          </button>
                          <span className="font-mono text-[11px] font-semibold text-emerald-700 dark:text-emerald-400 tabular-nums shrink-0">
                            {formatCurrency(equity)}
                          </span>
                        </div>

                        <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 flex items-center gap-1 truncate">
                          <MapPin className="w-3 h-3 shrink-0" />
                          <span>
                            {deal.property.countyName}, {deal.property.stateCode} ·{' '}
                            {deal.probateCase.caseNumber}
                          </span>
                        </div>

                        <div className="text-[11px] text-slate-600 dark:text-slate-300 mt-1.5">
                          Estate of {deal.probateCase.decedentName}
                        </div>

                        <div className="mt-2 pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
                          <span className="font-mono tabular-nums">
                            Offer {formatCurrency(deal.offerAmount)}
                          </span>
                          <span className="inline-flex items-center gap-1 font-mono tabular-nums">
                            <Calendar className="w-3 h-3" />
                            {deal.nextFollowupAt}
                          </span>
                        </div>

                        <div className="mt-2.5 flex items-center justify-between gap-1">
                          <div className="flex items-center gap-1">
                            {prevStage && (
                              <button
                                type="button"
                                aria-label={`Move ${deal.property.address} back to ${prevStage}`}
                                onClick={() => onMoveStage(deal.id, prevStage)}
                                className="p-1 rounded border border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-slate-800"
                              >
                                <ArrowLeft className="w-3 h-3" />
                              </button>
                            )}
                            {nextStage && (
                              <button
                                type="button"
                                aria-label={`Advance ${deal.property.address} to ${nextStage}`}
                                onClick={() => onMoveStage(deal.id, nextStage)}
                                className="p-1 rounded border border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-slate-800"
                              >
                                <ArrowRight className="w-3 h-3" />
                              </button>
                            )}
                          </div>

                          <div className="flex items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => onOpenForms(deal.id)}
                              className="px-2 py-1 rounded text-[11px] font-medium text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 inline-flex items-center gap-1"
                            >
                              <FileText className="w-3 h-3" />
                              Forms
                            </button>
                            <button
                              type="button"
                              onClick={() => onOpenDossier(deal.id)}
                              className="px-2 py-1 rounded bg-slate-900 dark:bg-sky-600 hover:bg-slate-800 dark:hover:bg-sky-500 text-white text-[11px] font-semibold"
                            >
                              Dossier
                            </button>
                          </div>
                        </div>
                      </article>
                    );
                  })}

                  {columnDeals.length === 0 && (
                    <div className="py-6 px-3 text-center text-[11px] text-slate-400 dark:text-slate-500 border border-dashed border-slate-200 dark:border-slate-800 rounded-lg">
                      Drop deal here
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
