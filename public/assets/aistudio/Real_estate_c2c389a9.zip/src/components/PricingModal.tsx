import React, { useState } from 'react';
import { Check, Sparkles, X } from 'lucide-react';
import type { PlanTier } from '../types/caselot';

interface PricingModalProps {
  currentPlan: PlanTier;
  onSelectPlan: (plan: PlanTier) => void;
  onClose: () => void;
  highlightFeature?: string | null;
}

interface TierSpec {
  id: PlanTier;
  name: string;
  audience: string;
  monthlyPrice: number;
  annualPrice: number;
  description: string;
  limits: string[];
  recommended?: boolean;
}

const TIERS: TierSpec[] = [
  {
    id: 'free',
    name: 'Starter Free',
    audience: 'Solo Investors',
    monthlyPrice: 0,
    annualPrice: 0,
    description: 'Core probate docket discovery, Google Maps parcel view, and single-deal CRM.',
    limits: [
      'Up to 25 court docket syncs / month',
      'Interactive Google Maps & 3D Spatial Atlas',
      'Up to 5 fillable court & LOI PDF packets / month',
      'Standard Texas Tyler Odyssey preview connector',
    ],
  },
  {
    id: 'pro',
    name: 'Acquisition Pro',
    audience: 'Active Deal Teams',
    monthlyPrice: 79,
    annualPrice: 64,
    recommended: true,
    description: 'Automated multi-county feeds, bulk assessor CSV exports, and unlimited transaction PDFs.',
    limits: [
      'Unlimited automated court vendor syncs (TX, AZ, FL, GA)',
      'Bulk Assessor-Matched CSV & Direct Mail export',
      'Unlimited auto-populated state purchase addenda & LOIs',
      'Saved search instant docket alerts (up to 25)',
    ],
  },
  {
    id: 'enterprise',
    name: 'Enterprise Local AI',
    audience: 'Institutional Funds',
    monthlyPrice: 249,
    annualPrice: 199,
    description: 'Full self-hosted Docling + Ollama / vLLM worker cluster with zero per-token AI fees.',
    limits: [
      'Everything in Acquisition Pro + Multi-seat CRM',
      'Self-hosted Docker Worker (Docling OCR + Gemma 4 / Qwen 3)',
      'Custom county FOIA / GIS assessor roll cross-matching',
      'Dedicated webhook & title-company packet API',
    ],
  },
];

export const PricingModal: React.FC<PricingModalProps> = ({
  currentPlan,
  onSelectPlan,
  onClose,
  highlightFeature,
}) => {
  const [annualBilling, setAnnualBilling] = useState(true);

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/75 flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="pricing-modal-title"
    >
      <div className="bg-white dark:bg-[#0B111E] border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-5xl max-h-[92vh] flex flex-col overflow-hidden shadow-2xl">
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#070B14] flex items-center justify-between gap-4">
          <div>
            <h2 id="pricing-modal-title" className="font-display text-lg font-bold text-slate-900 dark:text-slate-100">
              CaseLot US Transparent Pricing — Zero Hidden Coaching Upsells
            </h2>
            <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
              50-state probate statutes, 3D/AR/VR property twin, deal calculator, and Google Maps discovery stay free forever. Upgrade only for bulk team workflows.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close pricing modal"
            className="p-2 rounded-lg text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-200/60 dark:hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto space-y-5">
          {highlightFeature && (
            <div className="px-4 py-2.5 rounded-lg bg-sky-50 dark:bg-sky-950/50 border border-sky-200 dark:border-sky-800 text-xs text-sky-900 dark:text-sky-200 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-sky-600 dark:text-sky-400 shrink-0" />
              <span>
                <strong>{highlightFeature}</strong> is an optional paid add-on. Activate Acquisition Pro or Enterprise below to unlock immediately.
              </span>
            </div>
          )}

          {/* Billing Cadence Toggle */}
          <div className="flex items-center justify-center gap-3 text-xs">
            <button
              type="button"
              onClick={() => setAnnualBilling(false)}
              className={`px-3 py-1.5 rounded-lg font-medium border transition-colors ${
                !annualBilling
                  ? 'bg-slate-900 dark:bg-sky-600 text-white border-slate-900 dark:border-sky-600'
                  : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-300 dark:border-slate-700'
              }`}
            >
              Monthly Billing
            </button>
            <button
              type="button"
              onClick={() => setAnnualBilling(true)}
              className={`px-3 py-1.5 rounded-lg font-medium border transition-colors ${
                annualBilling
                  ? 'bg-slate-900 dark:bg-sky-600 text-white border-slate-900 dark:border-sky-600'
                  : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-300 dark:border-slate-700'
              }`}
            >
              Annual Billing (Save 19%)
            </button>
          </div>

          {/* 3-Tier SaaS Pricing Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {TIERS.map((tier) => {
              const price = annualBilling ? tier.annualPrice : tier.monthlyPrice;
              const isCurrent = currentPlan === tier.id;

              return (
                <div
                  key={tier.id}
                  className={`rounded-xl p-5 border flex flex-col justify-between transition-colors ${
                    tier.recommended
                      ? 'border-sky-600 dark:border-sky-500 bg-sky-50/40 dark:bg-slate-800/80'
                      : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[11px] font-semibold text-sky-700 dark:text-sky-400 uppercase tracking-wider">
                        {tier.audience}
                      </span>
                      {tier.recommended && (
                        <span className="text-[11px] font-semibold text-slate-700 dark:text-slate-300">
                          Most Popular
                        </span>
                      )}
                    </div>

                    <h3 className="font-display text-base font-bold text-slate-900 dark:text-white mt-1">
                      {tier.name}
                    </h3>

                    <div className="mt-3 flex items-baseline gap-1">
                      <span className="font-mono text-3xl font-bold text-slate-900 dark:text-white tabular-nums">
                        ${price}
                      </span>
                      <span className="text-xs text-slate-500 dark:text-slate-400">
                        {price === 0 ? 'forever' : '/ month'}
                      </span>
                    </div>

                    <p className="text-xs text-slate-600 dark:text-slate-400 mt-2.5 leading-relaxed">
                      {tier.description}
                    </p>

                    <ul className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-800 space-y-2 text-xs text-slate-700 dark:text-slate-300">
                      {tier.limits.map((lim) => (
                        <li key={lim} className="flex items-start gap-2">
                          <Check className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
                          <span>{lim}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      onSelectPlan(tier.id);
                      onClose();
                    }}
                    className={`mt-5 w-full py-2.5 px-4 rounded-lg text-xs font-semibold transition-colors ${
                      isCurrent
                        ? 'bg-emerald-700 text-white'
                        : tier.recommended
                          ? 'bg-sky-600 hover:bg-sky-500 text-white'
                          : 'bg-slate-900 hover:bg-slate-800 dark:bg-slate-800 dark:hover:bg-slate-700 text-white'
                    }`}
                  >
                    {isCurrent
                      ? 'Active Plan'
                      : tier.id === 'free'
                        ? 'Switch to Starter Free'
                        : `Activate ${tier.name}`}
                  </button>
                </div>
              );
            })}
          </div>

          {/* 2026 Pay-As-You-Go Add-On & Usage Rate Card */}
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 p-4 space-y-2.5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="font-display text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                2026 Pay-As-You-Go Probate Add-On Rates
              </h3>
              <span className="text-[11px] text-slate-500 dark:text-slate-400">
                Optional usage credits · No markup on self-hosted AI models
              </span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 text-xs">
              <div className="p-2.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                <div className="font-semibold text-slate-900 dark:text-white">Heir & PR Skip Trace</div>
                <div className="font-mono font-bold text-sky-700 dark:text-sky-400 mt-0.5 tabular-nums">
                  $0.14 / match
                </div>
              </div>
              <div className="p-2.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                <div className="font-semibold text-slate-900 dark:text-white">Lob Certified Mailer</div>
                <div className="font-mono font-bold text-sky-700 dark:text-sky-400 mt-0.5 tabular-nums">
                  $1.35 / letter
                </div>
              </div>
              <div className="p-2.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                <div className="font-semibold text-slate-900 dark:text-white">Zillow/Redfin AVM Sync</div>
                <div className="font-mono font-bold text-emerald-700 dark:text-emerald-400 mt-0.5 tabular-nums">
                  Included ($0)
                </div>
              </div>
              <div className="p-2.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                <div className="font-semibold text-slate-900 dark:text-white">Extra Local AI Worker</div>
                <div className="font-mono font-bold text-sky-700 dark:text-sky-400 mt-0.5 tabular-nums">
                  $29 / node / mo
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
