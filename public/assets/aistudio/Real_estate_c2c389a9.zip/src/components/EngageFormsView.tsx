import React, { useEffect, useMemo, useState } from 'react';
import {
  CheckCircle2,
  Download,
  FileText,
  Loader2,
  Printer,
  ShieldAlert,
} from 'lucide-react';
import type {
  BuyerProfile,
  CrmDeal,
  FormTemplate,
  GeneratedDoc,
  Jurisdiction,
  PlanTier,
} from '../types/caselot';
import type { AutoPopulatedFormFields } from '../utils/probateLogic';
import { buildFormFieldMap } from '../utils/probateLogic';
import { generateProbateFormPdf } from '../utils/pdfGenerator';

interface EngageFormsViewProps {
  deals: CrmDeal[];
  jurisdictions: Jurisdiction[];
  templates: FormTemplate[];
  activeDeal: CrmDeal;
  onSelectDeal: (dealId: string) => void;
  buyerProfile: BuyerProfile;
  onUpdateBuyerProfile: (next: BuyerProfile) => void;
  generatedDocs: GeneratedDoc[];
  onRecordGeneratedDoc: (doc: GeneratedDoc) => void;
  planTier: PlanTier;
  onRequireUpgrade: (featureName: string) => void;
}

export const EngageFormsView: React.FC<EngageFormsViewProps> = ({
  deals,
  jurisdictions,
  templates,
  activeDeal,
  onSelectDeal,
  buyerProfile,
  onUpdateBuyerProfile,
  generatedDocs,
  onRecordGeneratedDoc,
  planTier,
  onRequireUpgrade,
}) => {
  const [selectedTemplateId, setSelectedTemplateId] = useState(templates[0]?.id ?? '');
  const selectedTemplate =
    templates.find((t) => t.id === selectedTemplateId) ?? templates[0];

  const jurisdiction = jurisdictions.find(
    (j) => j.id === activeDeal.probateCase.jurisdictionId
  );

  const computedFields = useMemo(
    () => buildFormFieldMap(activeDeal, jurisdiction, buyerProfile),
    [activeDeal, jurisdiction, buyerProfile]
  );

  const [fieldOverrides, setFieldOverrides] = useState<AutoPopulatedFormFields>(computedFields);
  const [generating, setGenerating] = useState(false);
  const [lastPdfUrl, setLastPdfUrl] = useState<string | null>(null);
  const [lastFileName, setLastFileName] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    setFieldOverrides(computedFields);
    setLastPdfUrl(null);
    setLastFileName(null);
  }, [computedFields]);

  const handleGeneratePdf = async () => {
    if (!selectedTemplate) return;
    if (planTier === 'free' && generatedDocs.length >= 5) {
      onRequireUpgrade('Unlimited Fillable Court & Purchase Packets');
      return;
    }
    setGenerating(true);
    setErrorMsg(null);
    try {
      const result = await generateProbateFormPdf(selectedTemplate, fieldOverrides);
      if (lastPdfUrl) URL.revokeObjectURL(lastPdfUrl);
      setLastPdfUrl(result.blobUrl);
      setLastFileName(result.fileName);

      onRecordGeneratedDoc({
        id: `doc-${Date.now()}`,
        dealId: activeDeal.id,
        templateId: selectedTemplate.id,
        templateTitle: selectedTemplate.title,
        fileName: result.fileName,
        createdAt: new Date().toISOString().slice(0, 16).replace('T', ' '),
        offerAmount: activeDeal.offerAmount,
        buyerEntity: fieldOverrides.buyerEntity,
        recipientName: fieldOverrides.recipientName,
      });
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to generate PDF packet.');
    } finally {
      setGenerating(false);
    }
  };

  const dealDocs = generatedDocs.filter((d) => d.dealId === activeDeal.id);

  return (
    <div className="space-y-5">
      {/* Header & Deal Selector */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
            Engage & Auto-Populated Forms
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
            Populate state-specific letters, LOIs, and probate purchase addenda directly from CRM estate data.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <label htmlFor="engage-deal-select" className="text-xs font-medium text-slate-600 dark:text-slate-400">
            Subject Estate:
          </label>
          <select
            id="engage-deal-select"
            value={activeDeal.id}
            onChange={(e) => onSelectDeal(e.target.value)}
            className="px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold text-slate-900 dark:text-slate-100 max-w-xs"
          >
            {deals.map((d) => (
              <option key={d.id} value={d.id}>
                {d.property.address} ({d.property.stateCode}) — {d.probateCase.caseNumber}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Template Selector Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {templates.map((tpl) => {
          const isActive = tpl.id === selectedTemplate?.id;
          return (
            <button
              key={tpl.id}
              type="button"
              onClick={() => setSelectedTemplateId(tpl.id)}
              className={`text-left p-3.5 rounded-xl border transition-colors ${
                isActive
                  ? 'bg-slate-900 dark:bg-sky-600 text-white border-slate-900 dark:border-sky-600'
                  : 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
              }`}
            >
              <div className={`text-[11px] font-medium ${isActive ? 'text-sky-200' : 'text-slate-500 dark:text-slate-400'}`}>
                {tpl.category}
              </div>
              <div className="font-display text-xs font-bold mt-1 leading-snug">{tpl.title}</div>
            </button>
          );
        })}
      </div>

      {/* Split Workspace: Field Editor (Left) + Live Packet Preview & PDF Export (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left 5 Cols: Auto-Populated CRM Field Mapping */}
        <div className="lg:col-span-5 bento-card p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
            <h2 className="font-display text-sm font-bold text-slate-900 dark:text-white">
              Mapped Estate & Buyer Fields
            </h2>
            <span className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
              {activeDeal.property.countyName}, {activeDeal.property.stateCode}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="sm:col-span-2">
              <label htmlFor="form-estate-name" className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                Estate Matter
              </label>
              <input
                id="form-estate-name"
                type="text"
                value={fieldOverrides.estateName}
                onChange={(e) => setFieldOverrides({ ...fieldOverrides, estateName: e.target.value })}
                className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
              />
            </div>

            <div>
              <label htmlFor="form-case-num" className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                Case / Cause Number
              </label>
              <input
                id="form-case-num"
                type="text"
                value={fieldOverrides.caseNumber}
                onChange={(e) => setFieldOverrides({ ...fieldOverrides, caseNumber: e.target.value })}
                className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 font-mono text-slate-900 dark:text-slate-100"
              />
            </div>

            <div>
              <label htmlFor="form-apn" className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                Parcel ID / APN
              </label>
              <input
                id="form-apn"
                type="text"
                value={fieldOverrides.parcelId}
                onChange={(e) => setFieldOverrides({ ...fieldOverrides, parcelId: e.target.value })}
                className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 font-mono text-slate-900 dark:text-slate-100"
              />
            </div>

            <div className="sm:col-span-2">
              <label htmlFor="form-prop-addr" className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                Property Address
              </label>
              <input
                id="form-prop-addr"
                type="text"
                value={fieldOverrides.propertyAddress}
                onChange={(e) => setFieldOverrides({ ...fieldOverrides, propertyAddress: e.target.value })}
                className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
              />
            </div>

            <div>
              <label htmlFor="form-recipient" className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                Executor / PR Recipient
              </label>
              <input
                id="form-recipient"
                type="text"
                value={fieldOverrides.recipientName}
                onChange={(e) => setFieldOverrides({ ...fieldOverrides, recipientName: e.target.value })}
                className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
              />
            </div>

            <div>
              <label htmlFor="form-offer" className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                Offer Amount
              </label>
              <input
                id="form-offer"
                type="text"
                value={fieldOverrides.offerAmount}
                onChange={(e) => setFieldOverrides({ ...fieldOverrides, offerAmount: e.target.value })}
                className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 font-mono text-slate-900 dark:text-slate-100"
              />
            </div>

            <div className="sm:col-span-2 pt-2 border-t border-slate-100 dark:border-slate-800">
              <label htmlFor="form-buyer-entity" className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                Buyer Acquisition Entity
              </label>
              <input
                id="form-buyer-entity"
                type="text"
                value={fieldOverrides.buyerEntity}
                onChange={(e) => {
                  const val = e.target.value;
                  setFieldOverrides({ ...fieldOverrides, buyerEntity: val });
                  onUpdateBuyerProfile({ ...buyerProfile, entityName: val });
                }}
                className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
              />
            </div>

            <div>
              <label htmlFor="form-earnest" className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                Earnest Money
              </label>
              <input
                id="form-earnest"
                type="text"
                value={fieldOverrides.earnestMoney}
                onChange={(e) => setFieldOverrides({ ...fieldOverrides, earnestMoney: e.target.value })}
                className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 font-mono text-slate-900 dark:text-slate-100"
              />
            </div>

            <div>
              <label htmlFor="form-closing" className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                Closing Window
              </label>
              <input
                id="form-closing"
                type="text"
                value={fieldOverrides.closingDays}
                onChange={(e) => setFieldOverrides({ ...fieldOverrides, closingDays: e.target.value })}
                className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>

          <div className="pt-2 flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={handleGeneratePdf}
              disabled={generating}
              className="flex-1 px-4 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 disabled:opacity-60 text-white text-xs font-semibold flex items-center justify-center gap-2 whitespace-nowrap"
            >
              {generating ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileText className="w-4 h-4" />}
              Generate Fillable PDF Packet
            </button>

            {lastPdfUrl && lastFileName && (
              <a
                href={lastPdfUrl}
                download={lastFileName}
                className="px-4 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap"
              >
                <Download className="w-4 h-4" />
                Download PDF
              </a>
            )}
          </div>

          {planTier === 'free' && (
            <p className="text-[11px] text-slate-500 dark:text-slate-400 tabular-nums">
              Free Tier: {Math.min(generatedDocs.length, 5)} / 5 monthly PDF packets used.
            </p>
          )}

          {errorMsg && (
            <div className="p-2.5 rounded-lg bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-xs text-rose-800 dark:text-rose-200">
              {errorMsg}
            </div>
          )}

          {lastPdfUrl && lastFileName && (
            <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-900 dark:text-emerald-200 flex items-center justify-between gap-2">
              <span className="flex items-center gap-1.5 font-medium truncate">
                <CheckCircle2 className="w-4 h-4 text-emerald-700 dark:text-emerald-400 shrink-0" />
                Ready: <span className="font-mono truncate">{lastFileName}</span>
              </span>
              <button
                type="button"
                onClick={() => window.print()}
                className="text-emerald-800 dark:text-emerald-300 hover:text-emerald-950 font-semibold inline-flex items-center gap-1 shrink-0"
              >
                <Printer className="w-3.5 h-3.5" />
                Print
              </button>
            </div>
          )}
        </div>

        {/* Right 7 Cols: Live Document Preview + Generated Document History */}
        <div className="lg:col-span-7 space-y-5">
          <div className="bento-card overflow-hidden">
            <div className="bg-slate-900 dark:bg-[#070B14] text-white px-5 py-4 flex items-center justify-between gap-4 border-b border-slate-800">
              <div>
                <div className="text-[11px] font-mono text-slate-400">
                  CASELOT US TRANSACTION PACKET · {fieldOverrides.countyState.toUpperCase()}
                </div>
                <h3 className="font-display text-sm font-bold mt-0.5">
                  {selectedTemplate?.title}
                </h3>
              </div>
              <span className="font-mono text-xs text-sky-300 shrink-0">
                {fieldOverrides.caseNumber}
              </span>
            </div>

            <div className="p-5 space-y-4 text-xs text-slate-800 dark:text-slate-200">
              <div className="grid grid-cols-2 gap-3 p-3 bento-inset">
                <div>
                  <span className="text-slate-500 dark:text-slate-400 block">Estate Matter</span>
                  <strong className="text-slate-900 dark:text-white">{fieldOverrides.estateName}</strong>
                </div>
                <div>
                  <span className="text-slate-500 dark:text-slate-400 block">Court Venue</span>
                  <strong className="text-slate-900 dark:text-white">{fieldOverrides.courtSystem}</strong>
                </div>
                <div>
                  <span className="text-slate-500 dark:text-slate-400 block">Subject Property</span>
                  <strong className="text-slate-900 dark:text-white">{fieldOverrides.propertyAddress}</strong>
                </div>
                <div>
                  <span className="text-slate-500 dark:text-slate-400 block">Parcel ID / APN</span>
                  <strong className="font-mono text-slate-900 dark:text-white">{fieldOverrides.parcelId}</strong>
                </div>
              </div>

              <div>
                <h4 className="font-semibold text-slate-900 dark:text-white uppercase tracking-wider text-[11px] mb-2">
                  Proposed Transaction Summary
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 border-y border-slate-100 dark:border-slate-800 py-2.5">
                  <div>
                    <span className="text-slate-500 dark:text-slate-400 block">Purchase Offer</span>
                    <strong className="font-mono text-slate-900 dark:text-white">{fieldOverrides.offerAmount}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 dark:text-slate-400 block">Earnest Money</span>
                    <strong className="font-mono text-slate-900 dark:text-white">{fieldOverrides.earnestMoney}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 dark:text-slate-400 block">Inspection</span>
                    <strong className="text-slate-900 dark:text-white">{fieldOverrides.inspectionDays}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 dark:text-slate-400 block">Closing Target</span>
                    <strong className="text-slate-900 dark:text-white">{fieldOverrides.closingDays}</strong>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-semibold text-slate-900 dark:text-white uppercase tracking-wider text-[11px] mb-1.5">
                  Localized Probate Contingency
                </h4>
                <p className="p-3 bento-inset font-medium text-slate-900 dark:text-slate-100 leading-relaxed">
                  {fieldOverrides.probateContingencyClause}
                </p>
              </div>

              <ul className="space-y-1.5 text-slate-600 dark:text-slate-400 list-disc pl-4">
                {selectedTemplate?.clauses.map((cl) => (
                  <li key={cl}>{cl}</li>
                ))}
              </ul>

              {fieldOverrides.federalNotice && (
                <div className="bento-inset p-3 text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
                  {fieldOverrides.federalNotice}
                </div>
              )}

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-start gap-2 text-[11px] text-slate-500 dark:text-slate-400">
                <ShieldAlert className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
                <span>
                  Informational Template Only — Not Legal Advice. Have licensed local probate counsel review
                  court-specific addenda prior to execution.
                </span>
              </div>
            </div>
          </div>

          {/* Generated Document History */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4">
            <h3 className="font-display text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-2.5">
              Generated Document History ({dealDocs.length})
            </h3>
            {dealDocs.length === 0 ? (
              <p className="text-xs text-slate-500 dark:text-slate-400">
                No PDF packets generated for this estate yet. Click &ldquo;Generate Fillable PDF Packet&rdquo; above.
              </p>
            ) : (
              <div className="space-y-2">
                {dealDocs.map((doc) => (
                  <div
                    key={doc.id}
                    className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 flex items-center justify-between gap-3 text-xs"
                  >
                    <div className="min-w-0">
                      <div className="font-semibold text-slate-900 dark:text-white truncate">{doc.templateTitle}</div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400 font-mono truncate">
                        {doc.fileName} · {doc.createdAt}
                      </div>
                    </div>
                    <span className="font-mono text-xs font-semibold text-slate-700 dark:text-slate-300 shrink-0">
                      {doc.buyerEntity}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
