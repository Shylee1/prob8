/// <reference types="google.maps" />
import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  APIProvider,
  AdvancedMarker,
  ColorScheme,
  InfoWindow,
  Map as GoogleMap,
  Pin,
  useAdvancedMarkerRef,
  useMap,
  useMapsLibrary,
} from '@vis.gl/react-google-maps';
import { LocateFixed, MapPin, Search, X } from 'lucide-react';
import type { CrmDeal, ThemeMode } from '../types/caselot';
import { calculateEstimatedEquity, formatCurrency } from '../utils/probateLogic';

interface GoogleParcelMapProps {
  apiKey: string;
  deals: CrmDeal[];
  selectedDealId: string | null;
  theme: ThemeMode;
  onSelectDeal: (dealId: string) => void;
  onOpenDossier: (dealId: string) => void;
  onOpenPropertyPage?: (dealId: string) => void;
  onLocationFilter?: (label: string) => void;
}

interface SearchedLocation {
  label: string;
  lat: number;
  lng: number;
}

function isQuotaError(err: unknown): boolean {
  const text = err instanceof Error ? err.message : String(err);
  return /RESOURCE_EXHAUSTED|OVER_QUERY_LIMIT|QuotaExceeded|429/i.test(text);
}

function usePlaceAutocomplete(inputString: string) {
  const placesLib = useMapsLibrary('places');
  const sessionTokenRef = useRef<google.maps.places.AutocompleteSessionToken | null>(null);
  const [suggestions, setSuggestions] = useState<google.maps.places.AutocompleteSuggestion[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!placesLib) return;
    const trimmed = inputString.trim();
    if (trimmed.length < 2) {
      setSuggestions([]);
      return;
    }

    const { AutocompleteSessionToken, AutocompleteSuggestion } = placesLib;
    if (!sessionTokenRef.current) {
      sessionTokenRef.current = new AutocompleteSessionToken();
    }

    let cancelled = false;
    setLoading(true);
    const timer = window.setTimeout(() => {
      AutocompleteSuggestion.fetchAutocompleteSuggestions({
        input: trimmed,
        includedRegionCodes: ['us'],
        sessionToken: sessionTokenRef.current ?? undefined,
      })
        .then((res) => {
          if (!cancelled) {
            setSuggestions(res.suggestions ?? []);
          }
        })
        .catch((err) => {
          if (isQuotaError(err)) {
            window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
          }
          if (!cancelled) setSuggestions([]);
        })
        .finally(() => {
          if (!cancelled) setLoading(false);
        });
    }, 220);

    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [placesLib, inputString]);

  const resetSession = useCallback(() => {
    sessionTokenRef.current = null;
    setSuggestions([]);
  }, []);

  return { placesLib, suggestions, loading, resetSession };
}

const PlacesSearchBar: React.FC<{
  onPlaceChosen: (loc: SearchedLocation) => void;
  onClearLocation: () => void;
  activeSearchLabel: string | null;
}> = ({ onPlaceChosen, onClearLocation, activeSearchLabel }) => {
  const [inputValue, setInputValue] = useState('');
  const { placesLib, suggestions, loading, resetSession } = usePlaceAutocomplete(inputValue);

  const handleSelectSuggestion = async (
    suggestion: google.maps.places.AutocompleteSuggestion
  ) => {
    if (!placesLib || !suggestion.placePrediction) return;
    try {
      const place = suggestion.placePrediction.toPlace();
      await place.fetchFields({
        fields: ['displayName', 'formattedAddress', 'location', 'viewport'],
      });
      const loc = place.location;
      if (loc) {
        onPlaceChosen({
          label: place.formattedAddress || place.displayName || suggestion.placePrediction.text.text,
          lat: loc.lat(),
          lng: loc.lng(),
        });
      }
      setInputValue('');
      resetSession();
    } catch (err) {
      if (isQuotaError(err)) {
        window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
      }
    }
  };

  return (
    <div className="relative w-full max-w-md">
      <div className="relative flex items-center">
        <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 pointer-events-none" />
        <input
          type="text"
          aria-label="Search city, county, or address on Google Maps"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          placeholder="Search city, county, or street on Google Maps..."
          className="w-full pl-8 pr-8 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-sky-500"
        />
        {(inputValue || activeSearchLabel) && (
          <button
            type="button"
            aria-label="Clear map location search"
            onClick={() => {
              setInputValue('');
              resetSession();
              onClearLocation();
            }}
            className="absolute right-2 p-0.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {suggestions.length > 0 && (
        <ul className="absolute z-30 mt-1 w-full rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 shadow-lg max-h-56 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
          {suggestions.map((s, idx) => (
            <li key={s.placePrediction?.placeId ?? idx}>
              <button
                type="button"
                onClick={() => void handleSelectSuggestion(s)}
                className="w-full text-left px-3 py-2 text-xs text-slate-800 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-2"
              >
                <MapPin className="w-3.5 h-3.5 text-sky-600 shrink-0" />
                <span className="truncate">{s.placePrediction?.text.text}</span>
              </button>
            </li>
          ))}
        </ul>
      )}
      {loading && inputValue.trim().length >= 2 && (
        <div className="sr-only">Loading address suggestions...</div>
      )}
    </div>
  );
};

const MapCameraController: React.FC<{
  deals: CrmDeal[];
  selectedDealId: string | null;
  searchedLocation: SearchedLocation | null;
}> = ({ deals, selectedDealId, searchedLocation }) => {
  const map = useMap();
  const coreLib = useMapsLibrary('core');

  useEffect(() => {
    if (!map) return;
    if (searchedLocation) {
      map.panTo({ lat: searchedLocation.lat, lng: searchedLocation.lng });
      map.setZoom(11);
      return;
    }
    const selected = deals.find((d) => d.id === selectedDealId);
    if (selected && deals.length === 1) {
      map.panTo({ lat: selected.property.lat, lng: selected.property.lng });
      map.setZoom(12);
      return;
    }
    if (deals.length > 0 && coreLib) {
      const bounds = new coreLib.LatLngBounds();
      for (const d of deals) {
        bounds.extend({ lat: d.property.lat, lng: d.property.lng });
      }
      map.fitBounds(bounds, { top: 48, right: 48, bottom: 48, left: 48 });
    }
  }, [map, coreLib, deals, selectedDealId, searchedLocation]);

  return null;
};

const ParcelMarker: React.FC<{
  deal: CrmDeal;
  isSelected: boolean;
  isInfoOpen: boolean;
  onSelect: () => void;
  onCloseInfo: () => void;
  onOpenDossier: () => void;
  onOpenPropertyPage?: () => void;
}> = ({ deal, isSelected, isInfoOpen, onSelect, onCloseInfo, onOpenDossier, onOpenPropertyPage }) => {
  const [markerRef, marker] = useAdvancedMarkerRef();
  const equity = calculateEstimatedEquity(deal.property.assessedValue, deal.property.estimatedDebt);
  const bg = isSelected
    ? '#0284c7'
    : deal.probateCase.hasAttorney
      ? '#475569'
      : '#0f766e';
  const border = isSelected ? '#075985' : '#0f172a';

  return (
    <>
      <AdvancedMarker
        ref={markerRef}
        position={{ lat: deal.property.lat, lng: deal.property.lng }}
        onClick={onSelect}
        title={`${deal.property.address} — ${formatCurrency(equity)} eq`}
      >
        <Pin
          background={bg}
          borderColor={border}
          glyphColor="#ffffff"
          scale={isSelected ? 1.2 : 1.0}
        />
      </AdvancedMarker>

      {isInfoOpen && marker && (
        <InfoWindow anchor={marker} onCloseClick={onCloseInfo} maxWidth={310}>
          <div className="p-1.5 pr-2 text-slate-900 space-y-1.5 min-w-[220px]">
            <div className="font-semibold text-xs leading-snug">{deal.property.address}</div>
            <div className="text-[11px] text-slate-600">
              {deal.property.city}, {deal.property.stateCode} · {deal.property.countyName} County
            </div>
            <div className="flex items-center justify-between gap-2 pt-1 border-t border-slate-200 text-[11px]">
              <span className="font-mono text-slate-600 truncate">{deal.probateCase.caseNumber}</span>
              <span className="font-mono font-bold text-emerald-700 tabular-nums shrink-0">
                {formatCurrency(equity)} eq
              </span>
            </div>
            <div className="text-[11px] text-slate-600">
              {deal.probateCase.adminType} · {deal.probateCase.hasAttorney ? 'Attorney Listed' : 'Pro Se'}
            </div>
            <div className="flex items-center gap-1.5 mt-1">
              {onOpenPropertyPage && (
                <button
                  type="button"
                  onClick={onOpenPropertyPage}
                  className="flex-1 px-2.5 py-1.5 rounded bg-sky-600 hover:bg-sky-500 text-white text-[11px] font-semibold"
                >
                  Property 360°
                </button>
              )}
              <button
                type="button"
                onClick={onOpenDossier}
                className="flex-1 px-2.5 py-1.5 rounded bg-slate-900 hover:bg-slate-800 text-white text-[11px] font-semibold"
              >
                Dossier
              </button>
            </div>
          </div>
        </InfoWindow>
      )}
    </>
  );
};

export const GoogleParcelMap: React.FC<GoogleParcelMapProps> = ({
  apiKey,
  deals,
  selectedDealId,
  theme,
  onSelectDeal,
  onOpenDossier,
  onOpenPropertyPage,
  onLocationFilter,
}) => {
  const [openInfoId, setOpenInfoId] = useState<string | null>(selectedDealId);
  const [searchedLocation, setSearchedLocation] = useState<SearchedLocation | null>(null);

  useEffect(() => {
    if (selectedDealId) {
      setOpenInfoId(selectedDealId);
    }
  }, [selectedDealId]);

  if (!apiKey) {
    return (
      <section
        aria-label="Google Maps Probate Parcel Explorer"
        className="w-full h-[380px] rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-col items-center justify-center p-6 text-center"
        data-testid="google-parcel-map-fallback"
      >
        <MapPin className="w-7 h-7 text-sky-600 mb-2" />
        <h3 className="font-display text-sm font-bold text-slate-900 dark:text-slate-100">
          Google Maps Platform Parcel Layer
        </h3>
        <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 max-w-md">
          Configure <span className="font-mono">VITE_GOOGLE_MAPS_API_KEY</span> in your runtime secrets or environment to render live interactive Google Maps pins and Places address search.
        </p>
      </section>
    );
  }

  return (
    <section
      aria-label="Google Maps Probate Parcel Explorer"
      className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden"
      data-testid="google-parcel-map"
    >
      <APIProvider
        apiKey={apiKey}
        libraries={['marker', 'places', 'maps3d', 'streetView']}
        language="en"
        region="US"
      >
        {/* Top Toolbar with Google Places Autocomplete Search */}
        <div className="px-4 py-2.5 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs">
            <LocateFixed className="w-4 h-4 text-sky-600 dark:text-sky-400 shrink-0" />
            <span className="font-display font-semibold text-slate-900 dark:text-slate-100">
              Google Maps Parcel Explorer
            </span>
            <span className="text-slate-400" aria-hidden="true">·</span>
            <span className="text-slate-600 dark:text-slate-400 tabular-nums">
              {deals.length} geocoded estates
            </span>
          </div>

          <PlacesSearchBar
            activeSearchLabel={searchedLocation?.label ?? null}
            onPlaceChosen={(loc) => {
              setSearchedLocation(loc);
              const cityPart = loc.label.split(',')[0]?.trim();
              if (cityPart && onLocationFilter) {
                onLocationFilter(cityPart);
              }
            }}
            onClearLocation={() => {
              setSearchedLocation(null);
              if (onLocationFilter) onLocationFilter('');
            }}
          />
        </div>

        {/* Explicit Height Map Container (CF2) */}
        <div className="w-full h-[380px] relative">
          <GoogleMap
            mapId="DEMO_MAP_ID"
            defaultCenter={{ lat: 31.8, lng: -96.5 }}
            defaultZoom={4}
            gestureHandling="greedy"
            colorScheme={theme === 'dark' ? ColorScheme.DARK : ColorScheme.LIGHT}
            internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
            className="w-full h-full"
          >
            <MapCameraController
              deals={deals}
              selectedDealId={selectedDealId}
              searchedLocation={searchedLocation}
            />

            {searchedLocation && (
              <AdvancedMarker
                position={{ lat: searchedLocation.lat, lng: searchedLocation.lng }}
                title={searchedLocation.label}
              >
                <Pin background="#dc2626" borderColor="#7f1d1d" glyphColor="#ffffff" scale={1.1} />
              </AdvancedMarker>
            )}

            {deals.map((deal) => (
              <ParcelMarker
                key={deal.id}
                deal={deal}
                isSelected={deal.id === selectedDealId}
                isInfoOpen={openInfoId === deal.id}
                onSelect={() => {
                  onSelectDeal(deal.id);
                  setOpenInfoId(deal.id);
                }}
                onCloseInfo={() => setOpenInfoId(null)}
                onOpenDossier={() => onOpenDossier(deal.id)}
                onOpenPropertyPage={onOpenPropertyPage ? () => onOpenPropertyPage(deal.id) : undefined}
              />
            ))}
          </GoogleMap>
        </div>
      </APIProvider>
    </section>
  );
};
