import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import {
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  Box,
  Camera,
  Eye,
  Glasses,
  Hammer,
  Layers,
  RotateCcw,
  Scan,
  SunMedium,
} from 'lucide-react';
import type { CrmDeal, ThemeMode } from '../types/caselot';
import { calculateEstimatedEquity, formatCurrency } from '../utils/probateLogic';

interface SpatialPropertyTwin3DProps {
  deal: CrmDeal;
  rehabBudget: number;
  recommendedMao: number;
  lotSqft: number;
  theme: ThemeMode;
}

type SpatialMode = '3d-twin' | 'vr-walk' | 'ar-overlay';

const _fwd = new THREE.Vector3();
const _right = new THREE.Vector3();

function createParcelGroundTexture(isDark: boolean): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    ctx.fillStyle = isDark ? '#0e1726' : '#dfe7ef';
    ctx.fillRect(0, 0, 512, 512);

    ctx.strokeStyle = isDark ? 'rgba(148, 163, 184, 0.11)' : 'rgba(71, 85, 105, 0.14)';
    ctx.lineWidth = 1;
    for (let i = 0; i <= 512; i += 32) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, 512);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(0, i);
      ctx.lineTo(512, i);
      ctx.stroke();
    }
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(8, 8);
  return tex;
}

function createContactShadowTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    const grad = ctx.createRadialGradient(64, 64, 10, 64, 64, 62);
    grad.addColorStop(0, 'rgba(2, 6, 23, 0.45)');
    grad.addColorStop(0.6, 'rgba(2, 6, 23, 0.18)');
    grad.addColorStop(1, 'rgba(2, 6, 23, 0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 128, 128);
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function buildDetailedPropertyTwin(
  deal: CrmDeal,
  lotSqft: number,
  shadowTex: THREE.CanvasTexture
): {
  root: THREE.Group;
  roofGroup: THREE.Group;
  interiorGroup: THREE.Group;
  aduStageGroup: THREE.Group;
  boundaryGroup: THREE.Group;
} {
  const root = new THREE.Group();
  const roofGroup = new THREE.Group();
  const interiorGroup = new THREE.Group();
  const aduStageGroup = new THREE.Group();
  const boundaryGroup = new THREE.Group();

  const { property } = deal;
  const isLand = property.propertyType === 'Land / Lot';
  const isMulti = property.propertyType === 'Multi-Family';
  const isCommercial = property.propertyType === 'Commercial';

  const lotW = THREE.MathUtils.clamp(Math.sqrt(Math.max(4000, lotSqft)) * 0.12, 8.5, 14.5);
  const lotD = lotW * 1.15;

  // Materials
  const turfMat = new THREE.MeshStandardMaterial({
    color: 0x3b5e4c,
    roughness: 0.92,
    metalness: 0.02,
  });
  const concreteMat = new THREE.MeshStandardMaterial({
    color: 0x94a3b8,
    roughness: 0.85,
    metalness: 0.05,
  });
  const wallMat = new THREE.MeshStandardMaterial({
    color: isCommercial ? 0xdbeafe : 0xf1f5f9,
    roughness: 0.72,
    metalness: 0.08,
  });
  const trimMat = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    roughness: 0.3,
    metalness: 0.65,
  });
  const roofMat = new THREE.MeshStandardMaterial({
    color: isCommercial ? 0x0f172a : 0x334155,
    roughness: 0.48,
    metalness: 0.25,
  });
  const glassMat = new THREE.MeshStandardMaterial({
    color: 0x38bdf8,
    emissive: 0x0ea5e9,
    emissiveIntensity: 0.22,
    roughness: 0.12,
    metalness: 0.85,
  });
  const woodMat = new THREE.MeshStandardMaterial({
    color: 0x9a6b4c,
    roughness: 0.68,
    metalness: 0.05,
  });

  // Lot pad & contact shadow
  const lotSlab = new THREE.Mesh(new THREE.BoxGeometry(lotW, 0.08, lotD), turfMat);
  lotSlab.position.y = 0.04;
  lotSlab.receiveShadow = true;
  root.add(lotSlab);

  const shadowDisc = new THREE.Mesh(
    new THREE.CircleGeometry(lotW * 0.45, 32),
    new THREE.MeshBasicMaterial({
      map: shadowTex,
      transparent: true,
      depthWrite: false,
      opacity: 0.52,
    })
  );
  shadowDisc.rotation.x = -Math.PI / 2;
  shadowDisc.position.y = 0.09;
  root.add(shadowDisc);

  // Driveway & front walkway
  const driveway = new THREE.Mesh(
    new THREE.BoxGeometry(2.1, 0.03, lotD * 0.34),
    concreteMat
  );
  driveway.position.set(lotW * 0.24, 0.095, lotD * 0.32);
  driveway.receiveShadow = true;
  root.add(driveway);

  const walkway = new THREE.Mesh(
    new THREE.BoxGeometry(0.95, 0.03, lotD * 0.28),
    concreteMat
  );
  walkway.position.set(-0.6, 0.095, lotD * 0.35);
  walkway.receiveShadow = true;
  root.add(walkway);

  // Parcel survey perimeter line + corner boundary stakes
  const halfW = lotW / 2;
  const halfD = lotD / 2;
  const boundaryPts = [
    new THREE.Vector3(-halfW, 0.14, -halfD),
    new THREE.Vector3(halfW, 0.14, -halfD),
    new THREE.Vector3(halfW, 0.14, halfD),
    new THREE.Vector3(-halfW, 0.14, halfD),
    new THREE.Vector3(-halfW, 0.14, -halfD),
  ];
  const boundaryLine = new THREE.Line(
    new THREE.BufferGeometry().setFromPoints(boundaryPts),
    new THREE.LineBasicMaterial({ color: 0x38bdf8 })
  );
  boundaryGroup.add(boundaryLine);

  const stakeGeo = new THREE.CylinderGeometry(0.055, 0.055, 0.72, 10);
  const stakeMat = new THREE.MeshStandardMaterial({
    color: 0x0ea5e9,
    emissive: 0x0284c7,
    emissiveIntensity: 0.35,
    roughness: 0.3,
    metalness: 0.5,
  });
  const corners: [number, number][] = [
    [-halfW, -halfD],
    [halfW, -halfD],
    [halfW, halfD],
    [-halfW, halfD],
  ];
  for (const [cx, cz] of corners) {
    const stake = new THREE.Mesh(stakeGeo, stakeMat);
    stake.position.set(cx, 0.42, cz);
    stake.castShadow = true;
    boundaryGroup.add(stake);
  }
  root.add(boundaryGroup);

  if (isLand) {
    // Vacant lot survey monument + topo contour rings
    const monument = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.55, 1.1), concreteMat);
    monument.position.set(0, 0.35, 0);
    monument.castShadow = true;
    root.add(monument);

    const markerCap = new THREE.Mesh(
      new THREE.CylinderGeometry(0.32, 0.32, 0.2, 20),
      stakeMat
    );
    markerCap.position.set(0, 0.72, 0);
    root.add(markerCap);
  } else {
    // Architectural footprint scaled by living sqft
    const sqftScale = THREE.MathUtils.clamp(Math.sqrt((property.sqft || 2000) / 2000), 0.82, 1.38);
    const mainW = (isMulti ? 5.2 : 4.4) * sqftScale;
    const mainD = (isMulti ? 3.8 : 3.2) * sqftScale;
    const storyH = isMulti ? 3.2 : isCommercial ? 2.9 : 2.15;

    // Foundation slab
    const foundation = new THREE.Mesh(
      new THREE.BoxGeometry(mainW + 0.3, 0.22, mainD + 0.3),
      concreteMat
    );
    foundation.position.set(-0.4, 0.19, -0.35);
    foundation.receiveShadow = true;
    root.add(foundation);

    // Main exterior walls
    const mainBody = new THREE.Mesh(
      new THREE.BoxGeometry(mainW, storyH, mainD),
      wallMat
    );
    mainBody.position.set(-0.4, 0.3 + storyH / 2, -0.35);
    mainBody.castShadow = true;
    mainBody.receiveShadow = true;
    root.add(mainBody);

    // Secondary wing / attached garage
    const garageW = 2.2 * sqftScale;
    const garageD = 2.5 * sqftScale;
    const garageH = 1.85;
    const garage = new THREE.Mesh(
      new THREE.BoxGeometry(garageW, garageH, garageD),
      wallMat
    );
    garage.position.set(-0.4 + mainW / 2 + garageW / 2 - 0.1, 0.3 + garageH / 2, 0.15);
    garage.castShadow = true;
    garage.receiveShadow = true;
    root.add(garage);

    // Garage door recessed panel
    const garageDoor = new THREE.Mesh(
      new THREE.BoxGeometry(garageW * 0.72, 1.32, 0.08),
      trimMat
    );
    garageDoor.position.set(
      -0.4 + mainW / 2 + garageW / 2 - 0.1,
      0.98,
      0.15 + garageD / 2 + 0.01
    );
    root.add(garageDoor);

    // Front entry porch & door
    const porchDeck = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.16, 0.9), concreteMat);
    porchDeck.position.set(-0.6, 0.24, -0.35 + mainD / 2 + 0.45);
    root.add(porchDeck);

    const frontDoor = new THREE.Mesh(new THREE.BoxGeometry(0.68, 1.38, 0.08), woodMat);
    frontDoor.position.set(-0.6, 1.0, -0.35 + mainD / 2 + 0.02);
    root.add(frontDoor);

    // Glazed windows on front & sides
    const winGeo = new THREE.BoxGeometry(0.75, 0.72, 0.08);
    const windowOffsets = [-1.6, 0.55, 1.35];
    for (const wx of windowOffsets) {
      if (Math.abs(wx + 0.6) < 0.75) continue;
      const win = new THREE.Mesh(winGeo, glassMat);
      win.position.set(-0.4 + wx * 0.8, 1.35, -0.35 + mainD / 2 + 0.02);
      root.add(win);
    }
    const sideWin = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.72, 1.1), glassMat);
    sideWin.position.set(-0.4 - mainW / 2 - 0.02, 1.35, -0.35);
    root.add(sideWin);

    // Roof Group (lifted/hidden cleanly in Cutaway Mode)
    if (isCommercial) {
      const parapet = new THREE.Mesh(
        new THREE.BoxGeometry(mainW + 0.35, 0.32, mainD + 0.35),
        roofMat
      );
      parapet.position.set(-0.4, 0.3 + storyH + 0.16, -0.35);
      parapet.castShadow = true;
      roofGroup.add(parapet);
    } else {
      const mainRoof = new THREE.Mesh(
        new THREE.ConeGeometry(Math.max(mainW, mainD) * 0.76, 1.25, 4),
        roofMat
      );
      mainRoof.rotation.y = Math.PI / 4;
      mainRoof.position.set(-0.4, 0.3 + storyH + 0.62, -0.35);
      mainRoof.castShadow = true;
      roofGroup.add(mainRoof);

      const garageRoof = new THREE.Mesh(
        new THREE.ConeGeometry(Math.max(garageW, garageD) * 0.75, 0.82, 4),
        roofMat
      );
      garageRoof.rotation.y = Math.PI / 4;
      garageRoof.position.set(
        -0.4 + mainW / 2 + garageW / 2 - 0.1,
        0.3 + garageH + 0.41,
        0.15
      );
      garageRoof.castShadow = true;
      roofGroup.add(garageRoof);
    }
    root.add(roofGroup);

    // Interior Cutaway Floor-Plan Zoning Group (visible when Cutaway toggle enabled)
    const livingZone = new THREE.Mesh(
      new THREE.BoxGeometry(mainW * 0.46, 0.85, mainD * 0.44),
      new THREE.MeshStandardMaterial({ color: 0x0ea5e9, roughness: 0.45, transparent: true, opacity: 0.85 })
    );
    livingZone.position.set(-0.4 - mainW * 0.22, 0.82, -0.35 + mainD * 0.22);
    interiorGroup.add(livingZone);

    const kitchenZone = new THREE.Mesh(
      new THREE.BoxGeometry(mainW * 0.42, 0.85, mainD * 0.42),
      new THREE.MeshStandardMaterial({ color: 0x10b981, roughness: 0.45, transparent: true, opacity: 0.85 })
    );
    kitchenZone.position.set(-0.4 + mainW * 0.22, 0.82, -0.35 + mainD * 0.22);
    interiorGroup.add(kitchenZone);

    const suiteZone = new THREE.Mesh(
      new THREE.BoxGeometry(mainW * 0.88, 0.85, mainD * 0.4),
      new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.45, transparent: true, opacity: 0.85 })
    );
    suiteZone.position.set(-0.4, 0.82, -0.35 - mainD * 0.24);
    interiorGroup.add(suiteZone);

    interiorGroup.visible = false;
    root.add(interiorGroup);
  }

  // Stylized Landscaping Trees
  const trunkMat = new THREE.MeshStandardMaterial({ color: 0x5c4033, roughness: 0.9 });
  const leafMat = new THREE.MeshStandardMaterial({ color: 0x2f6f4e, roughness: 0.78 });
  const treeCoords: [number, number][] = [
    [-halfW + 1.15, halfD - 1.2],
    [halfW - 1.1, -halfD + 1.3],
  ];
  for (const [tx, tz] of treeCoords) {
    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.14, 0.9, 8), trunkMat);
    trunk.position.set(tx, 0.53, tz);
    trunk.castShadow = true;
    root.add(trunk);

    const crown = new THREE.Mesh(new THREE.DodecahedronGeometry(0.68, 1), leafMat);
    crown.position.set(tx, 1.32, tz);
    crown.castShadow = true;
    root.add(crown);
  }

  // AR Renovation / Backyard ADU Staging Volume (toggleable)
  const aduBody = new THREE.Mesh(
    new THREE.BoxGeometry(2.6, 1.65, 2.1),
    new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      emissive: 0x0284c7,
      emissiveIntensity: 0.3,
      transparent: true,
      opacity: 0.52,
      roughness: 0.25,
    })
  );
  aduBody.position.set(-halfW + 2.2, 0.92, -halfD + 2.1);
  aduStageGroup.add(aduBody);

  const aduWire = new THREE.LineSegments(
    new THREE.EdgesGeometry(new THREE.BoxGeometry(2.62, 1.67, 2.12)),
    new THREE.LineBasicMaterial({ color: 0x7dd3fc })
  );
  aduWire.position.copy(aduBody.position);
  aduStageGroup.add(aduWire);

  aduStageGroup.visible = false;
  root.add(aduStageGroup);

  return { root, roofGroup, interiorGroup, aduStageGroup, boundaryGroup };
}

export const SpatialPropertyTwin3D: React.FC<SpatialPropertyTwin3DProps> = ({
  deal,
  rehabBudget,
  recommendedMao,
  lotSqft,
  theme,
}) => {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  const [mode, setMode] = useState<SpatialMode>('3d-twin');
  const [cutaway, setCutaway] = useState(false);
  const [showAduStage, setShowAduStage] = useState(false);
  const [sunHour, setSunHour] = useState(14); // 2 PM default
  const [xrVrSupported, setXrVrSupported] = useState(false);
  const [xrArSupported, setXrArSupported] = useState(false);
  const [arCameraLive, setArCameraLive] = useState(false);
  const [arStatusNote, setArStatusNote] = useState<string | null>(null);

  const modeRef = useRef<SpatialMode>(mode);
  modeRef.current = mode;

  const themeRef = useRef<ThemeMode>(theme);
  themeRef.current = theme;

  const sceneApiRef = useRef<{
    rebuildModel: () => void;
    setCutaway: (enabled: boolean) => void;
    setAduStage: (enabled: boolean) => void;
    setSunHour: (hour: number) => void;
    applyMode: (next: SpatialMode) => void;
    applyTheme: (next: ThemeMode) => void;
    walkStep: (forward: number, strafe: number, turnYaw: number) => void;
    resetView: () => void;
    launchWebXr: (sessionType: 'immersive-vr' | 'immersive-ar') => Promise<void>;
  } | null>(null);

  // Probe WebXR hardware capabilities once
  useEffect(() => {
    const navXr = (navigator as unknown as { xr?: { isSessionSupported?: (mode: string) => Promise<boolean> } }).xr;
    if (!navXr?.isSessionSupported) return;
    navXr.isSessionSupported('immersive-vr').then((ok) => setXrVrSupported(Boolean(ok))).catch(() => {});
    navXr.isSessionSupported('immersive-ar').then((ok) => setXrArSupported(Boolean(ok))).catch(() => {});
  }, []);

  // Initialize Three.js WebGL Viewport
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const isSoftwareGl = (() => {
      const probe = document.createElement('canvas');
      const gl = probe.getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    const width = container.clientWidth || 920;
    const height = container.clientHeight || 420;

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      alpha: true,
      powerPreference: 'high-performance',
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.setSize(width, height);
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.xr.enabled = true;

    container.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    const camera = new THREE.PerspectiveCamera(44, width / height, 0.1, 140);
    camera.position.set(10.5, 7.6, 11.8);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.target.set(0, 1.2, 0);
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.08;
    controls.maxPolarAngle = Math.PI / 2 - 0.05;
    controls.minDistance = 3;
    controls.maxDistance = 30;

    const hemiLight = new THREE.HemisphereLight(0xe0f2fe, 0x334155, 0.88);
    scene.add(hemiLight);

    const sunLight = new THREE.DirectionalLight(0xfff5e4, 1.85);
    sunLight.position.set(9, 14, 8);
    sunLight.castShadow = !isSoftwareGl;
    sunLight.shadow.mapSize.set(1024, 1024);
    sunLight.shadow.camera.near = 1;
    sunLight.shadow.camera.far = 42;
    sunLight.shadow.camera.left = -12;
    sunLight.shadow.camera.right = 12;
    sunLight.shadow.camera.top = 12;
    sunLight.shadow.camera.bottom = -12;
    sunLight.shadow.bias = -0.0005;
    scene.add(sunLight);

    const rimLight = new THREE.DirectionalLight(0x7dd3fc, 0.55);
    rimLight.position.set(-10, 8, -10);
    scene.add(rimLight);

    let groundTex = createParcelGroundTexture(themeRef.current === 'dark');
    const groundMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      map: groundTex,
      roughness: 0.92,
      metalness: 0.02,
    });
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(75, 75), groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground);

    const shadowTex = createContactShadowTexture();
    const twinAnchor = new THREE.Group();
    scene.add(twinAnchor);

    let currentParts: ReturnType<typeof buildDetailedPropertyTwin> | null = null;
    let frameId = 0;
    let renderBusy = false;
    let renderDirty = false;
    let vrYaw = 0;
    let vrPitch = -0.04;
    const keysDown = new Set<string>();

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync ? gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0) : null;
      gl.flush();
      const poll = () => {
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (sync && state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    function requestRender() {
      if (renderBusy) {
        renderDirty = true;
        return;
      }
      renderBusy = true;
      frameId = requestAnimationFrame(() => {
        renderDirty = false;
        if (modeRef.current === 'vr-walk') {
          let moveF = 0;
          let moveS = 0;
          if (keysDown.has('KeyW') || keysDown.has('ArrowUp')) moveF += 0.16;
          if (keysDown.has('KeyS') || keysDown.has('ArrowDown')) moveF -= 0.16;
          if (keysDown.has('KeyA') || keysDown.has('ArrowLeft')) moveS -= 0.14;
          if (keysDown.has('KeyD') || keysDown.has('ArrowRight')) moveS += 0.14;
          if (moveF !== 0 || moveS !== 0) {
            sceneApiRef.current?.walkStep(moveF, moveS, 0);
          }
        } else {
          controls.update();
        }
        renderer.render(scene, camera);

        const done = () => {
          renderBusy = false;
          if (renderDirty || (modeRef.current === 'vr-walk' && keysDown.size > 0)) {
            requestRender();
          }
        };
        if (isSoftwareGl) afterDraw(done);
        else done();
      });
    }

    function disposeGroup(grp: THREE.Group) {
      grp.traverse((obj) => {
        if (obj instanceof THREE.Mesh || obj instanceof THREE.Line || obj instanceof THREE.LineSegments) {
          obj.geometry.dispose();
          if (Array.isArray(obj.material)) obj.material.forEach((m) => m.dispose());
          else obj.material.dispose();
        }
      });
    }

    function rebuildModel() {
      disposeGroup(twinAnchor);
      twinAnchor.clear();
      currentParts = buildDetailedPropertyTwin(deal, lotSqft, shadowTex);
      twinAnchor.add(currentParts.root);
      requestRender();
    }

    function applyTheme(next: ThemeMode) {
      if (modeRef.current === 'ar-overlay') {
        scene.background = null;
        scene.fog = null;
        ground.visible = false;
      } else {
        const bgHex = next === 'dark' ? 0x060b14 : 0xdbe4ef;
        scene.background = new THREE.Color(bgHex);
        scene.fog = new THREE.FogExp2(bgHex, 0.016);
        ground.visible = true;
        groundTex.dispose();
        groundTex = createParcelGroundTexture(next === 'dark');
        groundMat.map = groundTex;
        groundMat.needsUpdate = true;
      }
      requestRender();
    }

    function applyMode(next: SpatialMode) {
      if (next === 'vr-walk') {
        controls.enabled = false;
        vrYaw = 0;
        vrPitch = -0.02;
        camera.position.set(-0.6, 1.65, 8.2);
        camera.lookAt(-0.6, 1.55, 0);
      } else if (next === 'ar-overlay') {
        controls.enabled = true;
        camera.position.set(0.4, 2.3, 10.6);
        controls.target.set(0, 1.3, 0);
      } else {
        controls.enabled = true;
        camera.position.set(10.5, 7.6, 11.8);
        controls.target.set(0, 1.2, 0);
      }
      applyTheme(themeRef.current);
      requestRender();
    }

    function walkStep(forward: number, strafe: number, turnYaw: number) {
      vrYaw += turnYaw;
      _fwd.set(-Math.sin(vrYaw), 0, -Math.cos(vrYaw)).normalize();
      _right.set(Math.cos(vrYaw), 0, -Math.sin(vrYaw)).normalize();
      camera.position.addScaledVector(_fwd, forward);
      camera.position.addScaledVector(_right, strafe);
      camera.position.x = THREE.MathUtils.clamp(camera.position.x, -11, 11);
      camera.position.z = THREE.MathUtils.clamp(camera.position.z, -11, 12);
      camera.position.y = 1.65;

      const lookTarget = new THREE.Vector3(
        camera.position.x + _fwd.x * 4,
        1.65 + Math.sin(vrPitch) * 2.5,
        camera.position.z + _fwd.z * 4
      );
      camera.lookAt(lookTarget);
      requestRender();
    }

    sceneApiRef.current = {
      rebuildModel,
      setCutaway: (enabled: boolean) => {
        if (!currentParts) return;
        currentParts.roofGroup.visible = !enabled;
        currentParts.interiorGroup.visible = enabled;
        requestRender();
      },
      setAduStage: (enabled: boolean) => {
        if (!currentParts) return;
        currentParts.aduStageGroup.visible = enabled;
        requestRender();
      },
      setSunHour: (hour: number) => {
        const t = THREE.MathUtils.clamp((hour - 6) / 14, 0, 1);
        const angle = t * Math.PI;
        sunLight.position.set(Math.cos(angle) * 16, Math.max(3, Math.sin(angle) * 18), 8);
        sunLight.intensity = 1.1 + Math.sin(angle) * 0.95;
        requestRender();
      },
      applyMode,
      applyTheme,
      walkStep,
      resetView: () => applyMode(modeRef.current),
      launchWebXr: async (sessionType) => {
        const navXr = (navigator as unknown as {
          xr?: { requestSession: (m: string, opts?: Record<string, unknown>) => Promise<XRSession> };
        }).xr;
        if (!navXr) return;
        const session = await navXr.requestSession(sessionType, {
          optionalFeatures: ['local-floor', 'bounded-floor'],
        });
        await renderer.xr.setSession(session);
        renderer.setAnimationLoop(() => {
          renderer.render(scene, camera);
        });
        session.addEventListener('end', () => {
          renderer.setAnimationLoop(null);
          requestRender();
        });
      },
    };

    // Pointer look-around in VR walkthrough mode
    let draggingVr = false;
    let lastX = 0;
    let lastY = 0;
    const onPointerDown = (e: PointerEvent) => {
      if (modeRef.current !== 'vr-walk') return;
      draggingVr = true;
      lastX = e.clientX;
      lastY = e.clientY;
    };
    const onPointerMove = (e: PointerEvent) => {
      if (!draggingVr || modeRef.current !== 'vr-walk') return;
      const dx = e.clientX - lastX;
      const dy = e.clientY - lastY;
      lastX = e.clientX;
      lastY = e.clientY;
      vrYaw -= dx * 0.0055;
      vrPitch = THREE.MathUtils.clamp(vrPitch - dy * 0.004, -0.45, 0.5);
      walkStep(0, 0, 0);
    };
    const onPointerUp = () => {
      draggingVr = false;
    };
    const onKeyDown = (e: KeyboardEvent) => {
      if (modeRef.current !== 'vr-walk') return;
      if (['KeyW', 'KeyA', 'KeyS', 'KeyD', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) {
        keysDown.add(e.code);
        requestRender();
      }
    };
    const onKeyUp = (e: KeyboardEvent) => {
      keysDown.delete(e.code);
    };

    const onControlChange = () => requestRender();
    controls.addEventListener('change', onControlChange);
    renderer.domElement.addEventListener('pointerdown', onPointerDown);
    window.addEventListener('pointermove', onPointerMove);
    window.addEventListener('pointerup', onPointerUp);
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);

    const onResize = () => {
      if (!container) return;
      const w = container.clientWidth || 920;
      const h = container.clientHeight || 420;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
      requestRender();
    };
    window.addEventListener('resize', onResize);

    rebuildModel();
    applyTheme(themeRef.current);
    if (!isSoftwareGl) renderer.compile(scene, camera);
    requestRender();

    return () => {
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      window.removeEventListener('resize', onResize);
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('pointerup', onPointerUp);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      controls.removeEventListener('change', onControlChange);
      renderer.domElement.removeEventListener('pointerdown', onPointerDown);
      disposeGroup(twinAnchor);
      groundTex.dispose();
      shadowTex.dispose();
      groundMat.dispose();
      controls.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [deal.id, lotSqft]);

  useEffect(() => {
    sceneApiRef.current?.setCutaway(cutaway);
  }, [cutaway]);

  useEffect(() => {
    sceneApiRef.current?.setAduStage(showAduStage);
  }, [showAduStage]);

  useEffect(() => {
    sceneApiRef.current?.setSunHour(sunHour);
  }, [sunHour]);

  useEffect(() => {
    sceneApiRef.current?.applyTheme(theme);
  }, [theme]);

  useEffect(() => {
    sceneApiRef.current?.applyMode(mode);

    let activeStream: MediaStream | null = null;
    if (mode === 'ar-overlay') {
      if (navigator.mediaDevices?.getUserMedia) {
        navigator.mediaDevices
          .getUserMedia({ video: { facingMode: 'environment' }, audio: false })
          .then((stream) => {
            activeStream = stream;
            if (videoRef.current) {
              videoRef.current.srcObject = stream;
              videoRef.current.play().catch(() => {});
            }
            setArCameraLive(true);
            setArStatusNote('Live Camera AR HUD active — drag to align parcel boundary & ADU footprint.');
          })
          .catch(() => {
            setArCameraLive(false);
            setArStatusNote(
              'AR Street-Site Horizon Simulation active (grant camera access on mobile/tablet for live site pass-through).'
            );
          });
      } else {
        setArCameraLive(false);
        setArStatusNote('AR Street-Site Horizon Simulation active.');
      }
    } else {
      setArCameraLive(false);
      setArStatusNote(null);
    }

    return () => {
      if (activeStream) {
        activeStream.getTracks().forEach((t) => t.stop());
      }
    };
  }, [mode]);

  const equity = calculateEstimatedEquity(deal.property.assessedValue, deal.property.estimatedDebt);
  const aduValueLift = showAduStage ? 65000 : 0;

  return (
    <section
      aria-label="3D Architectural Digital Twin, AR & VR Spatial Studio"
      className="bento-card overflow-hidden"
      data-testid="spatial-property-twin-3d"
    >
      {/* Top Bar */}
      <div className="px-4 py-3 border-b border-slate-200/80 dark:border-white/[0.08] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 min-w-0">
          <Box className="w-4 h-4 text-sky-500 shrink-0" />
          <span className="font-display text-sm font-bold text-slate-900 dark:text-white truncate">
            3D Digital Twin · AR & VR Spatial Lab
          </span>
          <span className="hidden sm:inline text-slate-400">·</span>
          <span className="hidden sm:inline font-mono text-[11px] text-slate-500 dark:text-slate-400 tabular-nums">
            {deal.property.sqft.toLocaleString()} sf · {lotSqft.toLocaleString()} sf lot
          </span>
        </div>

        {/* Mode Switcher */}
        <div
          role="group"
          aria-label="Spatial visualization mode"
          className="inline-flex rounded-lg border border-slate-200 dark:border-white/10 bg-slate-100 dark:bg-[#070B14] p-0.5 text-xs"
        >
          <button
            type="button"
            onClick={() => setMode('3d-twin')}
            className={`px-2.5 py-1.5 rounded-md font-semibold flex items-center gap-1.5 whitespace-nowrap transition-colors ${
              mode === '3d-twin'
                ? 'bg-slate-900 dark:bg-sky-600 text-white'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            3D Twin
          </button>
          <button
            type="button"
            onClick={() => setMode('vr-walk')}
            className={`px-2.5 py-1.5 rounded-md font-semibold flex items-center gap-1.5 whitespace-nowrap transition-colors ${
              mode === 'vr-walk'
                ? 'bg-slate-900 dark:bg-sky-600 text-white'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Glasses className="w-3.5 h-3.5" />
            VR Walkthrough
          </button>
          <button
            type="button"
            onClick={() => setMode('ar-overlay')}
            className={`px-2.5 py-1.5 rounded-md font-semibold flex items-center gap-1.5 whitespace-nowrap transition-colors ${
              mode === 'ar-overlay'
                ? 'bg-slate-900 dark:bg-sky-600 text-white'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Scan className="w-3.5 h-3.5" />
            AR Site Overlay
          </button>
        </div>
      </div>

      {/* Viewport */}
      <div className="relative w-full h-[380px] sm:h-[430px] overflow-hidden bg-slate-950">
        {/* Live Camera Video or Simulated Street-Site Horizon Backdrop for AR Mode */}
        {mode === 'ar-overlay' && (
          <>
            <video
              ref={videoRef}
              playsInline
              muted
              className={`absolute inset-0 w-full h-full object-cover ${arCameraLive ? 'opacity-100' : 'opacity-0'}`}
            />
            {!arCameraLive && (
              <div
                aria-hidden="true"
                className="absolute inset-0"
                style={{
                  background:
                    'linear-gradient(180deg, #0b1628 0%, #1c3049 48%, #26313d 52%, #111827 100%)',
                }}
              />
            )}
          </>
        )}

        <div ref={mountRef} className="relative z-10 w-full h-full" />

        {/* Top-Left Spatial Telemetry HUD (No backdrop-blur over WebGL) */}
        <div className="pointer-events-none absolute top-3 left-3 z-20 flex flex-col gap-2 max-w-[300px]">
          <div className="bg-slate-950/92 text-white px-3 py-2 rounded-lg border border-white/15 text-xs space-y-1">
            <div className="flex items-center justify-between gap-3">
              <span className="font-semibold text-sky-300">
                {mode === 'vr-walk'
                  ? 'VR First-Person Tour'
                  : mode === 'ar-overlay'
                    ? 'AR Parcel Boundary HUD'
                    : '3D Parcel Digital Twin'}
              </span>
              <span className="font-mono text-emerald-400 font-bold tabular-nums">
                {formatCurrency(equity + aduValueLift)} eq
              </span>
            </div>
            <div className="text-[11px] text-slate-300 flex items-center justify-between gap-2 tabular-nums">
              <span>MAO {formatCurrency(recommendedMao)}</span>
              <span>·</span>
              <span>Rehab {formatCurrency(rehabBudget)}</span>
            </div>
            {showAduStage && (
              <div className="text-[11px] text-sky-300 font-medium pt-0.5 border-t border-white/10">
                ADU / Rehab Massing Active (+$65k ARV lift est.)
              </div>
            )}
          </div>

          {arStatusNote && (
            <div className="bg-slate-950/92 text-slate-200 px-3 py-1.5 rounded-lg border border-sky-500/35 text-[11px] flex items-center gap-1.5">
              <Camera className="w-3.5 h-3.5 text-sky-400 shrink-0" />
              <span>{arStatusNote}</span>
            </div>
          )}
        </div>

        {/* Bottom Controls Bar */}
        <div className="absolute bottom-3 left-3 right-3 z-20 flex flex-wrap items-center justify-between gap-2 pointer-events-none">
          <div className="pointer-events-auto flex flex-wrap items-center gap-1.5 bg-slate-950/92 border border-white/15 rounded-lg p-1.5 text-xs">
            <button
              type="button"
              onClick={() => setCutaway((v) => !v)}
              className={`px-2.5 py-1.5 rounded-md font-semibold flex items-center gap-1.5 whitespace-nowrap transition-colors ${
                cutaway ? 'bg-sky-600 text-white' : 'bg-slate-800 text-slate-200 hover:bg-slate-700'
              }`}
            >
              <Eye className="w-3.5 h-3.5" />
              {cutaway ? 'Restore Roof' : 'Floor Cutaway'}
            </button>

            <button
              type="button"
              onClick={() => setShowAduStage((v) => !v)}
              className={`px-2.5 py-1.5 rounded-md font-semibold flex items-center gap-1.5 whitespace-nowrap transition-colors ${
                showAduStage ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-200 hover:bg-slate-700'
              }`}
            >
              <Hammer className="w-3.5 h-3.5" />
              {showAduStage ? 'Hide ADU Stage' : 'AR ADU Stage'}
            </button>

            <div className="hidden md:flex items-center gap-2 px-2 py-1 rounded-md bg-slate-900 border border-white/10 text-[11px] text-slate-300">
              <SunMedium className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <label htmlFor="twin-sun-hour" className="whitespace-nowrap">
                Sun {sunHour}:00
              </label>
              <input
                id="twin-sun-hour"
                type="range"
                min={7}
                max={19}
                step={1}
                value={sunHour}
                onChange={(e) => setSunHour(Number(e.target.value))}
                className="w-20 accent-amber-400"
              />
            </div>

            <button
              type="button"
              onClick={() => sceneApiRef.current?.resetView()}
              aria-label="Reset 3D spatial view"
              className="p-1.5 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-200"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* VR Walkthrough Directional Controls or WebXR Launch */}
          <div className="pointer-events-auto flex items-center gap-1.5">
            {mode === 'vr-walk' && (
              <div className="flex items-center gap-1 bg-slate-950/92 border border-white/15 rounded-lg p-1 text-slate-200">
                <button
                  type="button"
                  aria-label="Turn left in VR"
                  onClick={() => sceneApiRef.current?.walkStep(0, 0, 0.22)}
                  className="p-1.5 rounded bg-slate-800 hover:bg-slate-700"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  aria-label="Walk forward in VR"
                  onClick={() => sceneApiRef.current?.walkStep(0.85, 0, 0)}
                  className="p-1.5 rounded bg-sky-600 hover:bg-sky-500 text-white"
                >
                  <ArrowUp className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  aria-label="Walk backward in VR"
                  onClick={() => sceneApiRef.current?.walkStep(-0.85, 0, 0)}
                  className="p-1.5 rounded bg-slate-800 hover:bg-slate-700"
                >
                  <ArrowDown className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  aria-label="Turn right in VR"
                  onClick={() => sceneApiRef.current?.walkStep(0, 0, -0.22)}
                  className="p-1.5 rounded bg-slate-800 hover:bg-slate-700"
                >
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {mode === 'vr-walk' && xrVrSupported && (
              <button
                type="button"
                onClick={() => void sceneApiRef.current?.launchWebXr('immersive-vr')}
                className="px-3 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap"
              >
                <Glasses className="w-3.5 h-3.5" />
                Enter WebXR VR
              </button>
            )}

            {mode === 'ar-overlay' && xrArSupported && (
              <button
                type="button"
                onClick={() => void sceneApiRef.current?.launchWebXr('immersive-ar')}
                className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap"
              >
                <Scan className="w-3.5 h-3.5" />
                Launch WebXR AR
              </button>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
