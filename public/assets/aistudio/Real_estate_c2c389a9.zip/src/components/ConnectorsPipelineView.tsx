import React, { useState } from 'react';
import {
  CheckCircle2,
  Cpu,
  Database,
  Download,
  Loader2,
  Lock,
  Play,
  Plug,
  Plus,
  Send,
  Terminal,
  Trash2,
} from 'lucide-react';
import type {
  CrmDeal,
  IntegrationCategory,
  PlanTier,
  ThirdPartyIntegration,
} from '../types/caselot';
import type { TexasConnectorRunResult } from '../connectors/texasOdysseyConnector';
import {
  SAMPLE_TYLER_ODYSSEY_HTML,
  runTexasOdysseyPipeline,
} from '../connectors/texasOdysseyConnector';
import { calculateEstimatedEquity, formatCurrency } from '../utils/probateLogic';

interface ConnectorsPipelineViewProps {
  planTier: PlanTier;
  onRequireUpgrade: (featureName: string) => void;
  onImportTexasDeals: (deals: CrmDeal[]) => void;
  onJumpToDiscover: () => void;
  integrations: ThirdPartyIntegration[];
  onToggleIntegration: (id: string) => void;
  onUpdateIntegration: (id: string, patch: Partial<ThirdPartyIntegration>) => void;
  onAddIntegration: (integration: ThirdPartyIntegration) => void;
  onDeleteIntegration: (id: string) => void;
}

const DOCKER_COMPOSE_SNIPPET = `services:
  ollama:
    image: ollama/ollama:latest
    ports: ["11434:11434"]
    volumes: ["ollama_weights:/root/.ollama"]
  worker:
    image: python:3.11-slim
    environment:
      - OLLAMA_HOST=http://ollama:11434
    command: python extract_docket.py --sample --backend ollama --model gemma4`;

export const ConnectorsPipelineView: React.FC<ConnectorsPipelineViewProps> = ({
  planTier,
  onRequireUpgrade,
  onImportTexasDeals,
  onJumpToDiscover,
  integrations,
  onToggleIntegration,
  onUpdateIntegration,
  onAddIntegration,
  onDeleteIntegration,
}) => {
  const [activeTab, setActiveTab] = useState<'texas' | 'ai-worker' | 'integrations'>('texas');
  const [countyFilter, setCountyFilter] = useState<'ALL' | 'Harris' | 'Travis'>('ALL');
  const [rawFeed, setRawFeed] = useState(SAMPLE_TYLER_ODYSSEY_HTML);
  const [syncing, setSyncing] = useState(false);
  const [syncResult, setSyncResult] = useState<TexasConnectorRunResult | null>(() =>
    runTexasOdysseyPipeline(SAMPLE_TYLER_ODYSSEY_HTML, 'ALL')
  );
  const [importedNotice, setImportedNotice] = useState<string | null>(null);

  // Self-hosted AI Pipeline config state
  const [backend, setBackend] = useState<'ollama' | 'vllm'>('ollama');
  const [modelTag, setModelTag] = useState<'gemma4' | 'qwen3:14b' | 'mistral-small'>('gemma4');
  const [ocrParser, setOcrParser] = useState<'docling' | 'mineru'>('docling');

  // 3rd-party integration testing & custom webhook creation
  const [testingId, setTestingId] = useState<string | null>(null);
  const [testResults, setTestResults] = useState<
    Record<string, { ok: boolean; status: number; latencyMs: number; message: string }>
  >({});
  const [newName, setNewName] = useState('');
  const [newCategory, setNewCategory] = useState<IntegrationCategory>('Automation Webhook');
  const [newEndpoint, setNewEndpoint] = useState('');
  const [newAuthHeader, setNewAuthHeader] = useState('Authorization');
  const [newToken, setNewToken] = useState('');
  const [newEvents, setNewEvents] = useState<string[]>(['deal.imported', 'stage.changed']);

  const AVAILABLE_EVENTS = [
    'deal.imported',
    'property.viewed',
    'stage.changed',
    'pdf.generated',
    'docket.extracted',
  ];

  const handleToggleEvent = (evt: string) => {
    setNewEvents((prev) =>
      prev.includes(evt) ? prev.filter((item) => item !== evt) : [...prev, evt]
    );
  };

  const handleAddCustomIntegration = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newEndpoint.trim()) return;
    const item: ThirdPartyIntegration = {
      id: `int-custom-${Date.now()}`,
      name: newName.trim(),
      category: newCategory,
      description: `Custom ${newCategory} REST / webhook connection configured for real-time probate events.`,
      endpointUrl: newEndpoint.trim(),
      authHeaderName: newAuthHeader.trim() || 'Authorization',
      apiKeyMasked: newToken.trim() || 'Bearer configured_secret',
      enabled: true,
      events: newEvents.length > 0 ? newEvents : ['deal.imported'],
      isCustom: true,
      lastStatus: 'Added · Ready to test',
    };
    onAddIntegration(item);
    setNewName('');
    setNewEndpoint('');
    setNewToken('');
  };

  const handleTestWebhook = async (integration: ThirdPartyIntegration) => {
    setTestingId(integration.id);
    try {
      const res = await fetch('/api/integrations/test-webhook', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: integration.name,
          endpointUrl: integration.endpointUrl,
          authHeaderName: integration.authHeaderName,
          apiKeyMasked: integration.apiKeyMasked,
        }),
      });
      const data = await res.json();
      const statusMsg = data.ok
        ? `HTTP ${data.status} OK (${data.latencyMs}ms)`
        : data.error || `HTTP ${data.status} Failed`;

      setTestResults((prev) => ({
        ...prev,
        [integration.id]: {
          ok: Boolean(data.ok),
          status: Number(data.status) || res.status,
          latencyMs: Number(data.latencyMs) || 0,
          message: statusMsg,
        },
      }));
      onUpdateIntegration(integration.id, {
        lastTestedAt: new Date().toISOString().slice(11, 19),
        lastStatus: statusMsg,
      });
    } catch {
      setTestResults((prev) => ({
        ...prev,
        [integration.id]: {
          ok: false,
          status: 500,
          latencyMs: 0,
          message: 'Network request failed while reaching proxy.',
        },
      }));
    } finally {
      setTestingId(null);
    }
  };

  const handleRunTexasSync = async () => {
    setSyncing(true);
    setImportedNotice(null);
    try {
      const res = await fetch('/api/connectors/texas-odyssey/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rawFeed, countyFilter }),
      });
      if (!res.ok) throw new Error('Sync failed');
      const data = (await res.json()) as TexasConnectorRunResult;
      setSyncResult(data);
    } catch {
      setSyncResult(runTexasOdysseyPipeline(rawFeed, countyFilter));
    } finally {
      setSyncing(false);
    }
  };

  const handleImportAll = () => {
    if (!syncResult || syncResult.deals.length === 0) return;
    onImportTexasDeals(syncResult.deals);
    setImportedNotice(
      `Imported ${syncResult.deals.length} Texas assessor-matched estates into Discover & Google Maps.`
    );
  };

  const handleDownloadWorkerFile = () => {
    if (planTier === 'free') {
      onRequireUpgrade('Self-Hosted Ollama + Docling Worker Bundle');
      return;
    }
    const blob = new Blob([DOCKER_COMPOSE_SNIPPET], { type: 'text/yaml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'caselot-ollama-docling-compose.yml';
    a.click();
    URL.revokeObjectURL(url);
  };

  const cliCommand = `python pipeline/extract_docket.py --input ./docket.pdf --backend ${backend} --model ${modelTag} # OCR via ${ocrParser}`;

  return (
    <div className="space-y-5">
      <div className="flex flex-col xl:flex-row xl:items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
            Court Connectors & Self-Hosted AI Worker
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
            Ingest Texas Tyler Odyssey dockets, cross-match tax rolls, and connect 3rd-party webhooks or Ollama.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab('texas')}
            className={`px-3 py-2 rounded-lg text-xs font-semibold border transition-colors whitespace-nowrap ${
              activeTab === 'texas'
                ? 'bg-slate-900 dark:bg-sky-600 text-white border-slate-900 dark:border-sky-600'
                : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-300 dark:border-slate-700'
            }`}
          >
            TX Odyssey Connector
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('ai-worker')}
            className={`px-3 py-2 rounded-lg text-xs font-semibold border transition-colors whitespace-nowrap ${
              activeTab === 'ai-worker'
                ? 'bg-slate-900 dark:bg-sky-600 text-white border-slate-900 dark:border-sky-600'
                : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-300 dark:border-slate-700'
            }`}
          >
            Self-Hosted AI (Ollama)
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('integrations')}
            className={`px-3 py-2 rounded-lg text-xs font-semibold border transition-colors whitespace-nowrap inline-flex items-center gap-1.5 ${
              activeTab === 'integrations'
                ? 'bg-slate-900 dark:bg-sky-600 text-white border-slate-900 dark:border-sky-600'
                : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-300 dark:border-slate-700'
            }`}
          >
            <Plug className="w-3.5 h-3.5" />
            3rd-Party Apps & Webhooks ({integrations.filter((i) => i.enabled).length})
          </button>
        </div>
      </div>

      {activeTab === 'texas' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Left 5 cols: Tyler Odyssey Feed Payload & County Selector */}
          <div className="lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-3.5">
            <div className="flex items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Database className="w-4 h-4 text-sky-600 dark:text-sky-400" />
                <h2 className="font-display text-sm font-bold text-slate-900 dark:text-white">
                  Tyler Odyssey Court Feed (TX)
                </h2>
              </div>
              <select
                aria-label="Filter Texas county connector"
                value={countyFilter}
                onChange={(e) => setCountyFilter(e.target.value as 'ALL' | 'Harris' | 'Travis')}
                className="px-2.5 py-1 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-medium text-slate-900 dark:text-slate-100"
              >
                <option value="ALL">Harris & Travis (TX)</option>
                <option value="Harris">Harris County (HCAD)</option>
                <option value="Travis">Travis County (TCAD)</option>
              </select>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-400">
              Supports Tyler Odyssey HTML docket tables, JSON exports, or pipe/CSV court feeds. Extracts decedent, PR, attorney, and matches against Texas county appraisal districts.
            </p>

            <label htmlFor="texas-odyssey-feed" className="sr-only">
              Tyler Odyssey Raw Feed
            </label>
            <textarea
              id="texas-odyssey-feed"
              rows={11}
              value={rawFeed}
              onChange={(e) => setRawFeed(e.target.value)}
              className="w-full p-3 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-[11px] text-slate-900 dark:text-slate-100 leading-relaxed"
            />

            <div className="flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={() => setRawFeed(SAMPLE_TYLER_ODYSSEY_HTML)}
                className="px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-300"
              >
                Reset Sample HTML
              </button>
              <button
                type="button"
                onClick={handleRunTexasSync}
                disabled={syncing}
                className="px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 disabled:opacity-60 text-white text-xs font-semibold flex items-center gap-1.5"
              >
                {syncing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
                Run Connector & Cross-Reference
              </button>
            </div>
          </div>

          {/* Right 7 cols: Cross-Referenced Assessor Matches */}
          <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <h2 className="font-display text-sm font-bold text-slate-900 dark:text-white">
                  Assessor Roll Cross-Reference Results
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 tabular-nums">
                  {syncResult
                    ? `${syncResult.parsedDocketsCount} dockets parsed · ${syncResult.matchedPropertiesCount} real estate parcels matched`
                    : 'Run connector to match parcels'}
                </p>
              </div>

              {syncResult && syncResult.deals.length > 0 && (
                <button
                  type="button"
                  onClick={handleImportAll}
                  className="px-3.5 py-2 rounded-lg bg-slate-900 dark:bg-emerald-600 hover:bg-slate-800 dark:hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Import {syncResult.deals.length} Matched Estates
                </button>
              )}
            </div>

            {importedNotice && (
              <div className="p-3 rounded-lg bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-900 dark:text-emerald-200 flex items-center justify-between gap-3">
                <span>{importedNotice}</span>
                <button
                  type="button"
                  onClick={onJumpToDiscover}
                  className="font-semibold underline underline-offset-2 shrink-0"
                >
                  View on Map & Feed
                </button>
              </div>
            )}

            <div className="space-y-3">
              {syncResult?.matches.map((match) => {
                const { docket, parcel, matchConfidence, matchMethod } = match;
                const equity = parcel
                  ? calculateEstimatedEquity(parcel.assessedValue, parcel.estimatedDebt)
                  : 0;

                return (
                  <div
                    key={docket.caseNumber}
                    className="p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 space-y-2 text-xs"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <span className="font-semibold text-slate-900 dark:text-white">
                          Estate of {docket.decedentName}
                        </span>
                        <span className="text-slate-400 mx-1.5">·</span>
                        <span className="font-mono text-slate-600 dark:text-slate-400">
                          {docket.caseNumber}
                        </span>
                      </div>
                      <span className="font-mono font-semibold text-emerald-700 dark:text-emerald-400 tabular-nums">
                        {matchConfidence}% Match
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] text-slate-600 dark:text-slate-400">
                      <div>
                        <strong className="text-slate-800 dark:text-slate-200">Court:</strong> {docket.courtName} ({docket.adminType})
                      </div>
                      <div>
                        <strong className="text-slate-800 dark:text-slate-200">PR / Counsel:</strong> {docket.personalRepresentative} · {docket.attorney}
                      </div>
                    </div>

                    {parcel ? (
                      <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">
                        <div>
                          <div className="font-semibold text-slate-900 dark:text-slate-100">
                            {parcel.situsAddress}, {parcel.city}, TX {parcel.zip}
                          </div>
                          <div className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">
                            {parcel.parcelId} · {matchMethod}
                          </div>
                        </div>
                        <div className="text-right font-mono tabular-nums">
                          <div className="font-bold text-emerald-700 dark:text-emerald-400">
                            {formatCurrency(equity)} eq
                          </div>
                          <div className="text-[11px] text-slate-500 dark:text-slate-400">
                            Assessed {formatCurrency(parcel.assessedValue)}
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="text-[11px] text-amber-700 dark:text-amber-400">
                        {matchMethod}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      ) : activeTab === 'ai-worker' ? (
        /* Tab 2: Self-Hosted Local AI Worker Configuration */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          <div className="lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
              <Cpu className="w-4 h-4 text-sky-600 dark:text-sky-400" />
              <h2 className="font-display text-sm font-bold text-slate-900 dark:text-white">
                Local Open-Weight Extraction Config
              </h2>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label htmlFor="worker-backend" className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                  Inference Runtime (Zero Per-Token Fees)
                </label>
                <select
                  id="worker-backend"
                  value={backend}
                  onChange={(e) => setBackend(e.target.value as 'ollama' | 'vllm')}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                >
                  <option value="ollama">Ollama (Local CPU/GPU Daemon)</option>
                  <option value="vllm">vLLM + Outlines (CFG-Constrained JSON)</option>
                </select>
              </div>

              <div>
                <label htmlFor="worker-model" className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                  Open-Weight Model
                </label>
                <select
                  id="worker-model"
                  value={modelTag}
                  onChange={(e) => setModelTag(e.target.value as 'gemma4' | 'qwen3:14b' | 'mistral-small')}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                >
                  <option value="gemma4">Gemma 4 (gemma4)</option>
                  <option value="qwen3:14b">Qwen 3 14B (qwen3:14b)</option>
                  <option value="mistral-small">Mistral Small 24B (Apache 2.0)</option>
                </select>
              </div>

              <div>
                <label htmlFor="worker-ocr" className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                  Scanned Court PDF OCR Parser
                </label>
                <select
                  id="worker-ocr"
                  value={ocrParser}
                  onChange={(e) => setOcrParser(e.target.value as 'docling' | 'mineru')}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                >
                  <option value="docling">Docling (Layout-Preserved Markdown + Tables)</option>
                  <option value="mineru">MinerU (High-Density Multi-Column OCR)</option>
                </select>
              </div>
            </div>

            <button
              type="button"
              onClick={handleDownloadWorkerFile}
              className="w-full py-2.5 px-4 rounded-lg bg-slate-900 dark:bg-sky-600 hover:bg-slate-800 dark:hover:bg-sky-500 text-white text-xs font-semibold flex items-center justify-center gap-2"
            >
              {planTier === 'free' ? <Lock className="w-3.5 h-3.5" /> : <Download className="w-3.5 h-3.5" />}
              {planTier === 'free'
                ? 'Download Docker Worker Bundle (Pro/Enterprise)'
                : 'Download docker-compose.yml'}
            </button>
          </div>

          <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-sky-600 dark:text-sky-400 shrink-0" />
                <h2 className="font-display text-sm font-bold text-slate-900 dark:text-white">
                  Pydantic + Outlines Extraction Blueprint (/pipeline)
                </h2>
              </div>
              <span className="font-mono text-[11px] text-slate-500 dark:text-slate-400">
                pipeline/extract_docket.py
              </span>
            </div>

            <div className="p-3 rounded-lg bg-slate-950 text-sky-300 font-mono text-xs overflow-x-auto">
              {cliCommand}
            </div>

            <div className="space-y-2 text-xs">
              <div className="font-semibold text-slate-900 dark:text-slate-100">
                Enforced Pydantic v2 Output Schema
              </div>
              <pre className="p-3.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 font-mono text-[11px] text-slate-800 dark:text-slate-300 overflow-x-auto leading-relaxed">
{`class ProbateDocketExtraction(BaseModel):
    decedent_name: str
    date_of_death: str
    case_number: str
    case_type: str
    admin_type: Literal["Independent", "Dependent / Supervised", "Informal", "Summary"]
    executor_name: str
    executor_address: str
    probate_attorney: str
    property_addresses: list[ProbatePropertyItem]
    estimated_debt_or_liens: int
    probate_stage: str`}
              </pre>
            </div>
          </div>
        </div>
      ) : (
        /* Tab 3: Universal 3rd-Party Apps & Custom Webhooks */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Left 7 cols: Connected Apps Catalog + Live Webhook Tester */}
          <div className="lg:col-span-7 space-y-3">
            {integrations.map((item) => {
              const testRes = testResults[item.id];
              return (
                <div
                  key={item.id}
                  className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 space-y-3"
                >
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <h3 className="font-display text-sm font-bold text-slate-900 dark:text-white">
                          {item.name}
                        </h3>
                        <span className="text-[11px] font-medium text-sky-700 dark:text-sky-400">
                          {item.category}
                        </span>
                      </div>
                      <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                        {item.description}
                      </p>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => onToggleIntegration(item.id)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
                          item.enabled
                            ? 'bg-emerald-700 hover:bg-emerald-600 text-white'
                            : 'border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                        }`}
                      >
                        {item.enabled ? 'Connected' : 'Enable'}
                      </button>

                      {item.isCustom && (
                        <button
                          type="button"
                          aria-label={`Remove ${item.name}`}
                          onClick={() => onDeleteIntegration(item.id)}
                          className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-800 text-slate-400 hover:text-rose-600"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                    <div>
                      <label className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                        Endpoint / Webhook URL
                      </label>
                      <input
                        type="url"
                        value={item.endpointUrl}
                        onChange={(e) =>
                          onUpdateIntegration(item.id, { endpointUrl: e.target.value })
                        }
                        className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-[11px] text-slate-900 dark:text-slate-100"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                        Auth Header ({item.authHeaderName})
                      </label>
                      <input
                        type="text"
                        value={item.apiKeyMasked}
                        onChange={(e) =>
                          onUpdateIntegration(item.id, { apiKeyMasked: e.target.value })
                        }
                        className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-[11px] text-slate-900 dark:text-slate-100"
                      />
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100 dark:border-slate-800 text-[11px]">
                    <div className="text-slate-500 dark:text-slate-400">
                      Events: <span className="font-mono text-slate-700 dark:text-slate-300">{item.events.join(', ')}</span>
                    </div>

                    <div className="flex items-center gap-2">
                      {(testRes?.message || item.lastStatus) && (
                        <span
                          className={`font-mono ${
                            testRes
                              ? testRes.ok
                                ? 'text-emerald-700 dark:text-emerald-400'
                                : 'text-rose-600 dark:text-rose-400'
                              : 'text-slate-500 dark:text-slate-400'
                          }`}
                        >
                          {testRes ? testRes.message : item.lastStatus}
                        </span>
                      )}
                      <button
                        type="button"
                        disabled={testingId === item.id}
                        onClick={() => void handleTestWebhook(item)}
                        className="px-2.5 py-1 rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-semibold inline-flex items-center gap-1 whitespace-nowrap"
                      >
                        {testingId === item.id ? (
                          <Loader2 className="w-3 h-3 animate-spin" />
                        ) : (
                          <Send className="w-3 h-3" />
                        )}
                        Test Webhook
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Right 5 cols: Connect Any Custom 3rd-Party App Form */}
          <div className="lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 h-fit space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
              <Plus className="w-4 h-4 text-sky-600 dark:text-sky-400" />
              <h2 className="font-display text-sm font-bold text-slate-900 dark:text-white">
                Connect Any 3rd-Party App or Tool
              </h2>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-400">
              Register any external CRM (HubSpot, Salesforce, Podio, Follow Up Boss), Zapier/Make hook, Slack channel, or custom valuation API.
            </p>

            <form onSubmit={handleAddCustomIntegration} className="space-y-3 text-xs">
              <div>
                <label htmlFor="custom-int-name" className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                  App / Tool Name
                </label>
                <input
                  id="custom-int-name"
                  type="text"
                  required
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="e.g., HubSpot Probate Sync or Slack Alerts"
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                />
              </div>

              <div>
                <label htmlFor="custom-int-cat" className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                  Category
                </label>
                <select
                  id="custom-int-cat"
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value as IntegrationCategory)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                >
                  <option value="Automation Webhook">Automation Webhook (Zapier / Make / n8n)</option>
                  <option value="CRM Sync">CRM Sync (HubSpot / Salesforce / Podio)</option>
                  <option value="Valuation & MLS">Valuation & MLS (Zillow / Redfin / ATTOM)</option>
                  <option value="Skip Trace">Skip Trace (BatchLeads / TLOxp)</option>
                  <option value="Direct Mail">Direct Mail (Lob / YellowLetterHQ)</option>
                  <option value="eSignature">eSignature (DocuSign / PandaDoc)</option>
                </select>
              </div>

              <div>
                <label htmlFor="custom-int-url" className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                  REST Endpoint / Webhook URL
                </label>
                <input
                  id="custom-int-url"
                  type="url"
                  required
                  value={newEndpoint}
                  onChange={(e) => setNewEndpoint(e.target.value)}
                  placeholder="https://hooks.zapier.com/hooks/catch/..."
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 font-mono text-[11px] text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label htmlFor="custom-int-header" className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                    Auth Header Name
                  </label>
                  <input
                    id="custom-int-header"
                    type="text"
                    value={newAuthHeader}
                    onChange={(e) => setNewAuthHeader(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 font-mono text-[11px] text-slate-900 dark:text-slate-100"
                  />
                </div>
                <div>
                  <label htmlFor="custom-int-token" className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                    API Key / Bearer Token
                  </label>
                  <input
                    id="custom-int-token"
                    type="password"
                    value={newToken}
                    onChange={(e) => setNewToken(e.target.value)}
                    placeholder="Optional secret token"
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 font-mono text-[11px] text-slate-900 dark:text-slate-100"
                  />
                </div>
              </div>

              <div>
                <div className="text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1.5">
                  Trigger Events
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {AVAILABLE_EVENTS.map((evt) => {
                    const active = newEvents.includes(evt);
                    return (
                      <button
                        key={evt}
                        type="button"
                        onClick={() => handleToggleEvent(evt)}
                        className={`px-2 py-1 rounded border font-mono text-[11px] transition-colors ${
                          active
                            ? 'bg-slate-900 dark:bg-sky-600 text-white border-slate-900 dark:border-sky-600'
                            : 'bg-slate-50 dark:bg-slate-950 text-slate-600 dark:text-slate-400 border-slate-300 dark:border-slate-700'
                        }`}
                      >
                        {evt}
                      </button>
                    );
                  })}
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 px-4 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5"
              >
                <Plus className="w-3.5 h-3.5" />
                Connect App / Webhook
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
