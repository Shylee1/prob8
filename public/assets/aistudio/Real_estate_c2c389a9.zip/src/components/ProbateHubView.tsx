import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  Calculator,
  CheckSquare,
  ExternalLink,
  Gavel,
  Loader2,
  Scale,
  Send,
  ShieldCheck,
  Square,
} from 'lucide-react';
import type { CrmDeal, Jurisdiction } from '../types/caselot';
import { formatCurrency } from '../utils/probateLogic';
import { calculateCurrentProbatePricing } from '../utils/valuationAndIntegrations';
import {
  US_STATE_PROBATE_RULES,
  calculateMinimumOverbidPrice,
  evaluateFederalCompliance,
  getStateProbateStatute,
} from '../utils/usRegulations';

interface ProbateHubViewProps {
  jurisdictions: Jurisdiction[];
  activeDeal: CrmDeal | null;
  selectedJurisdictionId: string;
  onSelectJurisdiction: (id: string) => void;
  selectedStateCode: string;
  onSelectStateCode: (code: string) => void;
  onToggleChecklist: (dealId: string, itemLabel: string) => void;
}

export const ProbateHubView: React.FC<ProbateHubViewProps> = ({
  jurisdictions,
  activeDeal,
  selectedJurisdictionId,
  onSelectJurisdiction,
  selectedStateCode,
  onSelectStateCode,
  onToggleChecklist,
}) => {
  const jurisdiction =
    jurisdictions.find((j) => j.id === selectedJurisdictionId) ?? jurisdictions[0];

  const stateStatute = useMemo(
    () => getStateProbateStatute(selectedStateCode || jurisdiction.stateCode),
    [selectedStateCode, jurisdiction.stateCode]
  );

  const [question, setQuestion] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const [aiAnswer, setAiAnswer] = useState<string | null>(null);
  const [calcValue, setCalcValue] = useState<number>(
    activeDeal?.property.assessedValue ?? 410000
  );
  const [calcDebt, setCalcDebt] = useState<number>(
    activeDeal?.property.estimatedDebt ?? 45000
  );

  // Overbid simulator input
  const [acceptedCourtOffer, setAcceptedCourtOffer] = useState<number>(
    activeDeal?.offerAmount || 340000
  );

  // Interactive Federal Compliance Gate state
  const [sellerIsForeign, setSellerIsForeign] = useState(false);
  const [buyerPrimaryResidence, setBuyerPrimaryResidence] = useState(false);
  const [wholesaleAssignment, setWholesaleAssignment] = useState(false);
  const [outreachChannel, setOutreachChannel] = useState<
    'Direct Mail' | 'Manual Call' | 'Automated SMS / Dialer'
  >('Direct Mail');
  const [hasPewc, setHasPewc] = useState(false);

  const probatePricing = calculateCurrentProbatePricing(
    jurisdiction.id,
    calcValue,
    calcDebt
  );

  const overbidCalculation = useMemo(
    () => calculateMinimumOverbidPrice(acceptedCourtOffer, stateStatute.overbidFormula),
    [acceptedCourtOffer, stateStatute.overbidFormula]
  );

  const federalReport = useMemo(
    () =>
      evaluateFederalCompliance({
        offerAmount: acceptedCourtOffer,
        propertyType: activeDeal?.property.propertyType ?? 'Single-Family',
        sellerIsForeignEstateOrHeir: sellerIsForeign,
        buyerIntendsPrimaryResidence: buyerPrimaryResidence,
        wholesaleAssignmentPlanned: wholesaleAssignment,
        outreachChannel,
        hasPriorExpressWrittenConsent: hasPewc,
      }),
    [
      acceptedCourtOffer,
      activeDeal?.property.propertyType,
      sellerIsForeign,
      buyerPrimaryResidence,
      wholesaleAssignment,
      outreachChannel,
      hasPewc,
    ]
  );

  const checklistState = activeDeal?.checklistCompleted ?? {};
  const completedCount = jurisdiction.checklistTemplates.filter(
    (item) => checklistState[item]
  ).length;

  const handleAskRule = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim()) return;
    setAiLoading(true);
    try {
      const res = await fetch('/api/ai/explain-rule', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: question.trim(),
          countyName: jurisdiction.countyName,
          stateCode: stateStatute.stateCode,
          rulesContext: `${stateStatute.stateName} (${stateStatute.upcAdopted}): ${stateStatute.courtConfirmationRule} Creditor period: ${stateStatute.creditorClaimWindow}. Local County: ${jurisdiction.rules.adminTypesSummary}`,
        }),
      });
      const data = await res.json();
      setAiAnswer(data.answer || 'No explanation returned.');
    } catch {
      setAiAnswer(
        `In ${stateStatute.stateName} (${jurisdiction.countyName} County): ${stateStatute.courtConfirmationRule}`
      );
    } finally {
      setAiLoading(false);
    }
  };

  return (
    <div className="space-y-5">
      {/* Header & Dual Selectors: All 50 US States + County Playbooks */}
      <div className="flex flex-col xl:flex-row xl:items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
            US Probate & Federal Compliance Hub
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
            All 50 US states + DC statutory probate rules, Federal FIRPTA/RESPA/TCPA compliance checks, and local county playbooks.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2">
            <label
              htmlFor="hub-us-state"
              className="text-xs font-medium text-slate-600 dark:text-slate-400 whitespace-nowrap"
            >
              US State Statute:
            </label>
            <select
              id="hub-us-state"
              value={stateStatute.stateCode}
              onChange={(e) => {
                const code = e.target.value;
                onSelectStateCode(code);
                const matchingCounty = jurisdictions.find((j) => j.stateCode === code);
                if (matchingCounty) onSelectJurisdiction(matchingCounty.id);
              }}
              className="px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700/80 bg-white dark:bg-[#0E1525] text-xs font-semibold text-slate-900 dark:text-slate-100"
            >
              {US_STATE_PROBATE_RULES.map((s) => (
                <option key={s.stateCode} value={s.stateCode}>
                  {s.stateName} ({s.stateCode}) — {s.upcAdopted}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-2">
            <label
              htmlFor="hub-jurisdiction"
              className="text-xs font-medium text-slate-600 dark:text-slate-400 whitespace-nowrap"
            >
              County Playbook:
            </label>
            <select
              id="hub-jurisdiction"
              value={jurisdiction.id}
              onChange={(e) => {
                const nextId = e.target.value;
                onSelectJurisdiction(nextId);
                const j = jurisdictions.find((item) => item.id === nextId);
                if (j) onSelectStateCode(j.stateCode);
                setAiAnswer(null);
              }}
              className="px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700/80 bg-white dark:bg-[#0E1525] text-xs font-semibold text-slate-900 dark:text-slate-100"
            >
              {jurisdictions.map((j) => (
                <option key={j.id} value={j.id}>
                  {j.countyName} County, {j.stateCode}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Active UPL Informational Notice */}
      <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/70 rounded-2xl px-4 py-3 flex items-start gap-3 text-xs text-amber-950 dark:text-amber-200">
        <AlertTriangle className="w-4 h-4 text-amber-700 dark:text-amber-400 shrink-0 mt-0.5" />
        <div>
          <span className="font-semibold">Informational Workflow Tool Only — Not Legal Advice: </span>
          State statutes and county procedures summarized below are operational guidance. Confirm
          fiduciary authority, homestead exemptions, and federal tax withholdings with a licensed{' '}
          {stateStatute.stateName} probate attorney and US title company.
        </div>
      </div>

      {/* US 50-State Statutory Matrix + Court Overbid Calculator */}
      <section className="bento-card p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Gavel className="w-4 h-4 text-sky-600 dark:text-sky-400" />
            <h2 className="font-display text-base font-bold text-slate-900 dark:text-white">
              {stateStatute.stateName} ({stateStatute.stateCode}) Statewide Probate Real Property Statute
            </h2>
          </div>
          <span className="text-[11px] font-mono text-sky-700 dark:text-sky-400 font-semibold">
            {stateStatute.upcAdopted} · TOD Deed: {stateStatute.transferOnDeathDeed ? 'Recognized' : 'Not Statutory'}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
          <div className="bento-inset p-3.5 space-y-1">
            <div className="text-[11px] text-slate-500 dark:text-slate-400">Independent Sale Authority</div>
            <div className="font-semibold text-slate-900 dark:text-white">
              {stateStatute.independentAuthority}
            </div>
            <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed pt-1">
              {stateStatute.courtConfirmationRule}
            </p>
          </div>

          <div className="bento-inset p-3.5 space-y-1">
            <div className="text-[11px] text-slate-500 dark:text-slate-400">Creditor Claim Window</div>
            <div className="font-mono font-semibold text-slate-900 dark:text-white">
              {stateStatute.creditorClaimWindow}
            </div>
            <div className="text-[11px] text-slate-600 dark:text-slate-300 pt-1">
              Typical Timeline: <strong>{stateStatute.typicalTimelineMonths}</strong>
            </div>
          </div>

          <div className="bento-inset p-3.5 space-y-1">
            <div className="text-[11px] text-slate-500 dark:text-slate-400">Homestead & Spousal Rules</div>
            <p className="text-[11px] text-slate-700 dark:text-slate-300 leading-relaxed">
              {stateStatute.homesteadAndSpousalNote}
            </p>
          </div>

          <div className="bento-inset p-3.5 space-y-1">
            <div className="text-[11px] text-slate-500 dark:text-slate-400">Attorney Representation Rule</div>
            <p className="text-[11px] text-slate-700 dark:text-slate-300 leading-relaxed">
              {stateStatute.attorneyRule}
            </p>
          </div>
        </div>

        {/* Statutory Overbid Calculator */}
        <div className="bento-inset p-4 flex flex-col lg:flex-row lg:items-center justify-between gap-4 text-xs">
          <div className="space-y-1 max-w-xl">
            <div className="font-semibold text-slate-900 dark:text-white">
              Statutory Court Confirmation & Overbid Calculator ({stateStatute.stateCode})
            </div>
            <p className="text-[11px] text-slate-600 dark:text-slate-400 leading-relaxed">
              {overbidCalculation.formulaSummary}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <div>
              <label
                htmlFor="overbid-offer-input"
                className="block text-[11px] text-slate-500 dark:text-slate-400 mb-1"
              >
                Accepted Contract Offer ($)
              </label>
              <input
                id="overbid-offer-input"
                type="number"
                min={0}
                step={5000}
                value={acceptedCourtOffer}
                onChange={(e) => setAcceptedCourtOffer(Math.max(0, Number(e.target.value)))}
                className="w-36 px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 font-mono text-xs text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400 mb-1">
                Required Increment
              </div>
              <div className="font-mono font-bold text-amber-700 dark:text-amber-400 text-sm tabular-nums">
                +{formatCurrency(overbidCalculation.requiredIncrement)}
              </div>
            </div>
            <div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400 mb-1">
                Minimum Next Overbid
              </div>
              <div className="font-mono font-bold text-sky-700 dark:text-sky-400 text-sm tabular-nums">
                {formatCurrency(overbidCalculation.minimumNextBid)}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Interactive Federal Real Estate & Probate Compliance Gate (FIRPTA, RESPA, TCPA, Fair Housing) */}
      <section className="bento-card p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <h2 className="font-display text-base font-bold text-slate-900 dark:text-white">
              Federal US Probate Acquisition Compliance Gate
            </h2>
          </div>
          <span className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
            IRS FIRPTA · CFPB RESPA · FCC TCPA · Fair Housing Act
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
          <label className="bento-inset p-3 flex items-start gap-2.5 cursor-pointer">
            <input
              type="checkbox"
              checked={sellerIsForeign}
              onChange={(e) => setSellerIsForeign(e.target.checked)}
              className="mt-0.5 accent-sky-600"
            />
            <div>
              <div className="font-semibold text-slate-900 dark:text-white">Foreign Estate / Heir</div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400">
                Triggers 26 U.S.C. § 1445 FIRPTA
              </div>
            </div>
          </label>

          <label className="bento-inset p-3 flex items-start gap-2.5 cursor-pointer">
            <input
              type="checkbox"
              checked={buyerPrimaryResidence}
              onChange={(e) => setBuyerPrimaryResidence(e.target.checked)}
              className="mt-0.5 accent-sky-600"
            />
            <div>
              <div className="font-semibold text-slate-900 dark:text-white">Primary Residence Buyer</div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400">
                Affects FIRPTA 0% / 10% tier
              </div>
            </div>
          </label>

          <label className="bento-inset p-3 flex items-start gap-2.5 cursor-pointer">
            <input
              type="checkbox"
              checked={wholesaleAssignment}
              onChange={(e) => setWholesaleAssignment(e.target.checked)}
              className="mt-0.5 accent-sky-600"
            />
            <div>
              <div className="font-semibold text-slate-900 dark:text-white">Wholesale Assignment</div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400">
                Audits RESPA §8 & disclosure
              </div>
            </div>
          </label>

          <div className="bento-inset p-3 space-y-1.5">
            <label htmlFor="hub-outreach-channel" className="block font-semibold text-slate-900 dark:text-white">
              Outreach Channel
            </label>
            <select
              id="hub-outreach-channel"
              value={outreachChannel}
              onChange={(e) =>
                setOutreachChannel(
                  e.target.value as 'Direct Mail' | 'Manual Call' | 'Automated SMS / Dialer'
                )
              }
              className="w-full px-2 py-1 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-[11px] text-slate-900 dark:text-white"
            >
              <option value="Direct Mail">Direct Mail (USPS)</option>
              <option value="Manual Call">Manual Call (DNC Scrub)</option>
              <option value="Automated SMS / Dialer">Automated SMS / Dialer</option>
            </select>
            {outreachChannel === 'Automated SMS / Dialer' && (
              <label className="flex items-center gap-1.5 text-[11px] text-slate-600 dark:text-slate-300 cursor-pointer pt-0.5">
                <input
                  type="checkbox"
                  checked={hasPewc}
                  onChange={(e) => setHasPewc(e.target.checked)}
                  className="accent-sky-600"
                />
                PEWC Written Consent Logged
              </label>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
          {federalReport.checks.map((chk) => (
            <div key={chk.id} className="bento-inset p-3.5 space-y-1.5">
              <div className="flex items-center justify-between gap-2">
                <span className="font-semibold text-slate-900 dark:text-white">
                  {chk.statute}
                </span>
                <span
                  className={`text-[11px] font-semibold ${
                    chk.severity === 'warning'
                      ? 'text-rose-600 dark:text-rose-400'
                      : chk.severity === 'caution'
                        ? 'text-amber-600 dark:text-amber-400'
                        : 'text-emerald-700 dark:text-emerald-400'
                  }`}
                >
                  {chk.status}
                </span>
              </div>
              <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
                {chk.summary}
              </p>
              <p className="text-[11px] font-medium text-slate-800 dark:text-slate-200">
                Required Action: {chk.requiredAction}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Main 2-Column County Playbook Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left 7 cols: County Rules Snapshot + Plain-English AI Guide + Pricing */}
        <div className="lg:col-span-7 space-y-5">
          <section className="bento-card p-5 space-y-4">
            <div className="flex items-start justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <h2 className="font-display text-base font-bold text-slate-900 dark:text-white">
                  {jurisdiction.countyName} County, {jurisdiction.stateName} — Local Playbook
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  {jurisdiction.courtSystemType} · {jurisdiction.scrapingAdapter}
                </p>
              </div>
              <Scale className="w-5 h-5 text-slate-400 shrink-0" />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="bento-inset p-3.5">
                <div className="font-semibold text-slate-900 dark:text-white">
                  Court Confirmation / Overbid
                </div>
                <div className="text-slate-700 dark:text-slate-300 mt-1 leading-relaxed">
                  {jurisdiction.rules.courtConfirmationRequired
                    ? 'Required for Restricted / Supervised Estates'
                    : 'Not Required under Independent Authority'}
                </div>
                <p className="text-slate-500 dark:text-slate-400 mt-1.5 leading-relaxed">
                  {jurisdiction.rules.overbidProcess}
                </p>
              </div>

              <div className="bento-inset p-3.5">
                <div className="font-semibold text-slate-900 dark:text-white">
                  Timeline & Creditor Window
                </div>
                <div className="font-mono text-slate-800 dark:text-slate-200 mt-1 font-medium">
                  {jurisdiction.rules.typicalTimeline}
                </div>
                <p className="text-slate-500 dark:text-slate-400 mt-1.5 leading-relaxed">
                  {jurisdiction.rules.creditorClaimPeriod}
                </p>
              </div>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <h3 className="font-semibold text-slate-900 dark:text-white">
                  Administration Framework
                </h3>
                <p className="text-slate-700 dark:text-slate-300 mt-1 leading-relaxed">
                  {jurisdiction.rules.adminTypesSummary}
                </p>
              </div>
              <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
                <h3 className="font-semibold text-slate-900 dark:text-white">
                  Homestead & Title Underwriting Note
                </h3>
                <p className="text-slate-700 dark:text-slate-300 mt-1 leading-relaxed">
                  {jurisdiction.rules.homesteadNote}
                </p>
              </div>
            </div>
          </section>

          {/* Plain-English AI Probate Guide */}
          <section className="bento-card p-5 space-y-3">
            <h2 className="font-display text-sm font-bold text-slate-900 dark:text-white">
              Plain-English Local Procedure Guide
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Ask an operational workflow question about {stateStatute.stateName} or{' '}
              {jurisdiction.countyName} County probate sales (e.g. &ldquo;How does the creditor
              period affect closing?&rdquo;).
            </p>

            <form onSubmit={handleAskRule} className="flex gap-2">
              <input
                type="text"
                aria-label="Ask local probate workflow question"
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder={`Ask about ${stateStatute.stateCode} / ${jurisdiction.countyName} Letters, overbids, or title clearance...`}
                className="flex-1 px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
              />
              <button
                type="submit"
                disabled={aiLoading}
                className="px-3.5 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 disabled:opacity-60 text-white text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap"
              >
                {aiLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                Ask Guide
              </button>
            </form>

            {aiAnswer && (
              <div className="bento-inset p-3.5 text-xs text-slate-800 dark:text-slate-200 leading-relaxed">
                {aiAnswer}
              </div>
            )}
          </section>

          {/* 2026 Current Probate Court & Statutory Fee Pricing Calculator */}
          <section className="bento-card p-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Calculator className="w-4 h-4 text-sky-600 dark:text-sky-400" />
                <h2 className="font-display text-sm font-bold text-slate-900 dark:text-white">
                  2026 Current Probate Pricing & Fee Schedule
                </h2>
              </div>
              <span className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                {jurisdiction.countyName} County, {jurisdiction.stateCode}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <div className="flex justify-between mb-1">
                  <label htmlFor="hub-estate-value" className="font-medium text-slate-700 dark:text-slate-300">
                    Estate Property Value
                  </label>
                  <span className="font-mono font-semibold text-slate-900 dark:text-white tabular-nums">
                    {formatCurrency(calcValue)}
                  </span>
                </div>
                <input
                  id="hub-estate-value"
                  type="range"
                  min={100000}
                  max={1500000}
                  step={10000}
                  value={calcValue}
                  onChange={(e) => setCalcValue(Number(e.target.value))}
                  className="w-full accent-sky-600"
                />
              </div>
              <div>
                <label htmlFor="hub-estate-debt" className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Outstanding Mortgage / Liens ($)
                </label>
                <input
                  id="hub-estate-debt"
                  type="number"
                  min={0}
                  step={5000}
                  value={calcDebt}
                  onChange={(e) => setCalcDebt(Math.max(0, Number(e.target.value)))}
                  className="w-full px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 font-mono text-xs text-slate-900 dark:text-slate-100"
                />
              </div>
            </div>

            <div className="text-[11px] text-slate-500 dark:text-slate-400">
              <strong className="text-slate-700 dark:text-slate-300">Basis:</strong>{' '}
              {probatePricing.statutoryBasis} · {probatePricing.attorneyFeeModel}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-xs">
              <div className="bento-inset p-2.5">
                <div className="text-[11px] text-slate-500 dark:text-slate-400">Clerk Filing Fee</div>
                <div className="font-mono font-semibold text-slate-900 dark:text-white mt-0.5 tabular-nums">
                  {formatCurrency(probatePricing.filingFee)}
                </div>
              </div>
              <div className="bento-inset p-2.5">
                <div className="text-[11px] text-slate-500 dark:text-slate-400">Notice & Bond</div>
                <div className="font-mono font-semibold text-slate-900 dark:text-white mt-0.5 tabular-nums">
                  {formatCurrency(
                    probatePricing.publicationNoticeFee + probatePricing.bondAndAppraisalFee
                  )}
                </div>
              </div>
              <div className="bento-inset p-2.5">
                <div className="text-[11px] text-slate-500 dark:text-slate-400">Attorney Fee Est.</div>
                <div className="font-mono font-semibold text-slate-900 dark:text-white mt-0.5 tabular-nums">
                  {formatCurrency(probatePricing.attorneyFeeEstimate)}
                </div>
              </div>
              <div className="bento-inset p-2.5">
                <div className="text-[11px] text-slate-500 dark:text-slate-400">Executor Fee Est.</div>
                <div className="font-mono font-semibold text-slate-900 dark:text-white mt-0.5 tabular-nums">
                  {formatCurrency(probatePricing.executorFeeEstimate)}
                </div>
              </div>
              <div className="bento-inset p-2.5">
                <div className="text-[11px] text-slate-500 dark:text-slate-400">6-Mo Carry Cost</div>
                <div className="font-mono font-semibold text-slate-900 dark:text-white mt-0.5 tabular-nums">
                  {formatCurrency(probatePricing.sixMonthHoldingCost)}
                </div>
              </div>
              <div className="p-2.5 rounded-xl bg-rose-50/70 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-800">
                <div className="text-[11px] text-rose-700 dark:text-rose-300">Total Probate Carry</div>
                <div className="font-mono font-bold text-rose-700 dark:text-rose-400 mt-0.5 tabular-nums">
                  {formatCurrency(probatePricing.totalProbateCarryCost)}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1 text-xs">
              <div className="bento-inset p-3 flex items-center justify-between">
                <div>
                  <div className="font-semibold text-slate-900 dark:text-white">Traditional Listing Net</div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400">7.5% agent/close + full carry</div>
                </div>
                <span className="font-mono font-bold text-slate-900 dark:text-white tabular-nums">
                  {formatCurrency(probatePricing.traditionalNetProceeds)}
                </span>
              </div>
              <div className="p-3 rounded-xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 flex items-center justify-between">
                <div>
                  <div className="font-semibold text-emerald-900 dark:text-emerald-200">As-Is Cash Close Net</div>
                  <div className="text-[11px] text-emerald-700 dark:text-emerald-400">0% commission · 21d close</div>
                </div>
                <span className="font-mono font-bold text-emerald-700 dark:text-emerald-400 tabular-nums">
                  {formatCurrency(probatePricing.fastCashNetProceeds)}
                </span>
              </div>
            </div>
          </section>
        </div>

        {/* Right 5 cols: Interactive Checklist + Official Directory */}
        <div className="lg:col-span-5 space-y-5">
          <section className="bento-card p-5 space-y-3">
            <div className="flex items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <h2 className="font-display text-sm font-bold text-slate-900 dark:text-white">
                  Transaction Readiness Checklist
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 truncate">
                  {activeDeal
                    ? `${activeDeal.property.address} (${activeDeal.probateCase.caseNumber})`
                    : `${jurisdiction.countyName} County Standard Workflow`}
                </p>
              </div>
              <span className="font-mono text-xs font-semibold text-slate-700 dark:text-slate-300 tabular-nums shrink-0">
                {completedCount}/{jurisdiction.checklistTemplates.length}
              </span>
            </div>

            <div className="space-y-2">
              {jurisdiction.checklistTemplates.map((item) => {
                const checked = Boolean(checklistState[item]);
                return (
                  <button
                    key={item}
                    type="button"
                    disabled={!activeDeal}
                    onClick={() => activeDeal && onToggleChecklist(activeDeal.id, item)}
                    className={`w-full text-left p-2.5 rounded-xl border text-xs flex items-start gap-2.5 transition-colors ${
                      checked
                        ? 'bg-emerald-50/70 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-slate-800 dark:text-slate-200'
                        : 'bg-white dark:bg-slate-950/50 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60 text-slate-800 dark:text-slate-200'
                    }`}
                  >
                    {checked ? (
                      <CheckSquare className="w-4 h-4 text-emerald-700 dark:text-emerald-400 shrink-0 mt-0.5" />
                    ) : (
                      <Square className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                    )}
                    <span className={checked ? 'line-through text-slate-500 dark:text-slate-400' : ''}>{item}</span>
                  </button>
                );
              })}
            </div>
          </section>

          <section className="bento-card p-5 space-y-3">
            <h2 className="font-display text-sm font-bold text-slate-900 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-2.5">
              Official {jurisdiction.countyName} County Directory
            </h2>
            <div className="space-y-2">
              {jurisdiction.officialLinks.map((link) => (
                <div
                  key={link.label}
                  className="bento-inset p-3 flex items-center justify-between gap-3 text-xs"
                >
                  <div className="min-w-0">
                    <div className="font-semibold text-slate-900 dark:text-white truncate">{link.label}</div>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                      {link.department} · {link.portalVendor}
                    </div>
                  </div>
                  <a
                    href={link.url}
                    target="_blank"
                    rel="noreferrer"
                    aria-label={`Open ${link.label}`}
                    className="p-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 shrink-0"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              ))}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};
