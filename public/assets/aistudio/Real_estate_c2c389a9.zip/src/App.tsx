import React, { useEffect, useMemo, useState } from 'react';
import type {
  ActivityLog,
  BuyerProfile,
  CrmDeal,
  DealStage,
  DiscoverFilters,
  ExtractedDocketData,
  GeneratedDoc,
  PlanTier,
  SavedSearch,
  ThemeMode,
  ThirdPartyIntegration,
  WorkspaceId,
} from './types/caselot';
import {
  DEFAULT_BUYER_PROFILE,
  SEED_DEALS,
  SEED_FORM_TEMPLATES,
  SEED_JURISDICTIONS,
  SEED_SAVED_SEARCHES,
} from './data/seedData';
import { SEED_INTEGRATIONS } from './utils/valuationAndIntegrations';
import { SidebarNav } from './components/SidebarNav';
import { DiscoverView } from './components/DiscoverView';
import { PropertyDetailPage } from './components/PropertyDetailPage';
import { PipelineView } from './components/PipelineView';
import { ProbateHubView } from './components/ProbateHubView';
import { EngageFormsView } from './components/EngageFormsView';
import { ConnectorsPipelineView } from './components/ConnectorsPipelineView';
import { PropertyDossierModal } from './components/PropertyDossierModal';
import { DocketIngestModal } from './components/DocketIngestModal';
import { PricingModal } from './components/PricingModal';
import { OfflineIndicator } from './components/PWAComponents';

const STORAGE_KEY = 'caselot_workspace_v2';

interface PersistedState {
  deals: CrmDeal[];
  savedSearches: SavedSearch[];
  generatedDocs: GeneratedDoc[];
  buyerProfile: BuyerProfile;
  theme: ThemeMode;
  planTier: PlanTier;
  integrations: ThirdPartyIntegration[];
}

function loadInitialState(): PersistedState {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<PersistedState>;
      if (Array.isArray(parsed.deals) && parsed.deals.length > 0) {
        return {
          deals: parsed.deals,
          savedSearches: Array.isArray(parsed.savedSearches)
            ? parsed.savedSearches
            : SEED_SAVED_SEARCHES,
          generatedDocs: Array.isArray(parsed.generatedDocs) ? parsed.generatedDocs : [],
          buyerProfile: parsed.buyerProfile ?? DEFAULT_BUYER_PROFILE,
          theme: parsed.theme === 'light' ? 'light' : 'dark',
          planTier:
            parsed.planTier === 'pro' || parsed.planTier === 'enterprise'
              ? parsed.planTier
              : 'free',
          integrations:
            Array.isArray(parsed.integrations) && parsed.integrations.length > 0
              ? parsed.integrations
              : SEED_INTEGRATIONS,
        };
      }
    }
  } catch {
    // Ignore storage read errors and fall back to seed data
  }
  return {
    deals: SEED_DEALS,
    savedSearches: SEED_SAVED_SEARCHES,
    generatedDocs: [],
    buyerProfile: DEFAULT_BUYER_PROFILE,
    theme: 'dark',
    planTier: 'free',
    integrations: SEED_INTEGRATIONS,
  };
}

export default function App() {
  const initial = useMemo(() => loadInitialState(), []);

  const [workspace, setWorkspace] = useState<WorkspaceId>('discover');
  const [deals, setDeals] = useState<CrmDeal[]>(initial.deals);
  const [savedSearches, setSavedSearches] = useState<SavedSearch[]>(initial.savedSearches);
  const [generatedDocs, setGeneratedDocs] = useState<GeneratedDoc[]>(initial.generatedDocs);
  const [buyerProfile, setBuyerProfile] = useState<BuyerProfile>(initial.buyerProfile);
  const [theme, setTheme] = useState<ThemeMode>(initial.theme);
  const [planTier, setPlanTier] = useState<PlanTier>(initial.planTier);
  const [integrations, setIntegrations] = useState<ThirdPartyIntegration[]>(initial.integrations);

  const [selectedDealId, setSelectedDealId] = useState<string>(initial.deals[0]?.id ?? '');
  const [dossierDealId, setDossierDealId] = useState<string | null>(null);
  const [showIngestModal, setShowIngestModal] = useState(false);
  const [showPricingModal, setShowPricingModal] = useState(false);
  const [upgradeFeatureName, setUpgradeFeatureName] = useState<string | null>(null);
  const [gmpQuotaExceeded, setGmpQuotaExceeded] = useState(false);

  const [mapsApiKey, setMapsApiKey] = useState<string>(() => {
    const viteKey = (import.meta as unknown as { env?: Record<string, string | undefined> }).env
      ?.VITE_GOOGLE_MAPS_API_KEY;
    if (viteKey && viteKey !== 'MY_GOOGLE_MAPS_API_KEY') return viteKey;
    return '';
  });

  const [selectedHubJurisdictionId, setSelectedHubJurisdictionId] = useState<string>(
    initial.deals[0]?.probateCase.jurisdictionId ?? SEED_JURISDICTIONS[0].id
  );
  const [selectedHubStateCode, setSelectedHubStateCode] = useState<string>(
    initial.deals[0]?.property.stateCode ?? 'TX'
  );

  const [filters, setFilters] = useState<DiscoverFilters>({
    stateCode: 'ALL',
    countyName: 'ALL',
    filingWindowDays: 0,
    propertyType: 'All',
    minEquity: 0,
    attorneyStatus: 'all',
    adminType: 'all',
    searchQuery: '',
  });

  // Apply Dark Mode class to <html>
  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
  }, [theme]);

  // Listen to Google Maps Platform quota / auth failure event
  useEffect(() => {
    const onQuotaExceeded = () => setGmpQuotaExceeded(true);
    window.addEventListener('gmp-quota-exceeded', onQuotaExceeded);
    return () => window.removeEventListener('gmp-quota-exceeded', onQuotaExceeded);
  }, []);

  // Fetch runtime Maps API key from server if Vite env var wasn't set at build time
  useEffect(() => {
    if (mapsApiKey) return;
    fetch('/api/config/maps')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data?.apiKey) {
          setMapsApiKey(String(data.apiKey));
        }
      })
      .catch(() => {
        // Silent fallback when key is unavailable
      });
  }, [mapsApiKey]);

  useEffect(() => {
    try {
      const payload: PersistedState = {
        deals,
        savedSearches,
        generatedDocs,
        buyerProfile,
        theme,
        planTier,
        integrations,
      };
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
    } catch {
      // Ignore quota errors
    }
  }, [deals, savedSearches, generatedDocs, buyerProfile, theme, planTier, integrations]);

  const activeDeal = useMemo(
    () => deals.find((d) => d.id === selectedDealId) ?? deals[0],
    [deals, selectedDealId]
  );

  const dossierDeal = useMemo(
    () => (dossierDealId ? deals.find((d) => d.id === dossierDealId) ?? null : null),
    [deals, dossierDealId]
  );

  const pipelineCount = useMemo(() => deals.filter((d) => d.inPipeline).length, [deals]);

  const handleSelectDeal = (dealId: string) => {
    setSelectedDealId(dealId);
    const found = deals.find((d) => d.id === dealId);
    if (found) {
      setSelectedHubJurisdictionId(found.probateCase.jurisdictionId);
      setSelectedHubStateCode(found.property.stateCode);
    }
  };

  const handleMoveStage = (dealId: string, nextStage: DealStage, addToPipeline = true) => {
    setDeals((prev) =>
      prev.map((d) =>
        d.id === dealId
          ? { ...d, stage: nextStage, inPipeline: addToPipeline ? true : d.inPipeline }
          : d
      )
    );
  };

  const handleAddToPipeline = (dealId: string) => {
    setDeals((prev) =>
      prev.map((d) =>
        d.id === dealId
          ? {
              ...d,
              inPipeline: true,
              stage: d.stage === 'New Lead' ? 'Verified Real Estate' : d.stage,
            }
          : d
      )
    );
  };

  const handleUpdateOfferAndNotes = (
    dealId: string,
    offerAmount: number,
    notes: string,
    nextFollowupAt: string
  ) => {
    setDeals((prev) =>
      prev.map((d) =>
        d.id === dealId ? { ...d, offerAmount, notes, nextFollowupAt } : d
      )
    );
  };

  const handleAddActivity = (
    dealId: string,
    channel: ActivityLog['channel'],
    summary: string
  ) => {
    const timestamp = new Date().toISOString().slice(0, 16).replace('T', ' ');
    const newEntry: ActivityLog = {
      id: `act-${Date.now()}`,
      timestamp,
      channel,
      summary,
    };
    setDeals((prev) =>
      prev.map((d) =>
        d.id === dealId ? { ...d, activities: [newEntry, ...d.activities] } : d
      )
    );
  };

  const handleToggleChecklist = (dealId: string, itemLabel: string) => {
    setDeals((prev) =>
      prev.map((d) => {
        if (d.id !== dealId) return d;
        const current = Boolean(d.checklistCompleted[itemLabel]);
        return {
          ...d,
          checklistCompleted: {
            ...d.checklistCompleted,
            [itemLabel]: !current,
          },
        };
      })
    );
  };

  const handleSaveSearch = (name: string, alertFrequency: SavedSearch['alertFrequency']) => {
    const newSearch: SavedSearch = {
      id: `ss-${Date.now()}`,
      name,
      filters: { ...filters },
      alertFrequency,
      createdAt: new Date().toISOString().slice(0, 10),
    };
    setSavedSearches((prev) => [newSearch, ...prev]);
  };

  const handleDeleteSavedSearch = (id: string) => {
    setSavedSearches((prev) => prev.filter((s) => s.id !== id));
  };

  const handleImportTexasDeals = (incomingDeals: CrmDeal[]) => {
    setDeals((prev) => {
      const existingCases = new Set(prev.map((d) => d.probateCase.caseNumber));
      const fresh = incomingDeals.filter((d) => !existingCases.has(d.probateCase.caseNumber));
      if (fresh.length === 0) return prev;
      return [...fresh, ...prev];
    });
    if (incomingDeals[0]) {
      setSelectedDealId(incomingDeals[0].id);
    }
  };

  const handleImportExtracted = (data: ExtractedDocketData, rawText: string) => {
    const cleanCounty = data.countyName.replace(/\s+County$/i, '').trim() || 'Harris';
    const cleanState = data.stateCode.toUpperCase().trim() || 'TX';
    const cleanStreet = data.propertyAddress.split(',')[0].trim();

    const matchedJurisdiction =
      SEED_JURISDICTIONS.find(
        (j) =>
          j.stateCode.toLowerCase() === cleanState.toLowerCase() &&
          j.countyName.toLowerCase() === cleanCounty.toLowerCase()
      ) ??
      SEED_JURISDICTIONS.find((j) => j.stateCode.toLowerCase() === cleanState.toLowerCase()) ??
      SEED_JURISDICTIONS[0];

    const idx = deals.length;
    const angle = (idx * 1.15) % (Math.PI * 2);
    const radius = 5.2 + (idx % 3) * 1.8;

    const newDealId = `deal-ingested-${Date.now()}`;
    const hasAtty =
      Boolean(data.probateAttorney) &&
      !/none|pro se|unrepresented/i.test(data.probateAttorney);

    const newDeal: CrmDeal = {
      id: newDealId,
      inPipeline: true,
      stage: 'Verified Real Estate',
      offerAmount: Math.round(data.assessedValue * 0.76),
      notes: `Imported via AI Docket Extraction. ${data.aiSummary}`,
      nextFollowupAt: '2026-11-20',
      probateCase: {
        id: `case-${Date.now()}`,
        jurisdictionId: matchedJurisdiction.id,
        caseNumber: data.caseNumber,
        decedentName: data.decedentName,
        dateOfDeath: data.dateOfDeath,
        filingDate: '2026-11-13',
        caseType: data.caseType,
        adminType: data.adminType,
        probateStage: data.probateStage,
        hasAttorney: hasAtty,
        rawDocketText: rawText,
        aiSummary: data.aiSummary,
        docketTimeline: [
          {
            id: `ev-${Date.now()}`,
            date: '2026-11-13',
            title: `${data.caseType} Imported`,
            documentType: 'Extracted Filing',
            notes: `Executor: ${data.executorName}`,
          },
        ],
      },
      property: {
        id: `prop-${Date.now()}`,
        parcelId: data.parcelId || 'APN-PENDING',
        address: cleanStreet,
        city: data.city,
        stateCode: cleanState,
        zip: '77018',
        countyName: cleanCounty,
        legalDescription: `PARCEL ${data.parcelId} · ${cleanCounty.toUpperCase()} COUNTY, ${cleanState}`,
        assessedValue: data.assessedValue,
        estimatedDebt: data.estimatedDebt,
        propertyType: data.propertyType,
        sqft: 2050,
        yearBuilt: 1972,
        lat: 29.8,
        lng: -95.4,
        sceneX: Number((Math.cos(angle) * radius).toFixed(2)),
        sceneZ: Number((Math.sin(angle) * radius).toFixed(2)),
        ownerName: data.decedentName,
        matchConfidence: 95,
        matchSource: 'Inventory & Appraisement PDF',
      },
      stakeholders: [
        {
          id: `st-${Date.now()}-exec`,
          role: 'Executor / PR',
          fullName: data.executorName,
          mailingAddress: data.executorAddress,
          phone: '(555) 010-2026',
          email: 'executor.pending@example.com',
          verified: true,
        },
        ...(hasAtty
          ? [
              {
                id: `st-${Date.now()}-atty`,
                role: 'Probate Attorney' as const,
                fullName: data.probateAttorney,
                mailingAddress: `${data.countyName} County Bar`,
                phone: '(555) 010-9910',
                email: 'counsel@example.com',
                verified: true,
              },
            ]
          : []),
      ],
      activities: [
        {
          id: `act-${Date.now()}`,
          timestamp: new Date().toISOString().slice(0, 16).replace('T', ' '),
          channel: 'Note',
          summary: 'Imported structured probate docket & matched parcel via AI Docket Parser.',
        },
      ],
      checklistCompleted: {},
    };

    setDeals((prev) => [newDeal, ...prev]);
    setSelectedDealId(newDealId);
    setSelectedHubJurisdictionId(matchedJurisdiction.id);
    setSelectedHubStateCode(cleanState);
    setShowIngestModal(false);
    setDossierDealId(newDealId);
  };

  const handleRequireUpgrade = (featureName: string) => {
    setUpgradeFeatureName(featureName);
    setShowPricingModal(true);
  };

  const handleOpenHubForState = (stateCode: string) => {
    setSelectedHubStateCode(stateCode);
    const matchingJurisdiction = SEED_JURISDICTIONS.find((j) => j.stateCode === stateCode);
    if (matchingJurisdiction) {
      setSelectedHubJurisdictionId(matchingJurisdiction.id);
    }
    setWorkspace('hub');
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F4F6FA] dark:bg-[#060911] text-slate-900 dark:text-slate-100">
      {gmpQuotaExceeded && (
        <div className="bg-amber-50 border-b border-amber-200 text-amber-900 px-4 py-2.5 text-xs md:text-sm text-center sticky top-0 z-50 shadow-sm">
          <span>
            Google Maps Platform quota reached. If you are the app owner, visit{' '}
            <a
              href="https://developers.google.com/maps/ai/ai-studio?utm_campaign=gmp_mcp_codeassist_v1_aistudio#quota_exceeded_errors"
              target="_blank"
              rel="noopener noreferrer"
              className="underline font-semibold text-amber-950 hover:text-amber-800"
            >
              maps developer site
            </a>{' '}
            for instructions to update your account.
          </span>
        </div>
      )}

      <div className="flex-1 flex flex-col lg:flex-row min-h-0">
        <SidebarNav
          activeWorkspace={workspace}
          onSelectWorkspace={setWorkspace}
          activeDeal={activeDeal}
          pipelineCount={pipelineCount}
          totalDealsCount={deals.length}
          integrationsCount={integrations.filter((i) => i.enabled).length}
          theme={theme}
          onToggleTheme={() => setTheme((t) => (t === 'dark' ? 'light' : 'dark'))}
          planTier={planTier}
          onOpenPricing={() => {
            setUpgradeFeatureName(null);
            setShowPricingModal(true);
          }}
          onOpenIngest={() => setShowIngestModal(true)}
        />

        <main className="flex-1 min-w-0 p-4 sm:p-6 lg:p-8 pb-24 lg:pb-8 overflow-y-auto">
          <div className="max-w-[1440px] mx-auto">
            {workspace === 'discover' && (
              <DiscoverView
                deals={deals}
                jurisdictions={SEED_JURISDICTIONS}
                filters={filters}
                onChangeFilters={setFilters}
                savedSearches={savedSearches}
                onSaveSearch={handleSaveSearch}
                onDeleteSavedSearch={handleDeleteSavedSearch}
                selectedDealId={selectedDealId}
                onSelectDeal={handleSelectDeal}
                onOpenDossier={(id) => {
                  handleSelectDeal(id);
                  setDossierDealId(id);
                }}
                onOpenPropertyPage={(id) => {
                  handleSelectDeal(id);
                  setWorkspace('property');
                }}
                onAddToPipeline={handleAddToPipeline}
                onOpenHubForState={handleOpenHubForState}
                onOpenIngest={() => setShowIngestModal(true)}
                mapsApiKey={mapsApiKey}
                theme={theme}
                planTier={planTier}
                onRequireUpgrade={handleRequireUpgrade}
              />
            )}

            {workspace === 'property' && activeDeal && (
              <PropertyDetailPage
                deal={activeDeal}
                allDeals={deals}
                jurisdiction={SEED_JURISDICTIONS.find(
                  (j) => j.id === activeDeal.probateCase.jurisdictionId
                )}
                buyerEntity={buyerProfile.entityName}
                mapsApiKey={mapsApiKey}
                theme={theme}
                onSelectDeal={handleSelectDeal}
                onBackToDiscover={() => setWorkspace('discover')}
                onAddToPipeline={handleAddToPipeline}
                onOpenEngage={(id) => {
                  handleSelectDeal(id);
                  setWorkspace('engage');
                }}
                onOpenHub={(id) => {
                  handleSelectDeal(id);
                  setWorkspace('hub');
                }}
              />
            )}

            {workspace === 'pipeline' && (
              <PipelineView
                deals={deals}
                onMoveStage={(id, next) => handleMoveStage(id, next, true)}
                onOpenDossier={(id) => {
                  handleSelectDeal(id);
                  setDossierDealId(id);
                }}
                onOpenForms={(id) => {
                  handleSelectDeal(id);
                  setWorkspace('engage');
                }}
              />
            )}

            {workspace === 'hub' && (
              <ProbateHubView
                jurisdictions={SEED_JURISDICTIONS}
                activeDeal={activeDeal}
                selectedJurisdictionId={selectedHubJurisdictionId}
                onSelectJurisdiction={setSelectedHubJurisdictionId}
                selectedStateCode={selectedHubStateCode}
                onSelectStateCode={setSelectedHubStateCode}
                onToggleChecklist={handleToggleChecklist}
              />
            )}

            {workspace === 'engage' && activeDeal && (
              <EngageFormsView
                deals={deals}
                jurisdictions={SEED_JURISDICTIONS}
                templates={SEED_FORM_TEMPLATES}
                activeDeal={activeDeal}
                onSelectDeal={handleSelectDeal}
                buyerProfile={buyerProfile}
                onUpdateBuyerProfile={setBuyerProfile}
                generatedDocs={generatedDocs}
                onRecordGeneratedDoc={(doc) => setGeneratedDocs((prev) => [doc, ...prev])}
                planTier={planTier}
                onRequireUpgrade={handleRequireUpgrade}
              />
            )}

            {workspace === 'connectors' && (
              <ConnectorsPipelineView
                planTier={planTier}
                onRequireUpgrade={handleRequireUpgrade}
                onImportTexasDeals={handleImportTexasDeals}
                onJumpToDiscover={() => setWorkspace('discover')}
                integrations={integrations}
                onToggleIntegration={(id) =>
                  setIntegrations((prev) =>
                    prev.map((item) =>
                      item.id === id ? { ...item, enabled: !item.enabled } : item
                    )
                  )
                }
                onUpdateIntegration={(id, patch) =>
                  setIntegrations((prev) =>
                    prev.map((item) => (item.id === id ? { ...item, ...patch } : item))
                  )
                }
                onAddIntegration={(item) => setIntegrations((prev) => [item, ...prev])}
                onDeleteIntegration={(id) =>
                  setIntegrations((prev) => prev.filter((item) => item.id !== id))
                }
              />
            )}
          </div>
        </main>
      </div>

      <OfflineIndicator />

      {dossierDeal && (
        <PropertyDossierModal
          deal={dossierDeal}
          jurisdiction={SEED_JURISDICTIONS.find(
            (j) => j.id === dossierDeal.probateCase.jurisdictionId
          )}
          onClose={() => setDossierDealId(null)}
          onUpdateStage={handleMoveStage}
          onUpdateOfferAndNotes={handleUpdateOfferAndNotes}
          onAddActivity={handleAddActivity}
          onJumpToHub={(id) => {
            handleSelectDeal(id);
            setDossierDealId(null);
            setWorkspace('hub');
          }}
          onJumpToEngage={(id) => {
            handleSelectDeal(id);
            setDossierDealId(null);
            setWorkspace('engage');
          }}
        />
      )}

      {showIngestModal && (
        <DocketIngestModal
          onClose={() => setShowIngestModal(false)}
          onImportExtracted={handleImportExtracted}
        />
      )}

      {showPricingModal && (
        <PricingModal
          currentPlan={planTier}
          onSelectPlan={setPlanTier}
          onClose={() => setShowPricingModal(false)}
          highlightFeature={upgradeFeatureName}
        />
      )}
    </div>
  );
}
