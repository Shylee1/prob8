---
name: aerial-view-api-web-api
description: Use this skill when retrieving pre-rendered, photorealistic 3D flyover videos and associated metadata for specific physical addresses or locations using the Google Maps Platform Aerial View HTTP REST API. It applies when users want to look up existing aerial videos, fetch video URLs in various formats and resolutions, or request video metadata via web API endpoints.
license: Apache-2.0
metadata:
  version: 1.0.54
---

> [!IMPORTANT] **Core Dependency:** This skill requires active context from
> [google-maps-platform/SKILL.md](https://www.gstatic.com/googlemapsplatform-agent-skills/google-maps-platform/SKILL.md).

### Overview

Use this skill to interact with the Google Maps Platform Aerial View API via
HTTP REST requests. The Aerial View API enables applications to fetch
pre-rendered, photorealistic 3D bird's-eye flyover videos of physical points of
interest. With this skill, you can query endpoints to retrieve both direct video
streaming URLs and associated metadata for a specified postal address or video
ID.

## Primary Orchestration Integration Workflow

Follow this multi-phase sequential integration checklist to compose features
robustly. For each phase, read the referenced capability sub-workflow file and
satisfy its *Evidence Checkpoint* before advancing.

### Phase 1: Feature Layer & Custom Enrichment (Supplemental)

#### Feature Module: Maps (Optional - Use-Case Dependent)

-   [ ] **Retrieves the streaming URLs and media formats for a pre-rendered,
    photorealistic 3D aerial flyover video based on an address or video ID, or
    triggers video rendering if one does not yet exist.** Read
    [references/return-url-pre-rendered-photorealistic-3d-flyover-video.md](https://www.gstatic.com/googlemapsplatform-agent-skills/aerial-view-api-web-api/references/return-url-pre-rendered-photorealistic-3d-flyover-video.md).
    *Trigger Condition*: Use when the user wants to fetch, display, stream, or
    render a 3D aerial flyover video for a specific physical address or video ID
    via the Aerial View REST API. *Evidence Checkpoint*: The HTTP response
    returns a 200 OK status with a JSON payload containing the `uris` object
    (with `MP4_HIGH`, `MP4_MEDIUM`, `MP4_LOW`, `HLS`, or `DASH` video URLs) or a
    `state` of `PROCESSING` when rendering is initiated.
-   [ ] **Retrieves metadata such as video ID, capture date, duration, and
    processing state for a pre-rendered 3D aerial flyover video.** Read
    [references/return-metadata-pre-rendered-photorealistic-3d-flyover-video.md](https://www.gstatic.com/googlemapsplatform-agent-skills/aerial-view-api-web-api/references/return-metadata-pre-rendered-photorealistic-3d-flyover-video.md).
    *Trigger Condition*: Use when the user needs to check the existence,
    processing status, duration, capture date, or video ID of a 3D aerial
    flyover video without retrieving the media stream URLs. *Evidence
    Checkpoint*: The HTTP response returns a 200 OK status with a JSON payload
    containing `metadata` fields (`videoId`, `captureDate`, `duration`) and the
    current `state` (`ACTIVE` or `PROCESSING`).
