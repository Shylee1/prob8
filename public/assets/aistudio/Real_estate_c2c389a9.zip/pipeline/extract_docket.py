"""
CaseLot Self-Hosted Probate Docket & Inventory Extraction Pipeline
=================================================================
Zero-per-token-fee local AI extraction pipeline:
  1. Document/PDF Parsing (OCR + layout-preserved Markdown): Docling
  2. Structured JSON Extraction: Ollama (Gemma 4 / Qwen 3) or vLLM + Outlines + Pydantic v2

Run locally:
  python extract_docket.py --sample --backend ollama --model gemma4
  python extract_docket.py --input ./sample_inventory.pdf --backend ollama --model qwen3:14b
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Literal, Optional

from pydantic import BaseModel, Field


class ProbatePropertyItem(BaseModel):
    address: str = Field(..., description="Street address of decedent real property")
    city: str = Field(default="", description="City")
    state_code: str = Field(default="TX", description="2-letter US state postal code")
    county_name: str = Field(default="", description="County name without the word County")
    parcel_id: str = Field(default="", description="Assessor APN / Account Number if present")
    assessed_value: int = Field(default=0, ge=0, description="Assessed or inventoried USD value")


class ProbateDocketExtraction(BaseModel):
    decedent_name: str = Field(..., description="Full legal name of the deceased")
    date_of_death: str = Field(default="", description="ISO YYYY-MM-DD date of death if stated")
    case_number: str = Field(..., description="Probate cause or docket number")
    case_type: str = Field(..., description="e.g. Independent Administration, Formal Probate")
    admin_type: Literal["Independent", "Dependent / Supervised", "Informal", "Summary"] = Field(
        default="Independent"
    )
    executor_name: str = Field(..., description="Appointed Executor, Administrator, or Personal Representative")
    executor_address: str = Field(default="", description="Executor or PR mailing address")
    probate_attorney: str = Field(default="None Listed (Pro Se)", description="Attorney of record or Pro Se")
    property_addresses: list[ProbatePropertyItem] = Field(
        default_factory=list,
        description="All real property assets listed in docket or Inventory & Appraisement",
    )
    estimated_debt_or_liens: int = Field(
        default=0, ge=0, description="Total mortgage, HELOC, or tax lien debt in USD"
    )
    probate_stage: str = Field(
        default="Petition Filed",
        description="Current court milestone (e.g. Citation Posted, Letters Issued, Inventory Filed)",
    )


SYSTEM_PROMPT = (
    "You are CaseLot's offline probate court document extractor. "
    "Read the OCR-parsed court filing or Inventory & Appraisement Markdown below and extract exact, "
    "factual probate metadata and real estate assets matching the provided JSON Schema. "
    "Do not invent addresses or dollar amounts not supported by the text."
)

SAMPLE_COURT_FILING = """
CAUSE NO. 526104-403
IN THE ESTATE OF RAYMOND V. ALVAREZ, DECEASED
PROBATE COURT NO. 3, HARRIS COUNTY, TEXAS
Date of Death: 2026-09-11 | Filed: 2026-11-11
Application for Independent Administration & Letters Testamentary
Applicant / Independent Executor: Gloria Alvarez, 3118 Norfolk St, Houston, TX 77098
Attorney of Record: None Listed (Pro Se)
Schedule A - Real Property:
1. 4418 Magnolia Ridge Dr, Houston, TX 77023 (HCAD APN: 066-142-0018), Appraised Value: $398,000
Liens / Encumbrances: Harris County Tax Lien $14,000; No mortgage of record.
"""


def parse_document_to_markdown(input_path: Path) -> str:
    """Convert scanned PDF / DOCX / TXT court filing into layout-preserved Markdown using Docling."""
    suffix = input_path.suffix.lower()
    if suffix in {".txt", ".md", ".csv"}:
        return input_path.read_text(encoding="utf-8", errors="replace")

    try:
        from docling.document_converter import DocumentConverter, PdfFormatOption
        from docling.datamodel.base_models import InputFormat
        from docling.datamodel.pipeline_options import PdfPipelineOptions

        pipeline_options = PdfPipelineOptions()
        pipeline_options.do_ocr = True
        pipeline_options.do_table_structure = True

        converter = DocumentConverter(
            format_options={
                InputFormat.PDF: PdfFormatOption(pipeline_options=pipeline_options)
            }
        )
        result = converter.convert(str(input_path))
        return result.document.export_to_markdown()
    except ImportError as exc:
        raise RuntimeError(
            "Docling is required for PDF OCR parsing. Run: pip install -r requirements.txt"
        ) from exc


def extract_with_ollama(markdown_text: str, model: str, host: str) -> ProbateDocketExtraction:
    """Use local Ollama + Pydantic JSON schema enforcement (zero external API fees)."""
    import ollama

    client = ollama.Client(host=host)
    response = client.chat(
        model=model,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": markdown_text},
        ],
        format=ProbateDocketExtraction.model_json_schema(),
        options={"temperature": 0.0},
    )
    raw_json = response["message"]["content"]
    return ProbateDocketExtraction.model_validate_json(raw_json)


def extract_with_outlines_vllm(markdown_text: str, model: str, base_url: str) -> ProbateDocketExtraction:
    """Use Outlines + local vLLM OpenAI-compatible server for CFG-constrained Pydantic JSON."""
    import outlines
    from openai import OpenAI

    client = OpenAI(base_url=base_url, api_key=os.environ.get("VLLM_API_KEY", "local-dev"))
    outlines_model = outlines.from_openai(client, model)
    result_json = outlines_model(
        f"{SYSTEM_PROMPT}\n\nDOCUMENT:\n{markdown_text}",
        ProbateDocketExtraction,
    )
    if isinstance(result_json, ProbateDocketExtraction):
        return result_json
    return ProbateDocketExtraction.model_validate_json(str(result_json))


def main() -> int:
    parser = argparse.ArgumentParser(
        description="CaseLot Self-Hosted Probate Docket Extraction Worker (Docling + Ollama/vLLM + Pydantic)"
    )
    parser.add_argument("--input", type=Path, help="Path to scanned PDF, TXT, or Markdown court filing")
    parser.add_argument("--sample", action="store_true", help="Run using built-in Harris County sample filing")
    parser.add_argument("--backend", choices=["ollama", "vllm"], default="ollama")
    parser.add_argument("--model", default="gemma4", help="Local open-weight model tag (e.g. gemma4, qwen3)")
    parser.add_argument("--host", default=os.environ.get("OLLAMA_HOST", "http://localhost:11434"))
    parser.add_argument("--vllm-url", default=os.environ.get("VLLM_BASE_URL", "http://localhost:8000/v1"))
    parser.add_argument("--json-out", type=Path, help="Optional output file path for validated JSON")
    args = parser.parse_args()

    if not args.sample and not args.input:
        parser.error("Specify --input <file> or --sample")

    if args.sample:
        markdown_text = SAMPLE_COURT_FILING
    else:
        markdown_text = parse_document_to_markdown(args.input)

    if args.backend == "ollama":
        extracted = extract_with_ollama(markdown_text, model=args.model, host=args.host)
    else:
        extracted = extract_with_outlines_vllm(markdown_text, model=args.model, base_url=args.vllm_url)

    payload = json.dumps(extracted.model_dump(), indent=2)
    if args.json_out:
        args.json_out.write_text(payload, encoding="utf-8")
    print(payload)
    return 0


if __name__ == "__main__":
    sys.exit(main())
