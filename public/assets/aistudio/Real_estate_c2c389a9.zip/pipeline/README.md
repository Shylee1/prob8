# CaseLot Self-Hosted AI Extraction Pipeline

Zero-per-token-fee local OCR & structured extraction worker using:

- **Docling** (`docling`) for OCR & layout-preserved Markdown conversion of scanned Probate Petitions and Inventory & Appraisement PDFs.
- **Ollama** (`gemma4` or `qwen3`) or **vLLM + Outlines** for 100% locally hosted open-weight structured JSON extraction.
- **Pydantic v2** (`ProbateDocketExtraction`) schema validation.

## Quick Start (Local Python)

```bash
# 1. Install Ollama and pull an open-weight model
ollama pull gemma4
# Or Qwen 3:
# ollama pull qwen3:14b

# 2. Install minimal worker dependencies
cd pipeline
pip install -r requirements.txt

# 3. Extract from a scanned PDF court filing
python extract_docket.py --input ./path/to/inventory.pdf --backend ollama --model gemma4 --json-out extracted.json
```

## Quick Start (Docker Compose)

```bash
cd pipeline
docker compose up -d ollama
docker exec caselot-ollama ollama pull gemma4
docker compose run --rm worker
```
